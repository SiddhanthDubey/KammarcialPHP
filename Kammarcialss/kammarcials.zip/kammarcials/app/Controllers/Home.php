<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('web/welcome_message');
    }
    
    public function male_fertility()
    {
        return view('web/male_fertility');
    }
    
    public function menopause_assessment()
    {
        return view('web/menopause_assessment');
    }
    
    public function prediabetes_assessment()
    {
        return view('web/prediabetes_assessment');
    }
    
     public function quiz_pcos_type()
    {
        return view('web/quiz_pcos_type');
    }
    
    
    
    public function rejected()
    {
        return view('web/rejected');
    }
    
    public function return()
    {
        return view('web/return');
    }
    
    public function callback()
    {
        return view('web/callback');
    }
    
    public function accepted()
    {
        return view('web/accepted');
    }
}
