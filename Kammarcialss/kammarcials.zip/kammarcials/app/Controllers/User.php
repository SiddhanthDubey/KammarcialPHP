<?php
 
namespace App\Controllers;
 
use App\Controllers\BaseController;
use CodeIgniter\API\ResponseTrait;
use App\Models\UserModel;
use App\Models\ContactUsModel;
use App\Models\ComplainModel;
use App\Models\ProviderGallery;
use App\Models\UserViewModel;

//use \Firebase\JWT\JWT;
//use Firebase\JWT\Key;
 
class User extends BaseController
{
    use ResponseTrait;
    
    
    // public function __construct()
    // {
    //     // Load the UserModel in the constructor
    //     $this->UserModel = new \App\Models\UserModel();
      
        
    //     header("Access-Control-Allow-Origin: *");
    //     header("Access-Control-Request-Headers: GET,POST,DELETE,PUT");
    //     header('Access-Control-Allow-Headers: Accept-Language,Content-Language,Content-Type');
    //     // {'Content-Type': 'application/x-www-form-urlencoded'}
    //     header('Access-Control-Allow-Headers: Accept-Language,Content-Language,Content-Type'); 
    //     header('Content-type:application/x-www-form-urlencoded');
    // }
    
     
    public function index()
    {
        $users = new UserModel;
        return $this->respond(['users' => $users->findAll()], 200);
    }
    
     public function delete_gallery_professional() {
       
        $id = $this->request->getVar('provider_id');
        $image_id = $this->request->getVar('image_id');
        
        $model = new ProviderGallery();
        
         $user = $model->where('provider_id', $id)->where('id', $image_id)->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'Image  Not Found' , 'status' => "0"], 200);
        }
        
        
        
        //$data = $model->find($id);
        $model->delete($image_id);
        $json['message'] = " Delete Success.";
        $json['status'] = "1";
        return $this->respond($json);
   
    }
    
    public function forget_password() {
       
        $countryCode = $this->request->getVar('country_code');
        $mobile = $this->request->getVar('mobile');
        $type = $this->request->getVar('type');//User Provider 
        
    
        //  $otp = '9999';
         $otp = rand(1000, 9999);
          
         $model = new UserModel();
          
              
        $userdata = $model->where('mobile', $mobile)->where('user_type', $type)->where('account_status', 'verify')->first();

        if ($userdata=='') {
            return $this->respond(['message' => 'Your Account is not Register ' , 'status' => "0"], 200); die;
        }
        
              $data =  [ 'otp' => $otp,'password'=>'' ];
              $model->where('type', $type)->where('mobile', $mobile)->set($data)->update();
              
              
                        // Your Account SID and Auth Token from twilio.com/console
            $account_sid = 'AC450e385ca1ab6c37ce72540a928b882e';
            $auth_token = '9d050ebefca296b4bdb27f6367063112';
            
            // A Twilio number you own with SMS capabilities
            $twilio_number = "+16412438110";
            
            
            // Recipient's phone number
           // $to_number = '+258847888318';
           
           $to_number = $countryCode.$mobile;
           
          // print_r($otp);die;
            
            // Message to be sent
            $message = 'Mobile Number Verification Code is '.$otp.' ';
            
            // Initialize cURL
            $ch = curl_init();
            
            // Set cURL options
            curl_setopt($ch, CURLOPT_URL, "https://api.twilio.com/2010-04-01/Accounts/$account_sid/Messages.json");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array(
                'To' => $to_number,
                'From' => $twilio_number,
                'Body' => $message
            )));
            curl_setopt($ch, CURLOPT_USERPWD, "$account_sid:$auth_token");
            
            // Execute cURL request
            $response = curl_exec($ch);
            
            $response_array = json_decode($response, true);

           // print_r($response_array['message']);die;
            
            // Check for errors
            // if(curl_errno($ch)) {
            //     echo 'Error:' . curl_error($ch);
            // } else {
            //     // Output HTTP response code and Twilio response
            //     echo "HTTP Response Code: " . curl_getinfo($ch, CURLINFO_HTTP_CODE) . "\n";
            //     echo "Twilio Response: " . $response . "\n";
            // }
            
            // Close cURL
            curl_close($ch);
            
          
               $userdata1 = $model->where('mobile', $mobile)->where('user_type', $type)->where('account_status', 'verify')->first();
          
                $json['user_data'] = $userdata1;
                $json['message'] = " Forgot Password Successfully Please check Otp";
                $json['status'] = "1";
                return $this->respond($json);die;
                
         
   
    }
         public   function juuuu()
         {
              $pickupLatitude = '22.72'; 
              $pickupLongitude = '75.86';
              $dropupLatitude = '23.18';
              $dropupLongitude = "75.78";
            
             $distanceValue = $this->calculateDistance($pickupLatitude,$pickupLongitude,$dropupLatitude,$dropupLongitude);
             echo $distanceValue;
         }
         

       
             public   function calculateDistance($userLat, $userLon, $driverLat, $driverLon)
            //  public  function calculateDistance()
             {
                // 75.86 and latitude of 22.72. Ujjain is l/ocated in India at the longitude of 75.78 and latitude of 23.18
            //   $userLat = '22.72'; 
            //   $userLon = '75.86';
            //   $driverLat = '23.18';
            //   $driverLon = "75.78";
                 
              $earthRadius = 6371; // in kilometers
            
              $latDiff = deg2rad($driverLat - $userLat);
              $lonDiff = deg2rad($driverLon - $userLon);
            
              $a = sin($latDiff / 2) * sin($latDiff / 2) +
                  cos(deg2rad($userLat)) * cos(deg2rad($driverLat)) *
                  sin($lonDiff / 2) * sin($lonDiff / 2);
              $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
            
              $distance = $earthRadius * $c; // in kilometers
            
            $formatted_number = number_format($distance, 2);
           // echo $formatted_number;die; 

              return $formatted_number; 
            }


    
    
    
     public function get_nearest_provider()
    {
        
        
         $pickupLatitude = $this->request->getVar('lat'); 
         $pickupLongitude = $this->request->getVar('lon');
         
         $service_id = $this->request->getVar('service_id');
         $type = $this->request->getVar('type');
         
         $distance_km = 200;

        $model = new UserModel();
        
       $db = \Config\Database::connect();
       
       if($type=='Company')
       {
    
    //   $categoryList = $db->query("SELECT * FROM `users` WHERE FIND_IN_SET($service_id, expertise_service_id) AND `user_type` = 'Company' AND `account_status` = 'verify' ")->getResultArray();
   
     $categoryList = $db->query("  SELECT *,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_1_lat)) * cos(radians(company_address_1_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_1_lat)))) AS distance1,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_2_lat)) * cos(radians(company_address_2_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_2_lat)))) AS distance2,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_3_lat)) * cos(radians(company_address_3_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_3_lat)))) AS distance3,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(lat)) * cos(radians(lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(lat)))) AS distance4
FROM `users`
WHERE 
    (FIND_IN_SET($service_id, expertise_service_id) AND `user_type` = 'Company' AND `account_status` = 'verify')
HAVING (distance1 <= 50 OR distance2 <= 50 OR distance3 <= 50 OR distance4 <= 50)
ORDER BY distance1, distance2, distance3, distance4;
 ")->getResultArray();
   
   
       }
       elseif($type=='Professional')
       {
             //   $categoryList = $db->query("SELECT * FROM `users` WHERE FIND_IN_SET($service_id, expertise_service_id) AND `user_type` = 'Professional' AND `account_status` = 'verify' ")->getResultArray();
  
      
       $categoryList = $db->query("  SELECT *,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_1_lat)) * cos(radians(company_address_1_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_1_lat)))) AS distance1,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_2_lat)) * cos(radians(company_address_2_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_2_lat)))) AS distance2,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_3_lat)) * cos(radians(company_address_3_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_3_lat)))) AS distance3,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(lat)) * cos(radians(lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(lat)))) AS distance4
FROM `users`
WHERE 
    (FIND_IN_SET($service_id, expertise_service_id) AND `user_type` = 'Professional' AND `account_status` = 'verify')
HAVING (distance1 <= 50 OR distance2 <= 50 OR distance3 <= 50 OR distance4 <= 50)
ORDER BY distance1, distance2, distance3, distance4;
 ")->getResultArray();
 
      
      
       }
       else
       {
    
     //  $categoryList = $db->query("SELECT * FROM `users` WHERE FIND_IN_SET($service_id, expertise_service_id) AND `user_type` IN ('Company','Professional') AND `account_status` = 'verify' ")->getResultArray();
  
    $categoryList = $db->query("  SELECT *,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_1_lat)) * cos(radians(company_address_1_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_1_lat)))) AS distance1,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_2_lat)) * cos(radians(company_address_2_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_2_lat)))) AS distance2,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(company_address_3_lat)) * cos(radians(company_address_3_lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(company_address_3_lat)))) AS distance3,
    (6371 * acos(cos(radians($pickupLatitude)) * cos(radians(lat)) * cos(radians(lon) - radians($pickupLongitude)) + sin(radians($pickupLatitude)) * sin(radians(lat)))) AS distance4
FROM `users`
WHERE 
    (FIND_IN_SET($service_id, expertise_service_id) AND `user_type` IN ('Company', 'Professional') AND `account_status` = 'verify')
HAVING (distance1 <= 50 OR distance2 <= 50 OR distance3 <= 50 OR distance4 <= 50)
ORDER BY distance1, distance2, distance3, distance4;
 ")->getResultArray();

      
       }
       
               
    // $categoryList = $db->query("SELECT * FROM `users` WHERE `user_type` IN ('Company','Professional') AND `account_status` = 'verify' ")->getResultArray();
     

//  print_r($categoryList);die;
     
     if($categoryList=='')
     {
            $json['data'] = [];
            $json['message'] = "data not found";
            $json['status'] = "0";
            return $this->respond($json);die;
     }
     
    //  echo '<pre>';
    //  print_r($categoryList);
    //  echo '</pre>';die;
        
      $i=0;
       $data1 = [];
        foreach($categoryList as $data_in){
           
        //   $usertype = $data_in['user_type']; 
          
        //   if($usertype=='Company')
        //   {
              
        //     $dropupLatitude = $data_in['company_address_1_lat'];
        //     $dropupLongitude = $data_in['company_address_1_lon'];
        //   }
        //   if($usertype=='Professional')
        //   {
        //     $dropupLatitude = $data_in['lat'];
        //     $dropupLongitude = $data_in['lon'];
        //   }
        //   if($dropupLatitude!='' && $dropupLongitude!='')
        //   {
        //   $distanceValue = $this->calculateDistance($pickupLatitude,$pickupLongitude,$dropupLatitude,$dropupLongitude);
        //   }
             
         //  echo $distanceValue.'**';
           
         //   if ($distanceValue <= $distance_km)
          //  {

              $data_in['image'] =  base_url() . "public/uploads/users/" . $data_in['image'];
              
             $id = $data_in['id'];
              
              $categoryList = $db->query("SELECT AVG(rating) AS rat FROM `rates` WHERE `owner_id` = '$id' ")->getResultArray();
         $rating = number_format($categoryList[0]['rat'], 1, '.', '');
         
         $categoryList111 = $db->query("SELECT COUNT(*) as cc FROM `rates` WHERE `owner_id` = '$id' ")->getResultArray();
         
         
             
         $data_in['rating'] =  $rating;
         $data_in['review'] =  $categoryList111[0]['cc'];
         
     
              $i++; 
            
             $data1[] = $data_in;
           
          //  }
            
      
        
        }
        
        
    //     echo '<pre>';
    //  print_r($data1);
    //  echo '</pre>';die;
    //     die;
    
        $json['data'] = $data1;
        $json['message'] = "Data Get Successfully";
        $json['status'] = 1;

        return $this->respond($json);
    }
    
    
    
     public function add_withdraw_request() {
         
           $userModel = new UserModel();
         
     
      $user_id = $this->request->getVar('user_id');
    //   $reward = $this->request->getVar('reward');
        
      $user = $userModel->where('id', $user_id)->first();
      
       if ($user=='') {
            return $this->respond(['message' => 'User Not Valid' , 'status' => "0"], 200); die;
        }
      
      $reward =  $user['wallet']; 
     
      $data = [
        'user_id' =>$user_id,
        'reward' =>$reward
    ];


      $db  = \Config\Database::connect();

    $builder1 = $db->table('withdraw');
    $result = $builder1->insert($data);
    
    
           if($result)
           {
              $json['data'] = 'success';
            $json['message'] = "Request Send successfully";
            $json['status'] = "1";
            return $this->respond($json);  
           }
           else
           {
              $json['data'] = 'not success';
            $json['message'] = "unsuccessfully";
            $json['status'] = "0";
            return $this->respond($json);  
           }
           
            
        
    }
    
    
     public function add_complain() {
      
        $user_id = $this->request->getVar('user_id');
       
        $message = $this->request->getVar('message'); 
      
        $model = new ComplainModel();
      
              $data = [
                            'user_id' =>$user_id,
                            'message' => $message
                     ];
        
           $result = $model->insert($data);
           
           if($result)
           {
              $json['data'] = 'success';
            $json['message'] = "Complain added successfully";
            $json['status'] = "1";
            return $this->respond($json);  
           }
           else
           {
              $json['data'] = 'not success';
            $json['message'] = "unsuccessfully";
            $json['status'] = "0";
            return $this->respond($json);  
           }
           
            
        
    }
    
     public function add_contact_us() {
      
        $user_id = $this->request->getVar('user_id');
        
        $user_name = $this->request->getVar('user_name');
        
        $email = $this->request->getVar('email');
       
        $message = $this->request->getVar('message'); 
      
        $model = new ContactUsModel();
      
              $data = [
                            'user_id' =>$user_id,
                            'user_name' => $user_name, 
                            'email' => $email ,
                            'message' => $message
                     ];
        
           $result = $model->insert($data);
           
           if($result)
           {
              $json['data'] = 'success';
            $json['message'] = "Contact added successfully";
            $json['status'] = "1";
            return $this->respond($json);  
           }
           else
           {
              $json['data'] = 'not success';
            $json['message'] = "unsuccessfully";
            $json['status'] = "0";
            return $this->respond($json);  
           }
           
            
        
    }
    
    
      public function register_company_provider() {
          
         
     

        $user_id = $this->request->getVar('provider_id');
        $company_name = $this->request->getVar('company_name');
        $company_code = $this->request->getVar('company_code');
        $company_mail = $this->request->getVar('company_mail');
        $year_of_expertise = $this->request->getVar('year_of_expertise');
       
        $expertise_service_idsss = $this->request->getVar('expertise_service_id');
        
        $array = json_decode($expertise_service_idsss, true); // Convert string to array
        $expertise_service_id = implode(',', $array); // Convert array to comma-separated string

        $company_number = $this->request->getVar('company_number'); 
        $language = $this->request->getVar('language'); 
        $bio = $this->request->getVar('bio'); 
        
        $company_address_1 = $this->request->getVar('company_address_1');
        $company_address_1_lat = $this->request->getVar('company_address_1_lat');
        $company_address_1_lon = $this->request->getVar('company_address_1_lon');
        
        $company_address_2 = $this->request->getVar('company_address_2');
        $company_address_2_lat = $this->request->getVar('company_address_2_lat');
        $company_address_2_lon = $this->request->getVar('company_address_2_lon');
        
        
        $company_address_3 = $this->request->getVar('company_address_3');
        $company_address_3_lat = $this->request->getVar('company_address_3_lat');
        $company_address_3_lon = $this->request->getVar('company_address_3_lon');
        
         
         
          $model = new UserModel();
          
           $user = $model->where('id', $user_id)->where('type', 'Provider')->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'Provider  Not Found' , 'status' => "0"], 200);
        }
        
      
         $data =  [
                    'company_name' => $company_name,
                    'company_code' => $company_code,
                    'company_mail' => $company_mail,
                    'company_number' => $company_number,
                    'expertise_service_id' => $expertise_service_id,
                    'language' => $language,
                    'bio' => $bio,
                    'user_type'=>'Company',
                    'year_of_expertise'=>$year_of_expertise,
                    'company_address_1' => $company_address_1,
                    'company_address_1_lat' => $company_address_1_lat,
                    'company_address_1_lon' => $company_address_1_lon,
                    'company_address_2' => $company_address_2,
                    'company_address_2_lat' => $company_address_2_lat,
                    'company_address_2_lon' => $company_address_2_lon,
                    'company_address_3' => $company_address_3,
                    'company_address_3_lat' => $company_address_3_lat,
                    'company_address_3_lon' => $company_address_3_lon,
                    'step'=>1
                    
                 ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/users/" . $img);
                    $data['image'] = $img;
                }
                
                 if (isset($_FILES['upload_company_document'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['upload_company_document']['tmp_name'], "public/uploads/users/" . $img);
                    $data['upload_company_document'] = $img;
                }
                
        $model->where('id', $user_id)->set($data)->update();
        $json['message'] = "Provider Company Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
     public function add_gallery_professional_provider() {
       
        $provider_id = $this->request->getVar('provider_id');
        $model = new UserModel();
          
        $user = $model->where('id', $provider_id)->where('type', 'Provider')->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'Provider  Not Found' , 'status' => "0"], 200);
        }
          
         $model1 = new ProviderGallery();  
         
         $data = ['provider_id' =>$provider_id ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/gallery/" . $img);
                    $data['image'] = $img;
                }
                
        
        $result = $model1->insert($data);
           
           if($result)
           {
              $json['data'] = 'success';
            $json['message'] = "Provider Gallery added Successfully";
            $json['status'] = "1";
            return $this->respond($json);  
           }
        
    }
    
     public function user_register() {
       
        $user_id = $this->request->getVar('user_id');
        $user_name = $this->request->getVar('user_name');
        $email = $this->request->getVar('email');
        $age = $this->request->getVar('age'); 
          
          $model = new UserModel();
          
      $userdata = $model->where('id', $user_id)->where('type', 'User')->where('account_status', 'unverify')->first();

        if ($userdata) {
            return $this->respond(['message' => 'Your Account is Not Verify Please verify your Mobile Number' , 'status' => "0"], 200);
        }
        
          
           $user = $model->where('id', $user_id)->where('type', 'User')->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'User  Not Found' , 'status' => "0"], 200);
        }
        
      
         $data =  [
                    'user_name' => $user_name,
                    'email' => $email,
                    'age' => $age,
                    'step'=>1
                 ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/users/" . $img);
                    $data['image'] = $img;
                }
                
        $model->where('id', $user_id)->set($data)->update();
        $json['message'] = "User Registration Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
    public function register_professional_provider() {
       
        $user_id = $this->request->getVar('provider_id');
        $user_name = $this->request->getVar('user_name');
        $email = $this->request->getVar('email');
        $professional_number = $this->request->getVar('professional_number');
        $year_of_expertise = $this->request->getVar('year_of_expertise');
        $year_of_expertise = $this->request->getVar('year_of_expertise'); 
        
        $expertise_service_idsss = $this->request->getVar('expertise_service_id');
        
        $array = json_decode($expertise_service_idsss, true); // Convert string to array
        $expertise_service_id = implode(',', $array); // Convert array to comma-separated string

       
        $age = $this->request->getVar('age'); 
        $location = $this->request->getVar('location'); 
        $bio = $this->request->getVar('bio'); 
        $lat = $this->request->getVar('lat'); 
        $lon = $this->request->getVar('lon'); 
         
          $model = new UserModel();
          
           $user = $model->where('id', $user_id)->where('type', 'Provider')->where('account_status', 'verify')->first();

        if(is_null($user)) {
            return $this->respond(['message' => 'Provider  Not Found' , 'status' => "0"], 200);
        }
        
         $data =  [
                    'user_name' => $user_name,
                    'email' => $email,
                    'professional_number' => $professional_number,
                    'age' => $age,
                    'year_of_expertise' =>$year_of_expertise,
                    'expertise_service_id' => $expertise_service_id,
                    'address' => $location,
                    'bio' => $bio,
                    'user_type'=>'Professional',
                    'lat' => $lat,
                    'step'=>1,
                    'lon' => $lon
                 ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/users/" . $img);
                    $data['image'] = $img;
                }
                
        $model->where('id', $user_id)->set($data)->update();
        $json['message'] = "Provider Registration Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
      public function delete_company_license()
    {
         
            $model = new UserModel();
            
            // $db      = \Config\Database::connect();
            // $builder = $db->table('users');
            
           $provider_id = $this->request->getVar('provider_id');
           
             $user = $model->where('id', $provider_id)->first(); 
             
            
        if(is_null($user)) {
            return $this->respond(['message' => 'Invalid User','status'=>'0'], 200);
        }
        else
        { 
            
             $data =  ['upload_company_document' =>''];
             
             $model->where('id', $provider_id)->set($data)->update();
             
            return $this->respond(['message' => 'Company License Deleted Successfully','status'=>'1'], 200);
        }
        

        
    }
    

    
    
     public function add_user_view() {
      
        $user_id = $this->request->getVar('user_id');
        
        $provider_id = $this->request->getVar('provider_id');
      
        $model = new UserViewModel();
        
        $umodel = new UserModel();
      
              $data = [
                            'user_id' =>$user_id,
                            'provider_id' => $provider_id
                      ];
                      
                      
                       $result = $model->insert($data);
                      
             $user = $umodel->where('id', $provider_id)->first(); 
             
             $a = $user['review_count'];
             $b = $a+1;
             
         $db      = \Config\Database::connect();
            $builder = $db->table('users');
            
          
             $data = array('review_count' => $b);
            
                $builder->where('id', $provider_id);
                $builder->set($data);
                $builder->update();
           
           if($user)
           {
              $json['data'] = 'success';
            $json['message'] = " added successfully";
            $json['status'] = "1";
            return $this->respond($json);  
           }
           else
           {
              $json['data'] = 'not success';
            $json['message'] = "unsuccessfully";
            $json['status'] = "0";
            return $this->respond($json);  
           }
           
            
        
    }
    
    
     public function provider_number_verification()
            {
                 
                   $userModel = new UserModel();
   
                 $user_id = $this->request->getVar('provider_id');
                
                $otp = $this->request->getVar('otp');
           
        // $user = $userModel->where('email', $email)->first();
        $user = $userModel->where('id', $user_id)->where('type', 'Provider')->first();
   
        if(is_null($user)) {
            return $this->respond(['error' => 'Invalid Provider.','status'=>0], 200);
        }
        
        $userotp = $userModel->where('id', $user_id)->where('otp', $otp)->first();
   
        if(is_null($userotp)) {
            return $this->respond(['error' => 'Do not match Otp','status'=>0], 200);
        }
        
       
            $db      = \Config\Database::connect();
            $builder = $db->table('users');
            
          
             $data = array('account_status' => 'verify' );
            
                $builder->where('id', $user_id);
                $builder->set($data);
                $builder->update();
                
                $userd = $userModel->where('id', $user_id)->where('type', 'Provider')->first();
      
        $response = [
            'message' => ' Succesfully',
            'user_data'=>$userd,
            'status'=>'1'
        ];
          
        return $this->respond($response, 200);
                
        
                
            }
    
    
     public function user_number_verification()
            {
                 
                $userModel = new UserModel();
   
                $user_id = $this->request->getVar('user_id');
                
                $otp = $this->request->getVar('otp');
           
        // $user = $userModel->where('email', $email)->first();
        $user = $userModel->where('id', $user_id)->first();
   
        if(is_null($user)) {
            return $this->respond(['error' => 'ID Not Found','status'=>0], 200);
        }
        
        $userotp = $userModel->where('id', $user_id)->where('otp', $otp)->first();
   
        if(is_null($userotp)) {
            return $this->respond(['error' => 'Do not match otp','status'=>0], 200);
        }
        
       
            $db      = \Config\Database::connect();
            $builder = $db->table('users');
            
          
             $data = array('account_status' => 'verify' );
            
                $builder->where('id', $user_id);
                $builder->set($data);
                $builder->update();
                
                $userd = $userModel->where('id', $user_id)->first();
      
        $response = [
            'message' => ' Succesfully',
            'user_data'=>$userd,
            'status'=>'1'
        ];
          
        return $this->respond($response, 200);
                
        
                
            }
            
            public function check_otp()
            {
                 
                   $userModel = new UserModel();
   
        $user_id = $this->request->getVar('user_id');
        $otp = $this->request->getVar('otp');
           
        // $user = $userModel->where('email', $email)->first();
        $user = $userModel->where('id', $user_id)->first();
   
        if(is_null($user)) {
            return $this->respond(['message' => 'Invalid ID ...','status'=>false], 200);
        }
        
        $userotp = $userModel->where('id', $user_id)->where('otp', $otp)->first();
   
        if(is_null($userotp)) {
            return $this->respond(['message' => 'Do not match Otp ...','status'=>false], 200);
        }
        
      
        $response = [
            'message' => ' Succesfully',
            'user_data'=>$user,
            'status'=>true
        ];
          
        return $this->respond($response, 200);
                
        
                
            }
            
            
              public function update_user_survay() {
       
         $id = $this->request->getVar('user_id');
         
          $model = new UserModel();
          
           $user = $model->where('id', $id)->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'User  Not Found' , 'status' => false], 200);
        }
        

         $data =  [
                    'age' => $this->request->getVar('age'),
                    'gender' => $this->request->getVar('gender'),
                    'pin' => $this->request->getVar('pin'),
                    'yearly_income' => $this->request->getVar('yearly_income'), 
                    'education' => $this->request->getVar('education')
                 ];
             
            
                
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "Survay Updated Successfully";
        $json['status'] = true;
        return $this->respond($json);
    }
            
            
            public function update_profile() {
       
         $id = $this->request->getVar('user_id');
         
         $email = $this->request->getVar('email');
         
          $model = new UserModel();
          
           $user = $model->where('id', $id)->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'User  Not Found' , 'status' => false], 200);
        }
        

         $data =  [
                    'user_name' => $this->request->getVar('user_name'),
                    'mobile' => $this->request->getVar('mobile'),
                     'country_id' => $this->request->getVar('country_id'),
                    //'mobile' => $mobile,
                    'email' =>$email
                 ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/users/" . $img);
                    $data['image'] = $img;
                }
                
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "User Updated Successfully";
        $json['status'] = true;
        return $this->respond($json);
    }
    
    public function update_user_bank_detail() {
       
         $id = $this->request->getVar('user_id');
         
          $model = new UserModel();
          
           $user = $model->where('id', $id)->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'User  Not Found' , 'status' => false], 200);
        }
        

         $data =  [
                    'bank_name' => $this->request->getVar('bank_name'),
                    'account_number' => $this->request->getVar('account_number'),
                     'ifsc_code' => $this->request->getVar('ifsc_code'),
                     'country' => $this->request->getVar('country'),
                     'sort_code' => $this->request->getVar('sort_code')
                    
                 ];
             
             
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "Bank Detail Updated Successfully";
        $json['status'] = true;
        return $this->respond($json);
    }
    
            
             public function log_out()
            {
                 
                $authHeader = $this->request->getHeader("Authorization");
                
                // Check if Authorization header exists
                if (!$authHeader) {
                    $response = ['status' => '0', 'message' => 'Authorization header is missing', 'result' => ''];
                    return $this->respondCreated($response);
                }
            
                $authHeader = $authHeader->getValue();
                $token = $authHeader;
    
        
               $a =  json_decode(base64_decode(str_replace('_', '/', str_replace('-','+',explode('.', $token)[1]))));
               $id1 =  $a->id;
               
               if($id1>0)
               {
                 
                    $userModel = new UserModel();
   
                    $user_id = $this->request->getVar('user_id');
            
                    $user = $userModel->where('id', $user_id)->first();
               
                    if(is_null($user)) {
                        return $this->respond(['message' => 'UnSuccess','status'=>false], 200);
                    }
                    
                    $userotp = $userModel->where('id', $user_id)->first();
                    
                    if($id1 == $user_id)
                    {
                       $response = [
                        'message' => 'You have been successfully logged out!',
                        'status'=>true
                    ];
                      
                    return $this->respond($response, 200); 
                    
                    }
                    else
                    {
                      $response = [
                        'message' => 'Invalid Data',
                        'status'=>false
                    ];
                      
                    return $this->respond($response, 200);  
                    }
                  
                     
               
                   
               }
               
                 
                
    
    
    
                
        
                
            }
            
    public function create_new_password(){
                 
         $userModel = new UserModel();
          $db      = \Config\Database::connect();
            $builder = $db->table('users');
   
        $id = $this->request->getVar('user_id');
        $new_password = password_hash($this->request->getVar('password'), PASSWORD_DEFAULT);

        $user = $userModel->where('id', $id)->first();
        // $user = $userModel->where('email', $email)->orWhere('mobile', $email)->first();
   
        if(is_null($user)) {
            return $this->respond(['message' => 'User Not Found..','status'=>false], 200);
        }
        
             $data = array('password' => $new_password);
             $builder->where('id', $id);
             $builder->set($data);
             $builder->update();
        
      $user = $userModel->where('id', $id)->first();
        $response = [
            'message' => ' Succesfully',
            'user_data'=>$user,
            'status'=>true
        ];
          
        return $this->respond($response, 200);
         }
         
         
         
         
         
         
                
    public function change_password(){
                 
         $userModel = new UserModel();
          $db      = \Config\Database::connect();
            $builder = $db->table('users');
   
        $id = $this->request->getVar('user_id');
        
       $old_password =$this->request->getVar('old_password');
        
        $new_password = password_hash($this->request->getVar('password'), PASSWORD_DEFAULT);

        $user = $userModel->where('id', $id)->first();
        // $user = $userModel->where('email', $email)->orWhere('mobile', $email)->first();
   
        if(is_null($user)) {
            return $this->respond(['error' => 'User Not Found..','status'=>'0'], 200);
        }
        
        
        
        
            if (!password_verify($old_password, $user['password'])) {
        return $this->respond(['error' => 'Password does not match.','status'=>'0'], 200);
    }
    
    $currentDateTime = date("Y-m-d H:i:s");
    
     $data = [
        'user_id' => $this->request->getPost('user_id'),
        'type' => 'Password Changed',
        'message' => "You've completed change the password.",
        'date'=>$currentDateTime
        // Add more columns and values as needed
    ];

    $builder1 = $db->table('notification');
    $builder1->insert($data);
   
   $insertedId = $db->insertID();
   
   

          $data = array('password' => $new_password);
             $builder->where('id', $id);
             $builder->set($data);
             $builder->update();
        
      
        $response = [
            'message' => ' Succesfully',
            'user_data'=>$user,
            'status'=>'1'
        ];
          
        return $this->respond($response, 200);
         }
          
         
        public function get_country(){
               $db      = \Config\Database::connect();
             
              $fetch = $db->query("select * from country  ORDER BY id ASC ")->getResultArray();
              if($fetch){
                 foreach ($fetch as $val) {
                           $data[] = $val;
                       }
            $response = [
            'message' => ' Succesfully',
            'data'=>$data,
            'status'=>true
            ];
          
        return $this->respond($response, 200);
                  
              }else{
                  $response = [
            'message' => ' Unsuccesfully',
            'data'=>[],
            'status'=>false
        ];
          
        return $this->respond($response, 404); 
                  
              
              }
           } 
           
           
           public function get_notification(){
              
               $db      = \Config\Database::connect();
          
               $user_id = $this->request->getVar('user_id');
               
              $fetch = $db->query("SELECT * FROM `notification` WHERE `user_id` = '$user_id' ")->getResultArray();
            //  print_r($fetch);die;
            
              if($fetch){
              
            $response = [
            'message' => ' Succesfully',
            'data'=>$fetch,
            'status'=>'1'
            ];
          
        return $this->respond($response, 200);
                  
              }else{
                  $response = [
            'message' => ' Unsuccesfully',
            'data'=>[],
            'status'=>'0'
        ];
          
        return $this->respond($response, 404); 
                  
              
              }
           }
         
         
          public function get_profile(){
               $db      = \Config\Database::connect();
          
               $user_id = $this->request->getGet('user_id');
               
              $fetch = $db->query("select * from users where id = '$user_id' ")->getResultArray();
              if($fetch){
              
            $response = [
            'message' => ' Succesfully',
            'data'=>$fetch[0],
            'status'=>'1'
            ];
          
        return $this->respond($response, 200);
                  
              }else{
                  $response = [
            'message' => ' Unsuccesfully',
            'data'=>[],
            'status'=>'0'
        ];
          
        return $this->respond($response, 404); 
                  
              
              }
           } 
         
  public function  add_rates() {
      
      
     $db = \Config\Database::connect(); 
     $data = [
        'user_id' => $this->request->getPost('user_id'),
        'owner_id' => $this->request->getPost('owner_id'),
        'rating' => $this->request->getPost('rating'),
        'review' => $this->request->getPost('review'),
        // Add more columns and values as needed
    ];

    $builder = $db->table('rates');
    $builder->insert($data);
   
   $insertedId = $db->insertID();
    // Check if the insertion was successful
    if ($insertedId) {
              $response = [
            'message' => ' Succesfully',
            'data'=>'Data inserted successfully!',
            'status'=>'1'
            ];
          
        return $this->respond($response, 200);
        
        
        
        echo "Data inserted successfully!";
    } else {
             $response = [
            'message' => ' Unsuccesfully',
            'data'=>'data not found',
            'status'=>'0'
        ];
          
        return $this->respond($response, 404); 
    }
}

            public function get_user_rating(){
              
               $db      = \Config\Database::connect();
          
               $user_id = $this->request->getVar('user_id');
               
              $fetch = $db->query("select * from rates where owner_id = '$user_id' ")->getResultArray();
            //  print_r($fetch);die;
              if($fetch){
                   $data[] = '';
                   foreach ($fetch as $val) {
                       $user_id = $val['user_id'];
                       $fetch11 = $db->query("SELECT * FROM users WHERE id = '$user_id' ")->getResultArray();
                       if($fetch11)
                       {
                         $val['name'] =  $fetch11[0]['user_name'];
                           $val['image'] =  base_url() . "public/uploads/users/" . $fetch11[0]['image'];
                           $data[] = $val;  
                       }
                
                       }
                       
              
            $response = [
            'message' => ' Succesfully',
            'data'=>$data,
            'status'=>'1'
            ];
          
        return $this->respond($response, 200);
                  
              }else{
                  $response = [
            'message' => ' Unsuccesfully',
            'data'=>[],
            'status'=>'0'
        ];
          
        return $this->respond($response, 404); 
                  
              
              }
           } 
    
         
}