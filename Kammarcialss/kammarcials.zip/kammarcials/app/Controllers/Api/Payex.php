<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

 use App\Models\UserModel;

class Payex extends ResourceController {
    use ResponseTrait;
    // get all category
  
    public function get_payment_token() {
       
           $url = 'https://sandbox-payexapi.azurewebsites.net/api/Auth/Token';
            $headers = [
             //   'accept: application/json',
                'Authorization: Basic '.base64_encode("nurulhafiza0@gmail.com:VDdDdAXmxyqq5EELBYrIY7S6TAXvFxGt"),
            ];
            
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            
            $result = curl_exec($ch);
  
            if (curl_errno($ch)) {
            $this->session->set_flashdata('msg','invalid details');
     
              echo 'Error:' . curl_error($ch);
            $json = ['result'=>(object)[],'status'=>0,'message'=>'Unsuccessful'];
                 }else{
                 $result = json_decode($result);
                 $json = ['result'=>$result,'status'=>1,'message'=>'Successful'];
                }
          curl_close ($ch);
        
          //  header('Content-type:application/json');
           //  echo json_encode($json);
             return $this->respond($json);
        }
    /**************************************************/
   
    public function payex_payment(){
        
         $booking_id = $this->request->getPost('booking_id');
         $user_id = $this->request->getPost('user_id');
         $model = new UserModel();
         $user = $model->where('id', $user_id)->findAll();
         
         $amount1 = $this->request->getPost('amount');
         $amount = $amount1*100;
         $currency = $this->request->getPost('currency');
         
         $customer_name = $user[0]['user_name'];
         $email = $user[0]['email'];
         $contact_number = $user[0]['mobile'];
         
        //  $return_url = 'https://www.csleaflabs.com/return';
        //  $callback_url = 'https://www.csleaflabs.com/callback';
        //  $accept_url = 'https://www.csleaflabs.com/accepted';
        //  $reject_url = 'https://www.csleaflabs.com/rejected';
         
         $return_url = 'https://server-php-8-2.technorizen.com/nuru/return';
         $callback_url = 'https://server-php-8-2.technorizen.com/nuru/callback';
         $accept_url = 'https://server-php-8-2.technorizen.com/nuru/accepted';
         $reject_url = 'https://server-php-8-2.technorizen.com/nuru//rejected';
        
         
         $expiry_date = $this->request->getPost('expiry_date');
         $description = $this->request->getPost('description');
         $token = $this->request->getPost('token');
        $reference_number = rand(1,9999999999999);
            
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, 'https://sandbox-payexapi.azurewebsites.net/api/v1/PaymentIntents');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "[{\"amount\":$amount,\"currency\":\"$currency\",\"capture\":true,\"customer_name\":\"$customer_name\",\"email\":\"$email\",\"contact_number\":\"$contact_number\",\"description\":\"$description\",\"reference_number\":\"$reference_number\",\"show_payment_types\":false,\"tokenize\":false,\"return_url\":\"$return_url\",\"callback_url\":\"$callback_url\",\"accept_url\":\"$accept_url\",\"reject_url\":\"$reject_url\",\"send_email\":false,\"single_attempt\":false,\"expiry_date\":\"$expiry_date\",\"splits\":[{\"amount\":$amount,\"split_type\":\"abs\",\"destination\":\"contact@payex.io\",\"type\":\"platform\",\"description\":\"Platform commission fees\"}]}]");
         //   curl_setopt($ch, CURLOPT_POSTFIELDS, "[{\"amount\":$amount,\"currency\":\"$currency\",\"capture\":true,\"customer_name\":\"$customer_name\",\"email\":\"$email\",\"contact_number\":\"$contact_number\",\"description\":\"$description\",\"reference_number\":\"$reference_number\",\"payment_type\":\"card\",\"payment_types\":[\"card\"],\"show_payment_types\":false,\"tokenize\":false,\"return_url\":\"$return_url\",\"callback_url\":\"$callback_url\",\"accept_url\":\"$accept_url\",\"reject_url\":\"$reject_url\",\"send_email\":false,\"single_attempt\":false,\"expiry_date\":\"$expiry_date\",\"splits\":[{\"amount\":$amount,\"split_type\":\"abs\",\"destination\":\"contact@payex.io\",\"type\":\"platform\",\"description\":\"Platform commission fees\"}]}]");
         //   curl_setopt($ch, CURLOPT_POSTFIELDS, "[{\"amount\":1000,\"currency\":\"MYR\",\"collection_id\":\"string\",\"capture\":true,\"customer_name\":\"string\",\"email\":\"user@example.com\",\"contact_number\":\"string\",\"address\":\"string\",\"postcode\":\"string\",\"city\":\"string\",\"state\":\"string\",\"country\":\"string\",\"shipping_name\":\"string\",\"shipping_email\":\"user@example.com\",\"shipping_contact_number\":\"string\",\"shipping_address\":\"string\",\"shipping_postcode\":\"string\",\"shipping_city\":\"string\",\"shipping_state\":\"string\",\"shipping_country\":\"string\",\"description\":\"string\",\"reference_number\":\"string\",\"items\":[{\"product_id\":1,\"product_name\":\"test product\",\"price\":10,\"weight\":5}],\"metadata\":{\"id\":1,\"color\":\"blue\"},\"payment_type\":\"card\",\"payment_types\":[\"card\"],\"show_payment_types\":false,\"tokenize\":false,\"card_on_file\":\"string\",\"return_url\":\"string\",\"callback_url\":\"string\",\"accept_url\":\"string\",\"reject_url\":\"string\",\"nonce\":\"string\",\"source\":\"string\",\"send_email\":false,\"single_attempt\":false,\"expiry_date\":\"2024-01-13T09:10:49Z\",\"splits\":[{\"amount\":1000,\"split_type\":\"abs\",\"destination\":\"contact@payex.io\",\"type\":\"platform\",\"description\":\"Platform commission fees\"}]}]");

            $headers = array();
           $headers[] = 'Accept: application/json';
            $headers[] = 'Authorization: Bearer '."$token";
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $result = curl_exec($ch);
    
            if (curl_errno($ch)) {
            $this->session->set_flashdata('msg','invalid details');
     
              echo 'Error:' . curl_error($ch);
            $json = ['result'=>(object)[],'status'=>0,'message'=>'Unsuccessful'];
                 }else{
                 $result = json_decode($result);
                 $json = ['result'=>$result,'status'=>1,'message'=>'Successful'];
                }
          curl_close ($ch);
        
           // header('Content-type:application/json');
         //    echo json_encode($json);
             return $this->respond($json);
    }
  
}
