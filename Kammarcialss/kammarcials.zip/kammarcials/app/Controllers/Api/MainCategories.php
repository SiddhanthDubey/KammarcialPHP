<?php namespace App\Controllers\Api;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\MainCategoryModel;
 
class MainCategories extends ResourceController
{
    use ResponseTrait;
    // get all category
    public function index()
    {
        $model = new MainCategoryModel();
        $data = $model->findAll();
        
        $i=0;
        foreach($data as $data_in){
            $data[$i]['category_image'] =  base_url() . "public/uploads/main_categories/" . $data_in['image'];
            $i++; 
        }
        
        $json = ['result'=>$data,'message'=>'successfull','status'=>'1'];
        
        return $this->respond($json);
    }
    

    
 
    // get single category
    public function show($id = null)
    {
        $model = new MainCategoryModel();
        $data = $model->getWhere(['category_id' => $id])->getResult();
        if($data){
            return $this->respond($data);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
    }
 
    // create a category
    public function create()
    {
        $model = new MainCategoryModel();
        $data = [
            'category_name' => $this->request->getVar('category_name')
        ];
        $model->insert($data);
        $response = [
            'status'   => 201,
            'error'    => null,
            'messages' => [
                'success' => 'Data Saved'
            ]
        ];
        return $this->respondCreated($response);
    }
 
    // update category
    public function update($id = null)
    {
        $model = new MainCategoryModel();
        $input = $this->request->getRawInput();
        $data = [
            'category_name' => $input['category_name'],
        ];
        $model->update($id, $data);
        $response = [
            'status'   => 200,
            'error'    => null,
            'messages' => [
                'success' => 'Data Updated'
            ]
        ];
        return $this->respond($response);
    }
 
    // delete category
    public function delete($id = null)
    {
        $model = new MainCategoryModel();
        $data = $model->find($id);
        if($data){
            $model->delete($id);
            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Data Deleted'
                ]
            ];
            return $this->respondDeleted($response);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
         
    }
 
}