<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\UserAttendenceModel;
use App\Models\UserModel;
use App\Models\EmplyeeLeaveModel;
use App\Models\UserAttendenceHourModel;

use \Firebase\JWT\JWT;

class UserAttendence extends ResourceController {
    use ResponseTrait;
   
   
   public function add_attendence() {
        
         $db = \Config\Database::connect();
         
         $id = $this->request->getPost('user_id');
        
          $attendence_id = $this->request->getPost('attendence_id');
         
          $attendence_hour_id = $this->request->getPost('attendence_hour_id');
 
         $usermodel = new UserModel();
        
        $dr_data = $usermodel->where('id', $id)->findAll();
        if ($dr_data == array()) {
            $json['data'] = array();
            $json['message'] = "User Not Found";
            $json['status'] = "1";
            return $this->respond($json);
        }
        
        
        $model = new UserAttendenceModel();
        
        $time = $this->request->getPost('time');
        
        $date = $this->request->getPost('date');
       
        $type_status = $this->request->getPost('type_status'); //checkin / checkout 
       
        $type = $this->request->getPost('type'); //attendence', 'lunch', 'tea_break'
        
        
        // $data = $db->query("SELECT * FROM `user_attendence` WHERE `user_id` = '$id' AND `user_date_time`= '$date' ")->getResultArray();
        
        
        // $dr_data = $model->where('user_id', $user_id)->where('user_date_time', $date)->where('type_status', $type_status)->findAll();
       
        if($type=='attendence' && $type_status== 'checkout')
        {
        
           $check_in_out_status = 'OFF'; 
           
            $datalunchout = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunchout = new UserModel();
            $modellunchout->where('id', $id)->set($datalunchout)->update();
           
           $datalunchdataa = ['check_out_time' =>$time ];
 
           $model->where('u_id', $attendence_id)->set($datalunchdataa)->update();
           
           $datauserhour6 = ['end_time' => $time ];
        
           $modeluserhour5 = new UserAttendenceHourModel();
       
            $datalunchout11t = ['end_time' => $time ];
           
            $modeluserhour5->where('id', $attendence_hour_id)->set($datalunchout11t)->update();
            
            
            $json['attendence_id'] = '';
            $json['attendence_hour_id'] = '';
            $json['message'] = "Check Out successfully..";
            $json['status'] = "1";
            return $this->respond($json);  
           
            
        }
        
        if($type=='attendence' && $type_status== 'checkin')
        {
         
         $data = [
                    'user_id' => $this->request->getPost('user_id'),
                    'type' => $type,  //attendence', 'lunch', 'tea_break'
                    'check_in_time' => $time ,
                    'description' => '',
                    'type_status' => $type_status, //checkin / checkout 
                    'user_date_time' => $date,
                    'lat' => $this->request->getPost('lat'),
                     'lon' => $this->request->getPost('lon')
        
           ];
        
           $result = $model->insert($data);
           
           $datauserhour = ['user_id' => $id,'check_type'=>'attendence', 'attendence_id' => $result, 'time' => $time , 'date' => $date ];
        
           $modeluserhour = new UserAttendenceHourModel();
           $resultuserhour = $modeluserhour->insert($datauserhour);
           
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
            $datauser = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
            $modeluser = new UserModel();
            $modeluser->where('id', $id)->set($datauser)->update();
        
        
            $json['attendence_id'] = "$result";
            $json['attendence_hour_id'] = "$resultuserhour";
            $json['message'] = "Check In successfully..";
            $json['status'] = "1";
            return $this->respond($json);   
            
        
            
        }
        
        if($type=='lunch' && $type_status== 'checkout') //pending
        {
        
           $check_in_out_status = 'OFF'; 
           
            $datalunchout = ['check_out_type' =>'lunch', 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunchout = new UserModel();
            $modellunchout->where('id', $id)->set($datalunchout)->update();
           
           $datalunchdataa = ['lunch_out_time' =>$time ];
 
           $model->where('u_id', $attendence_id)->set($datalunchdataa)->update();
        
           $modeluserhour5 = new UserAttendenceHourModel();
       
            $datalunchout11t = ['end_time' => $time ];
           
            $modeluserhour5->where('id', $attendence_hour_id)->set($datalunchout11t)->update();
            
            
             $json['attendence_id'] = '';
            $json['attendence_hour_id'] = '';
            $json['message'] = "Check Out successfully";
            $json['status'] = "1";
            return $this->respond($json);  
           
            
        }
        
        if($type=='lunch' && $type_status== 'checkin')
        {
         
         $data = [
                    'user_id' => $this->request->getPost('user_id'),
                    'type' => $type,  //attendence', 'lunch', 'tea_break'
                    'lunch_in_time' => $time ,
                    'description' => '',
                    'type_status' => $type_status, //checkin / checkout 
                    'user_date_time' => $date,
                    'lat' => $this->request->getPost('lat'),
                     'lon' => $this->request->getPost('lon')
        
           ];
        
           $result = $model->insert($data);
           
           $datauserhour = ['user_id' => $id,'check_type'=>'lunch', 'attendence_id' => $result, 'time' => $time , 'date' => $date ];
        
           $modeluserhour = new UserAttendenceHourModel();
           $resultuserhour = $modeluserhour->insert($datauserhour);
           
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
            $datauser = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
            $modeluser = new UserModel();
            $modeluser->where('id', $id)->set($datauser)->update();
        
        
            $json['attendence_id'] = "$result";
            $json['attendence_hour_id'] = "$resultuserhour";
            $json['message'] = "Check In successfully";
            $json['status'] = "1";
            return $this->respond($json);   
            
          
            
        }
        
        
         if($type=='tea_break' && $type_status== 'checkout') //pending
        {
        
           $check_in_out_status = 'OFF'; 
           
            $datalunchout = ['check_out_type' =>'tea_break', 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunchout = new UserModel();
            $modellunchout->where('id', $id)->set($datalunchout)->update();
           
           $datalunchdataa = ['tea_break_out_time' =>$time ];
 
           $model->where('u_id', $attendence_id)->set($datalunchdataa)->update();
        
           $modeluserhour5 = new UserAttendenceHourModel();
       
            $datalunchout11t = ['end_time' => $time ];
           
            $modeluserhour5->where('id', $attendence_hour_id)->set($datalunchout11t)->update();
            
            $json['attendence_id'] = '';
            $json['attendence_hour_id'] = '';
            $json['message'] = "Check Out successfully";
            $json['status'] = "1";
            return $this->respond($json); 
           
            
        }
        
        if($type=='tea_break' && $type_status== 'checkin')
        {
         
         $data = [
                    'user_id' => $this->request->getPost('user_id'),
                    'type' => $type,  //attendence', 'lunch', 'tea_break'
                    'tea_break_in_time' => $time ,
                    'description' => '',
                    'type_status' => $type_status, //checkin / checkout 
                    'user_date_time' => $date,
                    'lat' => $this->request->getPost('lat'),
                     'lon' => $this->request->getPost('lon')
        
           ];
        
           $result = $model->insert($data);
           
           $datauserhour = ['user_id' => $id,'check_type'=>'tea_break', 'attendence_id' => $result, 'time' => $time , 'date' => $date ];
        
           $modeluserhour = new UserAttendenceHourModel();
           $resultuserhour = $modeluserhour->insert($datauserhour);
           
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
            $datauser = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
            $modeluser = new UserModel();
            $modeluser->where('id', $id)->set($datauser)->update();
        
        
            $json['attendence_id'] = "$result";
            $json['attendence_hour_id'] = "$resultuserhour";
            $json['message'] = "Check In successfully";
            $json['status'] = "1";
            return $this->respond($json);   
            
        
            
        }
        
      
        

      
       
        //  if($data)
         
        //  {
        //      $m_id =  $data[0]['u_id'];
            
        //     if($type=='lunch')
        // {
            
        // $modellunch = new UserAttendenceModel();
        
        //   if($type_status== 'checkin')
        // {
        //   $check_out_type = $type; 
        //   $check_in_out_status = 'ON';
           
        
        //   $datalunch = ['lunch_in_time' =>$time ];
           
        //   $modellunch->where('u_id', $m_id)->set($datalunch)->update();
          
        //     $datalunch1 = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
        //     $modellunch1 = new UserModel();
        //     $modellunch1->where('id', $id)->set($datalunch1)->update();
            
            
        //      $datauserhour6755 = ['end_time' => $time ];
        
        //     $modellunchout55 = new UserAttendenceHourModel();
           
        //     $modellunchout55->where('attendence_id', $m_id)->where('check_type','lunch')->set($datauserhour6755)->update();
            
            
        //   $datauserhour67 = ['user_id' => $id, 'type' => 'lunch' ,'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        //   $modeluserhour57 = new UserAttendenceHourModel();
        //   $resultuserhour61 = $modeluserhour57->insert($datauserhour67);
           
          
           
        // }
        
        //   if($type_status== 'checkout')
        // {
        //   $check_out_type = $type; 
        //   $check_in_out_status = 'ON';
           
        //   $datalunch2 = ['lunch_out_time' =>$time ];
         
        //   $modellunch->where('u_id', $m_id)->set($datalunch2)->update();
           
        //   $datalunchout = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
        //     $modellunchout = new UserModel();
        //     $modellunchout->where('id', $id)->set($datalunchout)->update();
            
            
        //   $datauserhour6 = ['user_id' => $id, 'type'=>'attendence' , 'check_type'=>'tea_break' , 'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        //   $modeluserhour5 = new UserAttendenceHourModel();
        //   $resultuserhour6 = $modeluserhour5->insert($datauserhour6);
           
        //     $datalunchout11 = ['end_time' => $time ];
           
        //     $modeluserhour5->where('attendence_id', $m_id)->where('type','lunch')->set($datalunchout11)->update();
           
        // }
        
        
        
          
        // }
        
        
        // if($type=='tea_break')
        // {
           
        // //   $modeltea = new UserAttendenceModel();
        
        // //   if($type_status== 'checkin')
        // // {
        // //   $check_out_type = $type; 
        // //   $check_in_out_status = 'ON';
           
        
        // //   $datalunch = ['tea_break_in_time' =>$time ];
           
        // //   $modeltea->where('u_id', $m_id)->set($datalunch)->update();
          
        // //     $datalunch1 = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
        // //     $modellunch1 = new UserModel();
        // //     $modellunch1->where('id', $id)->set($datalunch1)->update();
            
            
        // //      $datauserhour678 = ['user_id' => $id, 'type' => 'tea_break' ,'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        // //   $modeluserhour578 = new UserAttendenceHourModel();
        // //   $resultuserhour611 = $modeluserhour578->insert($datauserhour678);
           
        // // }
        
        // //   if($type_status== 'checkout')
        // // {
        // //   $check_out_type = $type; 
        // //   $check_in_out_status = 'OFF';
           
        // //   $datalunch2 = ['tea_break_out_time' =>$time ];
         
        // //   $modeltea->where('u_id', $m_id)->set($datalunch2)->update();
           
        // //   $datalunchout = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
        // //     $modellunchout = new UserModel();
        // //     $modellunchout->where('id', $id)->set($datalunchout)->update();
            
            
        // //   $datauserhour6 = ['user_id' => $id,'type'=>'attendence', 'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        // //   $modeluserhour5 = new UserAttendenceHourModel();
        // //   $resultuserhour6 = $modeluserhour5->insert($datauserhour6);
           
        // // }
        
        
        
        // $modeltea = new UserAttendenceModel();
        
        //   if($type_status== 'checkin')
        // {
        //   $check_out_type = $type; 
        //   $check_in_out_status = 'ON';
           
        
        //   $dataluncht = ['tea_break_in_time' =>$time ];
           
        //   $modeltea->where('u_id', $m_id)->set($dataluncht)->update();
          
        //     $datalunch1t = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
        //     $modellunch1t = new UserModel();
        //     $modellunch1t->where('id', $id)->set($datalunch1t)->update();
            
            
        //      $datauserhour6755t = ['end_time' => $time ];
        
        //     $modellunchout55t = new UserAttendenceHourModel();
           
        //     $modellunchout55t->where('attendence_id', $m_id)->where('check_type','tea_break')->set($datauserhour6755t)->update();
            
            
        //   $datauserhour67t = ['user_id' => $id, 'type' => 'tea_break' ,'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        //   $modeluserhour57t = new UserAttendenceHourModel();
        //   $resultuserhour61t = $modeluserhour57t->insert($datauserhour67t);
           
          
           
        // }
        
        //   if($type_status== 'checkout')
        // {
        //   $check_out_type = $type; 
        //   $check_in_out_status = 'ON';
           
        //   $datalunch2t = ['tea_break_out_time' =>$time ];
         
        //   $modeltea->where('u_id', $m_id)->set($datalunch2t)->update();
           
        //   $datalunchoutt = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
        //     $modellunchoutt = new UserModel();
        //     $modellunchoutt->where('id', $id)->set($datalunchoutt)->update();
            
            
        //   $datauserhour6t = ['user_id' => $id, 'type'=>'attendence' , 'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        //   $modeluserhour5t = new UserAttendenceHourModel();
        //   $resultuserhour6t = $modeluserhour5t->insert($datauserhour6t);
           
        //     $datalunchout11t = ['end_time' => $time ];
           
        //     $modeluserhour5t->where('attendence_id', $m_id)->where('type','tea_break')->set($datalunchout11t)->update();
           
        // }
        
        
        
         
           
            
        // }
        
        
        
        
        
        
          
        
        //  }
        
        
      
            
        
    }
    
   
    public function add_attendence18012024() {
        
         $db = \Config\Database::connect();
         
       
        $id = $this->request->getPost('user_id');
        
        
         $usermodel = new UserModel();
        
        $dr_data = $usermodel->where('id', $id)->findAll();
        if ($dr_data == array()) {
            $json['data'] = array();
            $json['message'] = "User Not Found";
            $json['status'] = "1";
            return $this->respond($json);
        }
        
        
        $model = new UserAttendenceModel();
        
        $time = $this->request->getPost('time');
        
        $date = $this->request->getPost('date');
       
        $type_status = $this->request->getPost('type_status'); //checkin / checkout 
       
        $type = $this->request->getPost('type'); //attendence', 'lunch', 'tea_break'
        
        
        $data = $db->query("SELECT * FROM `user_attendence` WHERE `user_id` = '$id' AND `user_date_time`= '$date' ")->getResultArray();

      
       
         if($data)
         
         {
             $m_id =  $data[0]['u_id'];
            
            if($type=='lunch')
        {
            
        $modellunch = new UserAttendenceModel();
        
          if($type_status== 'checkin')
        {
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
        
           $datalunch = ['lunch_in_time' =>$time ];
           
           $modellunch->where('u_id', $m_id)->set($datalunch)->update();
          
            $datalunch1 = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunch1 = new UserModel();
            $modellunch1->where('id', $id)->set($datalunch1)->update();
            
            
             $datauserhour6755 = ['end_time' => $time ];
        
            $modellunchout55 = new UserAttendenceHourModel();
           
            $modellunchout55->where('attendence_id', $m_id)->where('check_type','lunch')->set($datauserhour6755)->update();
            
            
           $datauserhour67 = ['user_id' => $id, 'type' => 'lunch' ,'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
           $modeluserhour57 = new UserAttendenceHourModel();
           $resultuserhour61 = $modeluserhour57->insert($datauserhour67);
           
          
           
        }
        
          if($type_status== 'checkout')
        {
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
           $datalunch2 = ['lunch_out_time' =>$time ];
         
           $modellunch->where('u_id', $m_id)->set($datalunch2)->update();
           
           $datalunchout = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunchout = new UserModel();
            $modellunchout->where('id', $id)->set($datalunchout)->update();
            
            
           $datauserhour6 = ['user_id' => $id, 'type'=>'attendence' , 'check_type'=>'tea_break' , 'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
           $modeluserhour5 = new UserAttendenceHourModel();
           $resultuserhour6 = $modeluserhour5->insert($datauserhour6);
           
            $datalunchout11 = ['end_time' => $time ];
           
            $modeluserhour5->where('attendence_id', $m_id)->where('type','lunch')->set($datalunchout11)->update();
           
        }
        
        
        
          
        }
        
        
        if($type=='tea_break')
        {
           
        //   $modeltea = new UserAttendenceModel();
        
        //   if($type_status== 'checkin')
        // {
        //   $check_out_type = $type; 
        //   $check_in_out_status = 'ON';
           
        
        //   $datalunch = ['tea_break_in_time' =>$time ];
           
        //   $modeltea->where('u_id', $m_id)->set($datalunch)->update();
          
        //     $datalunch1 = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
        //     $modellunch1 = new UserModel();
        //     $modellunch1->where('id', $id)->set($datalunch1)->update();
            
            
        //      $datauserhour678 = ['user_id' => $id, 'type' => 'tea_break' ,'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        //   $modeluserhour578 = new UserAttendenceHourModel();
        //   $resultuserhour611 = $modeluserhour578->insert($datauserhour678);
           
        // }
        
        //   if($type_status== 'checkout')
        // {
        //   $check_out_type = $type; 
        //   $check_in_out_status = 'OFF';
           
        //   $datalunch2 = ['tea_break_out_time' =>$time ];
         
        //   $modeltea->where('u_id', $m_id)->set($datalunch2)->update();
           
        //   $datalunchout = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
        //     $modellunchout = new UserModel();
        //     $modellunchout->where('id', $id)->set($datalunchout)->update();
            
            
        //   $datauserhour6 = ['user_id' => $id,'type'=>'attendence', 'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
        //   $modeluserhour5 = new UserAttendenceHourModel();
        //   $resultuserhour6 = $modeluserhour5->insert($datauserhour6);
           
        // }
        
        
        
        $modeltea = new UserAttendenceModel();
        
          if($type_status== 'checkin')
        {
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
        
           $dataluncht = ['tea_break_in_time' =>$time ];
           
           $modeltea->where('u_id', $m_id)->set($dataluncht)->update();
          
            $datalunch1t = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunch1t = new UserModel();
            $modellunch1t->where('id', $id)->set($datalunch1t)->update();
            
            
             $datauserhour6755t = ['end_time' => $time ];
        
            $modellunchout55t = new UserAttendenceHourModel();
           
            $modellunchout55t->where('attendence_id', $m_id)->where('check_type','tea_break')->set($datauserhour6755t)->update();
            
            
           $datauserhour67t = ['user_id' => $id, 'type' => 'tea_break' ,'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
           $modeluserhour57t = new UserAttendenceHourModel();
           $resultuserhour61t = $modeluserhour57t->insert($datauserhour67t);
           
          
           
        }
        
          if($type_status== 'checkout')
        {
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
           $datalunch2t = ['tea_break_out_time' =>$time ];
         
           $modeltea->where('u_id', $m_id)->set($datalunch2t)->update();
           
           $datalunchoutt = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunchoutt = new UserModel();
            $modellunchoutt->where('id', $id)->set($datalunchoutt)->update();
            
            
           $datauserhour6t = ['user_id' => $id, 'type'=>'attendence' , 'attendence_id' => $m_id, 'time' => $time , 'date' => $date ];
        
           $modeluserhour5t = new UserAttendenceHourModel();
           $resultuserhour6t = $modeluserhour5t->insert($datauserhour6t);
           
            $datalunchout11t = ['end_time' => $time ];
           
            $modeluserhour5t->where('attendence_id', $m_id)->where('type','tea_break')->set($datalunchout11t)->update();
           
        }
        
        
        
         
           
            
        }
        
        
        
        if($type=='attendence')
        {
           
           
           
            $modelattendence = new UserAttendenceModel();
        
          if($type_status== 'checkin')
        {
            echo 'e';
           
        }
        
          if($type_status== 'checkout')
        {
           $check_out_type = $type; 
           $check_in_out_status = 'OFF'; 
           
           $datalunchdataa = ['check_out_time' =>$time ];
           
          
         
           $modelattendence->where('u_id', $m_id)->set($datalunchdataa)->update();
           
       //where('type','attendence')->where('check_type','attendence')
           
           $datalunchout = ['check_out_type' =>'attendence', 'check_in_out_status' => $check_in_out_status  ];
            
            $modellunchout = new UserModel();
            $modellunchout->where('id', $id)->set($datalunchout)->update();
            
            
           $datauserhour6 = ['end_time' => $time ];
        
           $modeluserhour5 = new UserAttendenceHourModel();
        //   $resultuserhour6 = $modeluserhour5->insert($datauserhour6);
           
           
            $datalunchout11t = ['end_time' => $time ];
           
            $modeluserhour5->where('attendence_id', $m_id)->where('type','attendence')->where('check_type','attendence')->set($datalunchout11t)->update();
           
        }
        
        
            
        }
        
        
          
        
         }
         else // CURRENT INSERT DATA
         {
              $data = [
                    'user_id' => $this->request->getPost('user_id'),
                    'type' => $type, 
                    'check_in_time' => $time ,
                    'description' => '',
                    'type_status' => $type_status,
                    'user_date_time' => $date,
                    'lat' => $this->request->getPost('lat'),
                     'lon' => $this->request->getPost('lon')
        
        ];
        
           $result = $model->insert($data);
           
           
           $datauserhour = ['user_id' => $id,'check_type'=>'lunch', 'attendence_id' => $result, 'time' => $time , 'date' => $date ];
        
           $modeluserhour = new UserAttendenceHourModel();
           $resultuserhour = $modeluserhour->insert($datauserhour);
           
        
               if($type_status== 'checkin')
        {
           $check_out_type = $type; 
           $check_in_out_status = 'ON';
           
        }
        
        $datauser = ['check_out_type' =>$check_out_type, 'check_in_out_status' => $check_in_out_status  ];
        
        $modeluser = new UserModel();
        $modeluser->where('id', $id)->set($datauser)->update();
       
         }
        
          
      
       
            
            $json['data'] = 'success';
            $json['message'] = "Attendence added successfully";
            $json['status'] = "1";
            return $this->respond($json);
        
    }
    
    
    
     public function add_leave() {
      
        $user_id = $this->request->getPost('user_id');
        
        $leave_from_date = $this->request->getPost('leave_from_date');
        
        $leave_to_date = $this->request->getPost('leave_to_date');
       
        $reason = $this->request->getPost('reason'); 
      
        $model = new EmplyeeLeaveModel();
      
              $data = [
                            'user_id' =>$user_id,
                            'leave_from_date' => $leave_from_date, 
                            'leave_to_date' => $leave_to_date ,
                            'reason' => $reason
                     ];
        
           $result = $model->insert($data);
           
           if($result)
           {
              $json['data'] = 'success';
            $json['message'] = "Leave added successfully";
            $json['status'] = "1";
            return $this->respond($json);  
           }
           else
           {
              $json['data'] = 'not success';
            $json['message'] = "unsuccessfully";
            $json['status'] = "0";
            return $this->respond($json);  
           }
           
            
           
        
    }
    
    public function get_terms_condition() {
       
     
        $db = \Config\Database::connect();
        $user_id = $this->request->getVar('user_id');
        
        $data = $db->query("SELECT * FROM `about_privacy` WHERE `id` = '4' ")->getResultArray();

        $doctor_out = array();
        foreach ($data as $data_in) {
           
              $data_in1['id'] = $data_in['id'];
               $data_in1['name'] = $data_in['name'];
                $data_in1['description'] = $data_in['description'];
              
          
           
          
            $doctor_out[] = $data_in1;
        }
        if ($doctor_out != array()) {
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    public function get_about_us() {
       
     
        $db = \Config\Database::connect();
        $user_id = $this->request->getVar('user_id');
        
        $data = $db->query("SELECT * FROM `about_privacy` WHERE `id` = '1' ")->getResultArray();

        $doctor_out = array();
        foreach ($data as $data_in) {
           
              $data_in1['id'] = $data_in['id'];
               $data_in1['name'] = $data_in['name'];
                $data_in1['description'] = $data_in['description'];
              
          
           
          
            $doctor_out[] = $data_in1;
        }
        if ($doctor_out != array()) {
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    public function get_privacy_policy() {
       
     
        $db = \Config\Database::connect();
        $user_id = $this->request->getVar('user_id');
        
        $data = $db->query("SELECT * FROM `about_privacy` WHERE `id` = '3' ")->getResultArray();

        $doctor_out = array();
        foreach ($data as $data_in) {
           
              $data_in1['id'] = $data_in['id'];
               $data_in1['name'] = $data_in['name'];
                $data_in1['description'] = $data_in['description'];
              
          
           
          
            $doctor_out[] = $data_in1;
        }
        if ($doctor_out != array()) {
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    
     public function get_user_leave() {
       
     
        $db = \Config\Database::connect();
        $user_id = $this->request->getVar('user_id');
        
        $data = $db->query("SELECT * FROM `emplyee_leave` WHERE `user_id` = '$user_id'  ORDER BY `li_id` DESC ")->getResultArray();

        $doctor_out = array();
        foreach ($data as $data_in) {
           
        //   $intimacy_category_id = $data_in['user_date_time'];
        //   if($saveblogs){
        //       $data_in['saved'] = 'Yes';
        //   } else {
        //       $data_in['saved'] = 'No';
        //   }
           
          
            $doctor_out[] = $data_in;
        }
        if ($doctor_out != array()) {
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    public function get_current_day() {
       
        $currentDate = date("Y-m-d");
      // echo $currentDate; die;

     
        $db = \Config\Database::connect();
        $user_id = $this->request->getVar('user_id');
        
        $data = $db->query(" SELECT * FROM `user_attendence_time` WHERE `user_id` = '$user_id' AND `date` = '$currentDate'  ORDER BY `id` DESC  ")->getResultArray();

        $doctor_out = array();
        foreach ($data as $data_in) {
           
        //   $intimacy_category_id = $data_in['user_date_time'];
        //   if($saveblogs){
        //       $data_in['saved'] = 'Yes';
        //   } else {
        //       $data_in['saved'] = 'No';
        //   }
           
          
            $doctor_out[] = $data_in;
        }
        if ($doctor_out != array()) {
          
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    public function get_date_wise_data() {
       
       $currentDate = $this->request->getVar('date');
       $user_id = $this->request->getVar('user_id');
      //  $currentDate = date("Y-m-d");
      // echo $currentDate; die;

     
        $db = \Config\Database::connect();
        
        
        $data = $db->query(" SELECT * FROM `user_attendence_time` WHERE `user_id` = '$user_id' AND `date` = '$currentDate' ORDER BY `id` DESC  ")->getResultArray();

        $doctor_out = array();
        foreach ($data as $data_in) {
           
        //   $intimacy_category_id = $data_in['user_date_time'];
        //   if($saveblogs){
        //       $data_in['saved'] = 'Yes';
        //   } else {
        //       $data_in['saved'] = 'No';
        //   }
           
          
            $doctor_out[] = $data_in;
        }
        if ($doctor_out != array()) {
          
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
     public function get_user_count_time() {
         
        $db = \Config\Database::connect();
         
        $user_id = $this->request->getVar('user_id');
        
        $currentDatetime = $this->request->getVar('date_time');
       
        $currentDate = date("Y-m-d");
       
       // $currentDatetime = date("Y-m-d H:i:s");

        $data = $db->query(" SELECT * FROM `user_attendence_time` WHERE `user_id` = '$user_id' AND `date` = '$currentDate'  ")->getResultArray();
        
       
        
        if($data)
        
        {
            $end_time1 =  $data[0]['end_time'];
            //  print_r($end_time1);die;
            
            if($end_time1== '')
            {
               
               $duration = $db->query(" SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(TIMEDIFF('$currentDatetime', time)))) AS total_duration FROM user_attendence_time  WHERE `user_id` = '$user_id'  AND date = '$currentDate' ")->getResultArray();
                      
            }
            else
            {
               
                // $duration = $db->query(" SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(TIMEDIFF(end_time, time)))) AS total_duration FROM user_attendence_time
                //   WHERE `user_id` = '$user_id' AND date = '$currentDate' ")->getResultArray();
                
            $duration = $db->query("SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(IF(end_time IS NULL, TIMEDIFF('$currentDatetime', `time`), TIMEDIFF(end_time, `time`))    ))) AS total_duration FROM user_attendence_time 
                  WHERE `user_id` = '$user_id' AND `date` = '$currentDate'  ")->getResultArray();    
                  
           
            }
               
            $json['work_hour'] = $duration[0]['total_duration'];
           
            $json['message'] = " Successfully";
            $json['status'] = "1";
            
             return $this->respond($json);
             
        }
        else
        {
            $json['work_hour'] = '00:00:00';
           
            $json['message'] = " Successfully";
            $json['status'] = "1";
            
             return $this->respond($json);
        }

        

        
        
          if($duration){
              $data_in['duration'] = $duration[0]['total_duration'];
          } else {
              $data_in['duration'] = '00:00:00';
          }
           
          
            $doctor_out[] = $data_in;
        
        if ($doctor_out != array()) {
            $json['available'] = 14;
            $json['half_day'] = 20;
            $json['total_daya'] = 25;
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    public function get_user_all_data() {
       
       
        $db = \Config\Database::connect();
        $user_id = $this->request->getVar('user_id');
        $from_date = $this->request->getVar('from_date');
        $to_date = $this->request->getVar('to_date');
        
        $data = $db->query(" SELECT * FROM `user_attendence_time` WHERE `user_id` = '$user_id' AND `date` BETWEEN '$from_date' AND '$to_date' GROUP BY `date` ORDER BY id DESC  ")->getResultArray();

        $doctor_out = array();
        foreach ($data as $data_in) {
            
           $date =  $data_in['date'];
           
        $duration = $db->query(" SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(TIMEDIFF(end_time, time)))) AS total_duration FROM user_attendence_time
                   WHERE `user_id` = '$user_id' AND `type` = 'attendence' AND date = '$date' ")->getResultArray();

        
          if($duration){
              $data_in['duration'] = $duration[0]['total_duration'];
          } else {
              $data_in['duration'] = '00:00:00';
          }
          
            $doctor_out[] = $data_in;
        }
        if ($doctor_out != array()) {
         
            $json['result'] = $doctor_out;
            $json['message'] = " List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    
   
    
    
    public function get_profile()
    {
        $type = 'user';//$this->request->getVar('type');
        $id = $this->request->getVar('user_id');

         $model = new UserModel();
       
         $user = $model->where('id', $id)->first();
         
        if (is_null($user)) {
            return $this->respond(['message' => 'Invalid username or password.' , 'status' => "0"], 200);
        }

        $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);

       
        $user['image'] =  base_url() . "public/uploads/users/" . $user['image'];

       
        $email =  $user['email'];
        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
           
            'user_type' => $type,
        ];

        
        $token = JWT::encode($payload, $key, 'HS256');
         
              $response = [
            'message' => 'Login Successful',
            'token' => $token,
            'user_data' => $user,
            'status' => '1',
           
            
        ]; 
          
         

        return $this->respond($response, 200);
    }
    
    // update doctor
    public function update_doctor_by_id() {
        $id = $this->request->getVar('doctor_id');
        $model = new DoctorModel();
        $data = ['doctor_product_id' => $this->request->getVar('product_id'), 'doctor_user_id' => $this->request->getVar('user_id'), 'doctor_quantity' => ($this->request->getVar('doctor_quantity') == "") ? 0 : $this->request->getVar('doctor_quantity'), ];
        $model->where('doctor_id', $id)->set($data)->update();
        $json['message'] = "Doctor Updated Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    public function update_profile() {
        $id = $this->request->getVar('user_id');
       
         $model = new UserModel();   
       
        
        $data =  [
                    'user_name' => $this->request->getVar('user_name'),
                    
                    'dob' => $this->request->getVar('dob'),
                    'mobile' => $this->request->getVar('mobile'),
                    'gender' => $this->request->getVar('gender')
                 ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/users/" . $img);
                    $data['image'] = $img;
                }
                
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "User Updated Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    /**********************************/
    public function update_user_profile() {
        $id = $this->request->getVar('user_id');
            $model = new UserModel();
        $data = [
                    'user_name' => $this->request->getVar('user_name'),
                    'company_name' => $this->request->getVar('company_name'),
                    'mobile' => $this->request->getVar('mobile'),
                    'gender' => $this->request->getVar('gender'),
                    'dob' => $this->request->getVar('dob'),
                    'email' => $this->request->getVar('email'),
                    'country_code' => $this->request->getVar('country_code'),
                   
             ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/users/" . $img);
                    $data['image'] = $img;
                }
                
             $update=   $model->where('id', $id)->set($data)->update();
                if($update) { 
                $json['message'] = "Users Updated Successfully";
                $json['status'] = "1"; 
                } else {
                 $json['message'] = "Something Went Wrong Try Again latter";
                $json['status'] = "0"; 
                }
                return $this->respond($json);
    }
    /***********************************************/
    public function delete_doctor_by_id() {
        $id = $this->request->getVar('doctor_id');
        $model = new DoctorModel();
        //$data = $model->find($id);
        $model->delete($id);
        $json['message'] = "Product Delete Success.";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
   
    
    
    public function booking_add_extra() {
        $id = $this->request->getPost('doctors_booking_doctors_id');
        $model = new DoctorModel();
        $dr_data = $model->where('id', $id)->findAll();
        if ($dr_data == array()) {
            $json['data'] = array();
            $json['message'] = "Doctor Not Found";
            $json['status'] = "1";
            return $this->respond($json);
        }
        $modelextra = new DoctorsBookingModelExtra();
        // Get data from Postman request
        $data = [
            'doctors_booking_doctors_id' => $this->request->getPost('doctors_booking_doctors_id'),
            'doctors_booking_date' => $this->request->getPost('doctors_booking_date'),
            'doctors_booking_time' => $this->request->getPost('doctors_booking_time'),
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'amount' => $this->request->getPost('amount'),
            'personal_trainer_cat_id' => $this->request->getPost('personal_trainer_cat_id'),
            'description' => $this->request->getPost('description'),
            'client_surname' => $this->request->getPost('client_surname'),
            'client_number' => $this->request->getPost('client_number') ];
        // Insert data into the database
        $result = $modelextra->insert($data);
        if ($result) {
            $json['data'] = $data;
            $json['message'] = "Booking added successfully";
            $json['status'] = "1";
            return $this->respond($json);
        } else {
            $json['data'] = array();
            $json['message'] = "Failed";
            $json['status'] = "0";
            return $this->respond($json);
        }
    }
    
   
   
    
   
   
    
 public function get_booking_by_users_id()
    {
        $users_id = $this->request->getVar('users_id');

        
        $model = new DoctorsBookingModel();

        // Get bookings based on users_id
        $bookings = $model->where('doctors_booking_users_id', $users_id)->findAll();

        $json['data'] = $bookings;
        $json['message'] = "Bookings retrieved successfully";
        $json['status'] = "1";

        return $this->respond($json);
    }

    
    
    
    public function get_doctor_availability()
    {
        
        $doctor_id = $this->request->getVar('doctor_id');
        
        $model = new DoctorAavailabilityModel();

      
        $data = $model->where('doctor_id', $doctor_id)->findAll();
         $i = 0;
        $doctor_out = array();
        foreach ($data as $data_in) {
          
            $doctor_out[] = $data_in;
        }
        if ($doctor_out != array()) {
            $json['result'] = $doctor_out;
            $json['message'] = "Doctor Aavailability Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
   /******************************************/ 
    public function delete_account()
    {
        $type = $this->request->getVar('type');
        $id = $this->request->getVar('id');

        $model = null;

        switch ($type) {
            case 'user':
                $model = new UserModel();
                break;
            case 'doctor':
                $model = new DoctorModel();
                break;
                case 'lab':
                $model = new LabModel();
                break;
            case 'trainer':
                $model = new PersonalTrainerModel();
                break;
            default:
                return $this->fail('Invalid user type', 400);
        }

        $deleted = $model->where(['id' => $id])->delete();
        $josn = array();
        if ($deleted) {
            $josn['result'] = array();
            $josn['message'] = "Deleted successfully";
            $josn['status'] = "1";
        } else {
            $josn['result'] = array();
            $josn['message'] = "Failed to delete";
            $josn['status'] = "0";
        }
        return $this->respond($josn);
        
        
    }
    
}
