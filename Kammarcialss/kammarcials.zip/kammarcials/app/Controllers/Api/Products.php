<?php namespace App\Controllers\Api;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ProductModel;
 
class Products extends ResourceController
{
    use ResponseTrait;
    // get all product
    public function index()
    {
       $model = new ProductModel();
        $data = $model->findAll();
        
        $i=0;
        foreach($data as $data_in){
            $data[$i]['product_image'] =  base_url() . "public/uploads/products/" . $data_in['product_image'];
            $i++; 
        }
        
        return $this->respond($data);
    }
 
    // get single product
    public function show($id = null)
    {
        $model = new ProductModel();
        $data = $model->getWhere(['product_id' => $id])->getResult();
        if($data){
            return $this->respond($data);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
    }
    
        public function products_by_category_id()
    {
        $model = new ProductModel();
        
        $category_id = $this->request->getVar('category_id');

        $data = $model->where('product_category_id',$category_id)->findAll();
        
        $i=0;
        foreach($data as $data_in){
            $data[$i]['product_image'] =  base_url() . "public/uploads/products/" . $data_in['product_image'];
            $i++; 
        }
        
        if($data == array()){
        $json['category'] = array();
        $json['message'] = 'Category List Not Found.';
        $json['status'] = '0';
        }else{
        $json['category'] = $data;
        $json['message'] = 'Category List Successfully.';
        $json['status'] = '1';
        }

        
        return $this->respond($json);
    }
 
 
         public function products_by_id()
    {
        $model = new ProductModel();
        
        $product_id = $this->request->getVar('product_id');

        $data = $model->where('product_id',$product_id)->findAll();
        
        $i=0;
        foreach($data as $data_in){
            $data[$i]['product_image'] =  base_url() . "public/uploads/products/" . $data_in['product_image'];
            $i++; 
        }
        
        if($data == array()){
        $json['product'] = NULL; //new \stdClass();
        $json['message'] = 'Product Not Found.';
        $json['status'] = '0';
        }else{
        $json['product'] = $data[0];
        $json['message'] = 'Product List Successfully.';
        $json['status'] = '1';
        }

        
        return $this->respond($json);
    }
    
 
    
 
    // create a product
    public function create()
    {
        $model = new ProductModel();
        $data = [
            'product_name' => $this->request->getVar('product_name'),
            'product_price' => $this->request->getVar('product_price')
        ];
        $model->insert($data);
        $response = [
            'status'   => 201,
            'error'    => null,
            'messages' => [
                'success' => 'Data Saved'
            ]
        ];
        return $this->respondCreated($response);
    }
 
    // update product
    public function update($id = null)
    {
        $model = new ProductModel();
        $input = $this->request->getRawInput();
        $data = [
            'product_name' => $input['product_name'],
            'product_price' => $input['product_price']
        ];
        $model->update($id, $data);
        $response = [
            'status'   => 200,
            'error'    => null,
            'messages' => [
                'success' => 'Data Updated'
            ]
        ];
        return $this->respond($response);
    }
 
    // delete product
    public function delete($id = null)
    {
        $model = new ProductModel();
        $data = $model->find($id);
        if($data){
            $model->delete($id);
            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Data Deleted'
                ]
            ];
            return $this->respondDeleted($response);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
         
    }
 
}