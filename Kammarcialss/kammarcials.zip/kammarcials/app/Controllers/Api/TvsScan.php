<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\TvsScanModel;
use App\Models\TrainerTypeModel;


class TvsScan extends ResourceController {
    use ResponseTrait;
    // get all category
    
    public function get_trainer_type_list() {
        
        $model = new TrainerTypeModel();
        $data = $model->findAll();
        $i = 0;
        $doctor_out = array();
        foreach ($data as $data_in) {
            $data_in1['id'] =$data_in['id'];
            $data_in1['name'] =$data_in['name'];
            $i++;
            $doctor_out[] = $data_in1;
        }
        if ($doctor_out != array()) {
            $json['doctor'] = $doctor_out;
            $json['message'] = "Data get Successfully";
            $json['status'] = "1";
        } else {
            $json['doctor'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    public function get_scan_clinic_List() {
        
        $model = new TvsScanModel();
        $data = $model->findAll();
        $i = 0;
        $doctor_out = array();
        foreach ($data as $data_in) {
            $data_in1['id'] =$data_in['id'];
            $data_in1['clinic_name'] =$data_in['clinic_name'];
            $data_in1['clinic_image'] = base_url() . "public/uploads/tvs_scan/" . $data_in['clinic_image'];
            $i++;
            $doctor_out[] = $data_in1;
        }
        if ($doctor_out != array()) {
            $json['doctor'] = $doctor_out;
            $json['message'] = "Tvs Scan List Successfully";
            $json['status'] = "1";
        } else {
            $json['doctor'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    
    public function get_scan_clinic_detail1() {
        $id = $this->request->getVar('clinic_id');
        $model = new TvsScanModel();
        $data = $model->where('id', $id)->findAll();
        $doctor_out = array();
        foreach ($data as $data_in) {
            $doctor_out = $data_in;
            $doctor_out['clinic_image'] = base_url() . "public/uploads/tvs_scan/" . $data_in['clinic_image'];
            
        }
        if ($doctor_out == array()) {
            $json['doctor'] = new \stdClass();
            $json['message'] = "Data Not Found";
            $json['status'] = "1";
        } else {
            $json['doctor'] = $doctor_out;
            $json['message'] = "Data Found Successfully";
            $json['status'] = "1";
        }
        return $this->respond($json);
    }
    
    public function get_scan_clinic_detail()
    {
        
        $booking_id = $this->request->getVar('clinic_id');
        
        $model = new TvsScanModel();

        $bookings = $model->where('id', $booking_id)->findAll();
        $bookings[0]['clinic_image'] = base_url() . "public/uploads/tvs_scan/" . $bookings[0]['clinic_image'];

    
        
           if ($bookings) {
        $json['data'] = $bookings[0];
        $json['message'] = "Bookings Detail";
        $json['status'] = "1";
            return $this->respond($json);
        } else {
            $json['data'] = (object)[];
            $json['message'] = "Failed";
            $json['status'] = "0";
            return $this->respond($json);
        }
        

        return $this->respond($json);
    }
    
   
    
    // update doctor
    public function update_doctor_by_id() {
        $id = $this->request->getVar('doctor_id');
        $model = new DoctorModel();
        $data = ['doctor_product_id' => $this->request->getVar('product_id'), 'doctor_user_id' => $this->request->getVar('user_id'), 'doctor_quantity' => ($this->request->getVar('doctor_quantity') == "") ? 0 : $this->request->getVar('doctor_quantity'), ];
        $model->where('doctor_id', $id)->set($data)->update();
        $json['message'] = "Doctor Updated Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    public function update_doctor_profile() {
        $id = $this->request->getVar('user_id');
        $type = $this->request->getVar('type');
        if($type=='doctor')
        {
         $model = new DoctorModel();   
        }
        
        $data = [
                    'name' => $this->request->getVar('name'),
                    'last_name' => $this->request->getVar('last_name'),
                    'year_of_experience' => $this->request->getVar('year_of_experience'),
                    'consult_fee' => $this->request->getVar('consult_fee'),
                    'education' => $this->request->getVar('education'),
                    'dob' => $this->request->getVar('dob'),
                    'nationality' => $this->request->getVar('nationality'),
                    'address' => $this->request->getVar('address'),
                    'about_me' => $this->request->getVar('about_me'),
                    'identification_card_no' => $this->request->getVar('identification_card_no'),
                    // 'upload_medicale_licences' => $this->request->getVar('upload_medicale_licences'),
                    'languages' => $this->request->getVar('languages'),
                     'type' => $type,
                     'verify_status' => 1,
                    'description' => $this->request->getVar('description')
                    
             ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/doctors/" . $img);
                    $data['image'] = $img;
                }
                if (isset($_FILES['upload_medicale_licences'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['upload_medicale_licences']['tmp_name'], "public/uploads/doctors/" . $img);
                    $data['upload_medicale_licences'] = $img;
                }
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "Doctor Updated Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    public function delete_doctor_by_id() {
        $id = $this->request->getVar('doctor_id');
        $model = new DoctorModel();
        //$data = $model->find($id);
        $model->delete($id);
        $json['message'] = "Product Delete Success.";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
    public function booking_add() {
        $id = $this->request->getPost('doctors_booking_doctors_id');
        $model = new DoctorModel();
        $dr_data = $model->where('id', $id)->findAll();
        if ($dr_data == array()) {
            $json['data'] = array();
            $json['message'] = "Doctor Not Found";
            $json['status'] = "1";
            return $this->respond($json);
        }
        $model = new DoctorsBookingModel();
        // Get data from Postman request
        $data = ['doctors_booking_doctors_id' => $this->request->getPost('doctors_booking_doctors_id'), 'doctors_booking_date' => $this->request->getPost('doctors_booking_date'), 'doctors_booking_time' => $this->request->getPost('doctors_booking_time'), 'doctors_booking_created_at' => $this->request->getPost('doctors_booking_created_at'), 'doctors_booking_updated_at' => $this->request->getPost('doctors_booking_updated_at'), 'doctors_booking_users_id' => $this->request->getPost('doctors_booking_users_id'), 'doctors_booking_price_when_purchase' => $dr_data[0]['consult_fee']];
        // Insert data into the database
        $result = $model->insert($data);
        if ($result) {
            $json['data'] = $data;
            $json['message'] = "Booking added successfully";
            $json['status'] = "1";
            return $this->respond($json);
        } else {
            $json['data'] = array();
            $json['message'] = "Failed";
            $json['status'] = "0";
            return $this->respond($json);
        }
    }
    
    
    public function booking_add_extra() {
        $id = $this->request->getPost('doctors_booking_doctors_id');
        $model = new DoctorModel();
        $dr_data = $model->where('id', $id)->findAll();
        if ($dr_data == array()) {
            $json['data'] = array();
            $json['message'] = "Doctor Not Found";
            $json['status'] = "1";
            return $this->respond($json);
        }
        $modelextra = new DoctorsBookingModelExtra();
        // Get data from Postman request
        $data = [
            'doctors_booking_doctors_id' => $this->request->getPost('doctors_booking_doctors_id'),
            'doctors_booking_date' => $this->request->getPost('doctors_booking_date'),
            'doctors_booking_time' => $this->request->getPost('doctors_booking_time'),
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'amount' => $this->request->getPost('amount'),
            'personal_trainer_cat_id' => $this->request->getPost('personal_trainer_cat_id'),
            'description' => $this->request->getPost('description'),
            'client_surname' => $this->request->getPost('client_surname'),
            'client_number' => $this->request->getPost('client_number') ];
        // Insert data into the database
        $result = $modelextra->insert($data);
        if ($result) {
            $json['data'] = $data;
            $json['message'] = "Booking added successfully";
            $json['status'] = "1";
            return $this->respond($json);
        } else {
            $json['data'] = array();
            $json['message'] = "Failed";
            $json['status'] = "0";
            return $this->respond($json);
        }
    }
    
     public function get_extra_booking_by_doctors_id()
    {
        
        $doctors_id = $this->request->getVar('trainer_id');
        
        $personal_trainer_cat_id = $this->request->getVar('personal_trainer_cat_id');
        
        
        $model = new DoctorsBookingModelExtra();
        
        if($personal_trainer_cat_id>0)
        {
          $bookings = $model->where('doctors_booking_doctors_id', $doctors_id)
                            ->where('personal_trainer_cat_id', $personal_trainer_cat_id)->findAll();  
        }
        else
        {
            $bookings = $model->where('doctors_booking_doctors_id', $doctors_id)->findAll();
        }

        

    
        
           if ($bookings) {
        //      $i=0;  
        //         $doctor_out = array();
        // foreach ($bookings as $data_in) {
        //     $doctor_out = $data_in;
        //     $doctor_out[$i]['image'] = base_url() . "public/uploads/personal_trainers/no_image.png";
        //     $i++;
        // }
        
        $i=0;
        $doctor_out = array();
        foreach ($bookings as $data_in) {
            
            $data_in['image'] = base_url() . "public/uploads/doctors/no_image.png";
            $doctor_out[$i] = $data_in;
            $i++;
        }
          
               
        $json['data'] = $doctor_out;
        $json['message'] = "Bookings retrieved successfully";
        $json['status'] = "1";
            return $this->respond($json);
        } else {
            $json['data'] = array();
            $json['message'] = "Failed";
            $json['status'] = "0";
            return $this->respond($json);
        }
        

        return $this->respond($json);
    }
    
    public function get_extra_booking_detail()
    {
        
        $booking_id = $this->request->getVar('booking_id');
        
        $model = new DoctorsBookingModelExtra();

        $bookings = $model->where('doctors_booking_id', $booking_id)->findAll();

    
        
           if ($bookings) {
        $json['data'] = $bookings[0];
        $json['message'] = "Bookings Detail";
        $json['status'] = "1";
            return $this->respond($json);
        } else {
            $json['data'] = (object)[];
            $json['message'] = "Failed";
            $json['status'] = "0";
            return $this->respond($json);
        }
        

        return $this->respond($json);
    }

    

    
    
    
    
 public function get_booking_by_users_id()
    {
        $users_id = $this->request->getVar('users_id');

        
        $model = new DoctorsBookingModel();

        // Get bookings based on users_id
        $bookings = $model->where('doctors_booking_users_id', $users_id)->findAll();

        $json['data'] = $bookings;
        $json['message'] = "Bookings retrieved successfully";
        $json['status'] = "1";

        return $this->respond($json);
    }

    public function get_booking_by_doctors_id()
    {
        
        $doctors_id = $this->request->getVar('doctors_id');
        
        $model = new DoctorsBookingModel();

        $bookings = $model->where('doctors_booking_doctors_id', $doctors_id)->findAll();

    
        
           if ($bookings) {
        $json['data'] = $bookings;
        $json['message'] = "Bookings retrieved successfully";
        $json['status'] = "1";
            return $this->respond($json);
        } else {
            $json['data'] = array();
            $json['message'] = "Failed";
            $json['status'] = "0";
            return $this->respond($json);
        }
        

        return $this->respond($json);
    }

    
}
