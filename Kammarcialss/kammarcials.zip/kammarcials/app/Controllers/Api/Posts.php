<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\PostModel;
class Posts extends ResourceController {
    use ResponseTrait;
    // get all category
    public function index() {
        $model = new PostModel();
        
        $type = $this->request->getVar('type');
        $sub_category_id = $this->request->getVar('sub_category_id');
         
        $data = $model->where('post_type',$type)->where('post_sub_category',$sub_category_id)->findAll();

        $i = 0;
        $post_out = array();
        foreach ($data as $data_in) {
                $post_out[$i] =  $data_in;
                $post_out[$i]['post_video'] =  base_url() . "public/uploads/posts/" . $data_in['post_video'];
                $post_out[$i]['post_audio'] =  base_url() . "public/uploads/posts/" . $data_in['post_audio'];

                $post_out[$i]['post_image'] =  base_url() . "public/uploads/posts/" . $data_in['post_image'];
                $i++;
         }
        
        if ($post_out != array()) {
            $json['post'] = $post_out;
            $json['message'] = "Post List Successfully";
            $json['status'] = "1";
        } else {
            $json['post'] =  array();
            $json['message'] = "Post Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    // get single post
    public function show($id = null) {
        $model = new PostModel();
        $data = $model->getWhere(['post_id' => $id])->getResult();
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('No Data Found with id ' . $id);
        }
    }
    // create a post
    public function create() {
        $model = new PostModel();
        $data = ['post_product_id' => $this->request->getVar('product_id'), 'post_user_id' => $this->request->getVar('user_id'), 'post_quantity' => ($this->request->getVar('post_quantity') == "") ? 0 : $this->request->getVar('post_quantity'), ];
        $model->insert($data);
        $json['data'] = $data;
        $json['message'] = "Post Product Added Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
    // update post
    public function update($id = null) {
        $id = $this->request->getVar('post_id');

        $model = new PostModel();
        $data = ['post_product_id' => $this->request->getVar('product_id'), 'post_user_id' => $this->request->getVar('user_id'), 'post_quantity' => ($this->request->getVar('post_quantity') == "") ? 0 : $this->request->getVar('post_quantity'), ];
        $model->where('post_id', $id)->set($data)->update();
        $json['message'] = "Post Updated Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
    // delete category
    public function delete($id = null) {
        
        $id = $this->request->getVar('post_id');
        
        $model = new PostModel();
        $data = $model->find($id);
        $model->delete($id);
        $json['message'] = "Product Delete Success.";
        $json['status'] = "1";
        return $this->respond($json);
    }
}
