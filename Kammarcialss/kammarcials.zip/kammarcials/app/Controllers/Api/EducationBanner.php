<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\EducationBannerModel;


class EducationBanner extends ResourceController {
    use ResponseTrait;
    // get all category
    public function get_fertility_education_banner() {
        
        $model = new EducationBannerModel();
        $data = $model->findAll();
        $i = 0;
        $banner = array();
        foreach ($data as $data_in) {
            $data_in['image'] = base_url() . "public/uploads/education_banner/" . $data_in['image'];
            $i++;
            $banner = $data_in;
        }
        if ($banner != array()) {
            $json['result'] = $banner;
            $json['message'] = "Banner List Successfully";
            $json['status'] = "1";
        } else {
            $json['result'] = [];
            $json['message'] = " Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
   
    
}
