<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ChatModel;
use App\Models\UserModel;

use App\Models\ProductModel;
class Chats extends ResourceController {
    use ResponseTrait;
    // get all category
    public function index() {
        $model = new ChatModel();
        $user_id = $this->request->getVar('user_id');
        
        $data = $model->query('SELECT DISTINCT
            CASE
                WHEN chat_sender_id = 1 THEN chat_receiver_id
                ELSE chat_sender_id
            END AS other_user_id,
            MAX(chat_created_at) AS latest_date,
            (
                SELECT chat_message
                FROM chats m2
                WHERE (
                    (m2.chat_sender_id = 1 AND m2.chat_receiver_id = other_user_id) OR
                    (m2.chat_sender_id = other_user_id AND m2.chat_receiver_id = 1)
                )
                ORDER BY chat_created_at DESC
                LIMIT 1
            ) AS latest_message
        FROM chats
        WHERE chat_sender_id = 1 OR chat_receiver_id = 1
        GROUP BY other_user_id
')->getResultArray();

        $i = 0;
        $chat_out = array();
        foreach ($data as $data_in) {

                
                $model = new UserModel();
                $data = $model->getWhere(['id' => $data_in['other_user_id']])->getResult();
        
                if($data == array()){
                    
                }else{
                    
                 $data[0]->image = base_url() . "public/uploads/users/" .  $data[0]->image;
                    
                $chat_out[$i] = $data_in;
                $chat_out[$i]['user_data'] = $data[0];
                $i++;
                }
            
        }
        
        if ($chat_out != array()) {
            $json['chat'] = $chat_out;
            $json['message'] = "Chat List Successfully";
            $json['status'] = "1";
        } else {
            $json['chat'] = array();
            $json['message'] = "Chat Empty.";
            $json['status'] = "0";
        }
        return $this->respond($json);
    }
    // get single chat
    public function show($id = null) {
        
        $model = new ChatModel();
        $data = $model->getWhere(['chat_id' => $id])->getResult();
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('No Data Found with id ' . $id);
        }
    }
    // create a chat
    public function create() {
        $model = new ChatModel();
        
        $data = [
            
            'chat_sender_id' => $this->request->getVar('sender_id'),
            'chat_receiver_id' => $this->request->getVar('receiver_id'), 
            'chat_message' => $this->request->getVar('message'), 
            'chat_created_at' => date('Y-m-d H:i:s'), 

            ];
        $model->insert($data);
        $json['data'] = $data;
        $json['message'] = "Chat Added Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
    // update Chat
    public function update_chat_by_id() {
        $id = $this->request->getVar('chat_id');

        $model = new ChatModel();
        $data = ['chat_product_id' => $this->request->getVar('product_id'), 'chat_user_id' => $this->request->getVar('user_id'), 'chat_quantity' => ($this->request->getVar('chat_quantity') == "") ? 0 : $this->request->getVar('chat_quantity'), ];
        $model->where('chat_id', $id)->set($data)->update();
        $json['message'] = "Chat Updated Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    

    
    public function delete_chat_by_id() {
        
        $id = $this->request->getVar('chat_id');
        $model = new ChatModel();
        //$data = $model->find($id);
        $model->delete($id);
        $json['message'] = "Product Delete Success.";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
    
    
    
    
     public function chat_between_user() {

        $ChatModel = new ChatModel();
        
        $user_id = $this->request->getVar('user_id');
        $other_user_id = $this->request->getVar('other_user_id');
        
        $model = new UserModel();
        $data_user = $model->getWhere(['id' => $user_id])->getResult();
        
        $model = new UserModel();
        $data_other = $model->getWhere(['id' => $other_user_id])->getResult();  
        
        if(empty($data_user)){
            
             $json['chat'] = array();
             $json['message'] = "User Not Found.";
             $json['status'] = "0";
             return $this->respond($json);
        }
        
        if(empty($data_other)){
            
             $json['chat'] = array();
             $json['message'] = "Other User Not Found.";
             $json['status'] = "0";
             return $this->respond($json);
        }
        
        $messages = $ChatModel->whereIn('chat_sender_id', [$user_id, $other_user_id])->whereIn('chat_receiver_id', [$user_id, $other_user_id])->orderBy('chat_created_at', 'desc')->findAll();
        
        $messages = (array)$messages;
        
        $i = 0;
        foreach ($messages as $messages_in) {
            $messages[$i]['sent_by'] = ($messages_in['chat_sender_id'] == $user_id) ? "ME" : "OTHER";
            $i++;
        }
        
        if (empty($messages)) {
        $json['chat'] = array();
        $json['message'] = "Chat Empty.";
        $json['status'] = "0";
        return $this->respond($json);
        }

        $json['chat'] = $messages;
        
        
        $json['user_name'] =   $data_user[0]->user_name;
        $json['user_image'] =  base_url() . "public/uploads/users/" . $data_user[0]->image;
        
        $json['other_user_name'] =   $data_other[0]->user_name;
        $json['other_user_image'] =   base_url() . "public/uploads/users/" .  $data_other[0]->image;;
        
          $json['chat_sender_id'] =   $data_user[0]->id;
          $json['chat_receiver_id'] =   $data_other[0]->id;
        

        $json['message'] = "Chat Found Success.";
        $json['status'] = "1";
        return $this->respond($json);
        
    }
    
    
    
    
    
    
    
    
}
