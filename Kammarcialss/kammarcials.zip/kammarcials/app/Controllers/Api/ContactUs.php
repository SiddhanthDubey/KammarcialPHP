<?php namespace App\Controllers\Api;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ServicesModel;
use App\Models\UserModel;
use App\Models\AppLogoModel;
use App\Models\LanguageModel;
use App\Models\ContactUsModel;

use App\Models\WorkoutTypeModel;
use App\Models\FaqModel;

 
class ContactUs extends ResourceController
{
    use ResponseTrait;
    
    public function add_contact_us1() {
    // Retrieve user_id and electricity_providers_id from the request
    $user_id = $this->request->getVar('user_id');
    $name = $this->request->getVar('name');
    $email = $this->request->getVar('email');
    $email = $this->request->getVar('message');
    
    // Create a database connection
    $db = \Config\Database::connect();
    
    // Create an instance of UserModel
    $userModel = new UserModel();
    
    // Get the user ID using a method in the UserModel
   // $user_id = $userModel->getUserID($user_id);
    
    $user_data = $userModel->where('id',$user_id)->first();
    
   // print_r($user_id);die;
    
    // Check if user_id exists
    if ($user_data=='') {
        $json['data'] = [];
        $json['message'] = "User with specified ID does not exist";
        $json['status'] = false;
        return $this->respond($json);
    }
    
    // Create an instance of UserModel
    $ContactUsModel = new ContactUsModel();

    // Get data from Postman request
    $data = [
        'user_id' => $user_id,
        'name' => $this->request->getPost('name'),
        'email' => $this->request->getPost('email'),
        'message' => $this->request->getPost('message'),
    ];
    
//  Var print_r($data);die;

    // Insert data into the database
    $result = $ContactUsModel->insert($data);
    
    if ($result) {
        $json['data'] = $data;
        $json['message'] = "Contact Us detail added successfully";
        $json['status'] = true;
    } else {
        // If log entry insertion fails
        $json['data'] = [];
        $json['message'] = "Failed to add Contact Us details";
        $json['status'] = false;
    }
    
    return $this->respond($json);
}
    
    
     public function add_contact_us() {
      
        $user_id = $this->request->getVar('user_id');
        
        $name = $this->request->getVar('name');
        
        $email = $this->request->getVar('email');
       
        $message = $this->request->getVar('message'); 
      
        $model = new ContactUsModel();
      
              $data = [
                            'user_id' =>$user_id,
                            'name' => $name, 
                            'email' => $email ,
                            'message' => $message
                     ];
        
           $result = $model->insert($data);
           
           if($result)
           {
              $json['data'] = 'success';
            $json['message'] = "Contact added successfully";
            $json['status'] = true;
            return $this->respond($json);  
           }
           else
           {
              $json['data'] = 'not success';
            $json['message'] = "unsuccessfully";
            $json['status'] = false;
            return $this->respond($json);  
           }
           
            
        
    }
    
    public function get_contact_us() {
    
    $ContactUsModel = new ContactUsModel();
   
    // Get the workout data
    $ContactUsdata = $ContactUsModel->findAll();

    // Check if workout data exists
    if ($ContactUsdata) {
        
        // Prepare response
        $json['contact_us'] = $ContactUsdata;
        $json['message'] = "Contact Us found";
        $json['status'] = "true";
    } else {
        // If workout data does not exist
        $json['data'] = [];
        $json['message'] = "Contact Us not found";
        $json['status'] = "false";
    }

    return $this->respond($json);
}

      public function get_suppliment_plan() {
          
       
          
        $db = \Config\Database::connect();
        $sub_category_id = $this->request->getVar('sub_category_id');
        $categoryList = $db->query("select * from suppliment_plan where sub_category_id = $sub_category_id")->getResultArray();
            if ($categoryList) {
               
                foreach ($categoryList as $val) {
                    $val['image'] =  base_url() . "public/uploads/suppliment/" . $val['image'];
                   
                 
                    $data[] = $val;
                }
                $json = ['result' => $data, 'message' => 'successfull', 'status' => '1'];
            } else {
                $json = ['result' => 'Data Not Found', 'message' => 'unsuccessfull', 'status' => '0'];
            }
        
         return $this->respond($json);
    }
    
    
       public function get_logo() {
          $db = \Config\Database::connect();
          $workoutList = $db->query("select * from app_logo")->getResultArray();
            if ($workoutList) {
                foreach ($workoutList as $val) {
                    $val['image'] =  base_url() . "public/uploads/app_logo/" . $val['image'];
                    $data[] = $val;
                }
                $json = ['result' => $data, 'message' => 'successfull', 'status' => '1'];
            } else {
                $json = ['result' => 'Data Not Found', 'message' => 'unsuccessfull', 'status' => '0'];
            }
        
         return $this->respond($json);
    }
    
      public function get_privacy_policy() {
          $db = \Config\Database::connect();
          $workoutList = $db->query("select * from about_us_privacy_policy where id = '1' ")->getResultArray();
            if ($workoutList) {
                foreach ($workoutList as $val) {
                    $data[] = $val;
                }
                $json = ['result' => $data, 'message' => 'successfull', 'status' => '1'];
            } else {
                $json = ['result' => 'Data Not Found', 'message' => 'unsuccessfull', 'status' => '0'];
            }
        
         return $this->respond($json);
    }
    
     public function get_about_us() {
          $db = \Config\Database::connect();
          $workoutList = $db->query("select * from about_us_privacy_policy where id = '2' ")->getResultArray();
            if ($workoutList) {
                foreach ($workoutList as $val) {
                    $data[] = $val;
                }
                $json = ['result' => $data, 'message' => 'successfull', 'status' => '1'];
            } else {
                $json = ['result' => 'Data Not Found', 'message' => 'unsuccessfull', 'status' => '0'];
            }
        
         return $this->respond($json);
    }
        
         public function get_terms_conditions() {
          $db = \Config\Database::connect();
          $termsConditionsList = $db->query("select * from terms_conditions where id = '1' ")->getResultArray();
            if ($termsConditionsList) {
                foreach ($termsConditionsList as $val) {
                    $data[] = $val;
                }
                $json = ['result' => $data, 'message' => 'successfull', 'status' => '1'];
            } else {
                $json = ['result' => 'Data Not Found', 'message' => 'unsuccessfull', 'status' => '0'];
            }
        
         return $this->respond($json);
    }
    
     public function get_faq() {
          $db = \Config\Database::connect();
          $workoutList = $db->query("select * from faq ")->getResultArray();
            if ($workoutList) {
                foreach ($workoutList as $val) {
                    $data[] = $val;
                }
                $json = ['result' => $data, 'message' => 'successfull', 'status' => '1'];
            } else {
                $json = ['result' => 'Data Not Found', 'message' => 'unsuccessfull', 'status' => '0'];
            }
        
         return $this->respond($json);
    }
    
    
     
      public function get_banner() {
          $db = \Config\Database::connect();
          $workoutList = $db->query("select * from banner")->getResultArray();
            if ($workoutList) {
                foreach ($workoutList as $val) {
                    $val['image'] =  base_url() . "public/uploads/banner/" . $val['image'];
                    $data[] = $val;
                }
                $json = ['result' => $data, 'message' => 'successfull', 'status' => '1'];
            } else {
                $json = ['result' => 'Data Not Found', 'message' => 'unsuccessfull', 'status' => '0'];
            }
        
         return $this->respond($json);
    }
    
    
    
      public function get_services()
    {
        $model = new ServicesModel();
        $data = $model->findAll();
        
        $i=0;
        foreach($data as $data_in){
            $data[$i]['ser_image'] =  base_url() . "public/uploads/services/" . $data_in['ser_image'];
            $i++; 
        }
        
        $json['data'] = $data;
        $json['message'] = "Service Found Successfully";
        $json['status'] = "1";

        return $this->respond($json);
    }
    
       public function get_langauge()
    {
        $model = new LanguageModel();
        $data = $model->findAll();
        
        $i=0;
        foreach($data as $data_in){
            //$data[$i]['ser_image'] =  base_url() . "public/uploads/services/" . $data_in['ser_image'];
            $i++; 
        }
        
        $json['data'] = $data;
        $json['message'] = "language Found Successfully";
        $json['status'] = "1";

        return $this->respond($json);
    }
    
  
    // get all category
    public function get_body_parts()
    {
        $model = new BodyPartModel();
        $data = $model->findAll();
        
        $i=0;
        foreach($data as $data_in){
            $data[$i]['bp_image'] =  base_url() . "public/uploads/body_parts/" . $data_in['bp_image'];
            $i++; 
        }
        
        $json['data'] = $data;
        $json['message'] = "Categoories Found Successfully";
        $json['status'] = "1";

        return $this->respond($json);
    }    
    
    
    

    public function provider_list()
    {
        
         $db = \Config\Database::connect();
         $service_id = $this->request->getVar('service_id');
          
         $type = $this->request->getVar('type');

        $model = new UserModel();
        
        if($type=='Company')
        {
           
        //  $data_main = $model->whereIn('expertise_service_id', $service_ids)->where('user_type', 'Company')->findAll();
  $data_main = $db->query("SELECT * FROM `users` WHERE FIND_IN_SET($service_id, expertise_service_id) AND `user_type` = 'Company' AND account_status = 'verify' ")->getResultArray();

                   
          //$data_main = $model->where('expertise_service_id',$service_id)->where('user_type','Company')->findAll();  
        }
        elseif($type=='Professional')
        {
           // $data_main = $model->where('expertise_service_id',$service_id)->where('user_type','Professional')->findAll(); 
          // $data_main = $model->whereIn('expertise_service_id1', $service_ids)->where('user_type', 'Professional')->findAll();
            
               
          $data_main = $db->query("SELECT * FROM `users` WHERE FIND_IN_SET($service_id, expertise_service_id) AND `user_type` = 'Professional' AND account_status = 'verify' ")->getResultArray();
        }
        else
        {
           $data_main = $model->where('expertise_service_id',$service_id)->findAll();   
        }
        
        
        
        if($data_main == array()){
            
         $json['data'] = $data_main;
         $json['message'] = "Data Not Found.";
         $json['status'] = 0;

         return $this->respond($json);
        
        }
        else
        {
            
        }
        
       $i=0;
        foreach($data_main as $data_in){
             $data[$i]['id'] =  $data_in['id'];
              $user_type =  $data_in['user_type'];
              if($user_type=='Professional')
              {
                 $data[$i]['user_name'] =  $data_in['user_name'];  
              }
              
               if($user_type=='Company')
              {
                 $data[$i]['user_name'] =  $data_in['company_name'];  
              }
              
              
          
                $db = \Config\Database::connect();
               
                $categoryList = $db->query("SELECT AVG(rating) AS rat FROM `rates` WHERE `user_id` = ".$data[$i]['id']." ")->getResultArray();
                
                $rating = number_format($categoryList[0]['rat'], 1, '.', '');
                
               // print_r($rating);
             
              $data[$i]['rating'] =  $rating;
              $data[$i]['review'] =  $data_in['review_count'];
             
            $data[$i]['image'] =  base_url() . "public/uploads/users/" . $data_in['image'];
            $i++; 
        }
        
        $json['data'] = $data;
      
        $json['message'] = "Data Get Successfully";
        $json['status'] = 1;

        return $this->respond($json);
    }
    
    
    
    
    
    
    public function get_insights(){
             
        $db  = \Config\Database::connect();
        $builder = $db->table('insights');
        
        $data = $builder->get()->getResultArray();
        
        $json['data'] = $data;
        $json['message'] = "Insights Found Successfully";
        $json['status'] = "1";

        return $this->respond($json);
        
    }
    
    
    
    
    
    
    
    
     public function sub_categories_by_category_id()
    {
        
        // $model = new CategoryModel();
        
        $db  = \Config\Database::connect();
        $builder = $db->table('sub_categories');
        
        $banner = $db->table('banner');
        
        $d123 = $banner->where('id', '1')->get()->getResultArray();
        
        $banner_image =  base_url() . "public/uploads/sub_categories/" . $d123[0]['banner_image'];
            
        
        
        $category_id = $this->request->getVar('category_id');

        $data = $builder->where('category_id', $category_id)->get()->getResultArray();
        
        if($data)
        {
        
        $i=0;
        foreach($data as $data_in){
            $data[$i]['sub_category_image'] =  base_url() . "public/uploads/sub_categories/" . $data_in['image'];
            $data[$i]['page_link'] =  base_url().$data_in['page_link'];
            $i++; 
        }
        
        $json['result'] = $data;
        $json['banner'] = $banner_image;
        $json['title'] = "You may select more than one option";
        $json['message'] = "Categoories Found Successfully";
        $json['status'] = "1";
        
        }
        else
        {
        $json['result'] = [];
         $json['title'] = "You may select more than one option";
        $json['banner'] = '';
        $json['message'] = "Categoories Not Found Successfully";
        $json['status'] = "0";
        }

        return $this->respond($json);
    }
    
    public function cycle_tracking_option()
    {
        
        // $model = new CategoryModel();
        
        $db  = \Config\Database::connect();
        $builder = $db->table('cycle_tracking_option');
        
        
        $cycle_tracking_id = $this->request->getVar('cycle_tracking_id');

        $data = $builder->where('sub_category_id', $cycle_tracking_id)->get()->getResultArray();
        
        if($data)
        {
        
        $json['result'] = $data;
       
        $json['title'] = "My primary contraceptive method is";
        $json['message'] = "Cycle Data Found Successfully";
        $json['status'] = "1";
        
        }
        else
        {
        $json['result'] = [];
        $json['title'] = "My primary contraceptive method is";
        $json['message'] = "Cycle Data Not Found Successfully";
        $json['status'] = "0";
        }

        return $this->respond($json);
    }
    
    public function cycle_tracking_sub_option()
    {
        
        // $model = new CategoryModel();
        
        $db  = \Config\Database::connect();
        $builder = $db->table('cycle_tracking_sub_option');
        
        
        $cycle_tracking_sub_option_id = $this->request->getVar('cycle_tracking_sub_option_id');

        $data = $builder->where('cycle_tracking_sub_option_id', $cycle_tracking_sub_option_id)->get()->getResultArray();
        
        if($data)
        {
        
        $json['result'] = $data;
       
        $json['title'] = "My primary contraceptive method is";
        $json['message'] = "Cycle Data Found Successfully";
        $json['status'] = "1";
        
        }
        else
        {
        $json['result'] = [];
        $json['title'] = "My primary contraceptive method is";
        $json['message'] = "Cycle Data Not Found Successfully";
        $json['status'] = "0";
        }

        return $this->respond($json);
    }
    
    
 
    // get single category
    public function show($id = null)
    {
        $model = new CategoryModel();
        $data = $model->getWhere(['category_id' => $id])->getResult();
        if($data){
            return $this->respond($data);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
    }
 
    // create a category
    public function create()
    {
        $model = new CategoryModel();
        $data = [
            'category_name' => $this->request->getVar('category_name')
        ];
        $model->insert($data);
        $response = [
            'status'   => 201,
            'error'    => null,
            'messages' => [
                'success' => 'Data Saved'
            ]
        ];
        return $this->respondCreated($response);
    }
 
    // update category
    public function update($id = null)
    {
        $model = new CategoryModel();
        $input = $this->request->getRawInput();
        $data = [
            'category_name' => $input['category_name'],
        ];
        $model->update($id, $data);
        $response = [
            'status'   => 200,
            'error'    => null,
            'messages' => [
                'success' => 'Data Updated'
            ]
        ];
        return $this->respond($response);
    }
 
    // delete category
    public function delete($id = null)
    {
        $model = new CategoryModel();
        $data = $model->find($id);
        if($data){
            $model->delete($id);
            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Data Deleted'
                ]
            ];
            return $this->respondDeleted($response);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
         
    }
 
}