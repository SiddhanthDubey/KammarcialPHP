<?php
  
namespace App\Controllers;
  
use App\Controllers\BaseController;
use CodeIgniter\API\ResponseTrait;
use App\Models\UserModel;
use App\Models\DoctorModel;

use \Firebase\JWT\JWT;


class Login extends BaseController
{
    use ResponseTrait;
    
    
      public function get_token_data(){
          
                //$type = 'User';//$this->request->getVar('type');
        $user_id = $this->request->getVar('user_id');
        $password = $this->request->getVar('pin');
      $t = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJJc3N1ZXIgb2YgdGhlIEpXVCIsImF1ZCI6IkF1ZGllbmNlIHRoYXQgdGhlIEpXVCIsInN1YiI6IlN1YmplY3Qgb2YgdGhlIEpXVCIsImlhdCI6MTcwOTc5ODM0MiwiZXhwIjoxNzQxMzM0MzQyLCJtb2JpbGUiOiI3MDAwNDUwMDAxIiwiaWQiOiIxIiwidXNlcl90eXBlIjoiVXNlciJ9.9ykTYCV6vyJ364M2YZVsGnK704sD75A9T1tOI5hvuVw';
    
        // $model = new UserModel();
        
        // $user = $model->where('id', $user_id)->where('account_status', 'verify')->first();

       
        // if (is_null($user)) {
        //     return $this->respond(['message' => 'Your Account is Not Verify Please verify your Mobile Number' , 'status' => "0"], 200);
        // }

            
        // $pwd_verify = password_verify($password, $user['password']);

        // if (!$pwd_verify) {
        //     return $this->respond(['message' => 'Incorrect Pin.', 'status' => "0"], 200);
        // }

        $key = getenv('JWT_SECRET');
        // $iat = time(); // current timestamp value
        // $exp = strtotime('+1 year', $iat);

        //           $mobile =  $user['mobile'];

        
        // $payload = [
        //     'iss' => 'Issuer of the JWT',
        //     'aud' => 'Audience that the JWT',
        //     'sub' => 'Subject of the JWT',
        //     'iat' => $iat, // Time the JWT issued at
        //     'exp' => $exp, // Expiration time of token
        //     'mobile' => $mobile,
        //     'user_type' => $user['user_type'],
        // ];

        // $token = JWT::encode($payload, $key, 'HS256');
        
       
        print_r(json_decode(base64_decode(str_replace('_', '/', str_replace('-','+',explode('.', $t)[1]))))); die;

        // $decoded = JWT::decode($t, $key, array('HS256'));
        // $decoded = JWT::decode($t, $key, ['HS256']);
        
        try {
    // Decode the JWT and verify the signature
    $decoded = JWT::decode($t, $key, ["HS256"]);
 
    // Output the decoded claims
    print_r($decoded);
} catch (Exception $e) {
    // Handle JWT validation errors
    echo "Access denied: " . $e->getMessage();
}
        
         print_r($decoded);die;

        // $decoded contains the decoded token as an object
        // You can access the claims like this:
        $userId = $decoded->user_id;
      echo  $username = $decoded->username; die; 
        
        $user['image'] = base_url() . "public/uploads/users/" . $user['image'];
        $response = [
            'user_data' => $user,
            'message' => 'Login Successful',
             'token' => $token,
            'status' => '1',
            // 'user_type' => $type
        ];

        return $this->respond($response, 200);
        
           } 
           
      
    public function index()
    {
        //$type = 'User';//$this->request->getVar('type');
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

    
        $model = new UserModel();
        
        $user = $model->where('email', $email)->where('account_status', 'verify')->first();

      
        if (is_null($user)) {
            return $this->respond(['message' => 'Email ID Not Valid' , 'status' => false], 200);
        }

            
        $pwd_verify = password_verify($password, $user['password']);

        if (!$pwd_verify) {
            return $this->respond(['message' => 'Incorrect Password.', 'status' => false], 200);
        }

        $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);

         $email =  $user['email'];

        
        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            'id' =>  $user['id'],
            'user_type' => 'User',
        ];

        $token = JWT::encode($payload, $key, 'HS256');
        
        $user['image'] = base_url() . "public/uploads/users/" . $user['image'];
        
        $response = [
            'token' => $token,
            'user_data' => $user,
            'message' => 'Login Successful',
             
            'status' => true,
            // 'user_type' => $type
        ];

        return $this->respond($response, 200);
    }
    
    
    public function update_profile() {
       
         $id = $this->request->getVar('user_id');
         
        //  $mobile = $this->request->getVar('mobile');
         $email = $this->request->getVar('email');
         
          $model = new UserModel();
          
           $user = $model->where('id', $id)->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'User  Not Found' , 'status' => "0"], 200);
        }
        
        
       
        // $user = $model->where('mobile', $mobile)->where('type', 'User')->where('account_status', 'verify')->first();

        // if (is_null($user)) {
        //     return $this->respond(['message' => 'Mobile No. Already exists' , 'status' => "0"], 200);
        // }
        
        // $useer = $model->where('email', $email)->where('type', 'User')->where('account_status', 'verify')->first();

        // if (is_null($useer)) {
        //     return $this->respond(['message' => 'Email is Already exists' , 'status' => "0"], 200);
        // }

         $data =  [
                    'user_name' => $this->request->getVar('user_name'),
                    'age' => $this->request->getVar('age'),
                    //'mobile' => $mobile,
                    'email' =>$email
                 ];
             
             if (isset($_FILES['image'])) {
                    $n = rand(0, 100000);
                    $img = "USER_IMG_" . $n . '.png';
                    move_uploaded_file($_FILES['image']['tmp_name'], "public/uploads/users/" . $img);
                    $data['image'] = $img;
                }
                
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "User Updated Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
    public function update_langauage() {
       
         $id = $this->request->getVar('user_id');
         
        
          $model = new UserModel();
          
           $user = $model->where('id', $id)->where('type', 'User')->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'User  Not Found' , 'status' => "0"], 200);
        }
        
        
         $data =  ['language' => $this->request->getVar('language')];
             
            
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "User Langauge Update Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
      public function update_notiification() {
       
         $id = $this->request->getVar('user_id');
         
        
          $model = new UserModel();
          
           $user = $model->where('id', $id)->where('type', 'User')->where('account_status', 'verify')->first();

        if (is_null($user)) {
            return $this->respond(['message' => 'User  Not Found' , 'status' => "0"], 200);
        }
        
        
        $general_notification = $this->request->getVar('general_notification');
                   $sound = $this->request->getVar('sound');
                   $vibrate = $this->request->getVar('vibrate');
                   $app_update = $this->request->getVar('app_update');
                   $new_tips_available = $this->request->getVar('new_tips_available');
                   $new_service_available = $this->request->getVar('new_service_available');
                   
         if($general_notification)
         {
            $data =  ['general_notification' => $this->request->getVar('general_notification') ];   
         }           
         if($sound)
         {
            $data =  ['sound' => $this->request->getVar('sound') ];  
         }
         if($vibrate)
         {
            $data =  ['vibrate' => $this->request->getVar('vibrate') ];  
         }
         if($app_update)
         {
            $data =  ['app_update' => $this->request->getVar('app_update') ];  
         }
         if($new_tips_available)
         {
            $data =  ['new_tips_available' => $this->request->getVar('new_tips_available') ];  
         }
         if($new_service_available)
         {
            $data =  ['new_service_available' => $this->request->getVar('new_service_available') ];  
         }
         
        //  $data =  [
        //           '' => $this->request->getVar('general_notification'),
        //           '' => $this->request->getVar('sound'),
        //           '' => $this->request->getVar('vibrate'),
        //           '' => $this->request->getVar('app_update'),
        //           '' => $this->request->getVar('new_tips_available'),
        //           '' => $this->request->getVar('new_service_available')
        //           ];
             
            
        $model->where('id', $id)->set($data)->update();
        $json['message'] = "User NOTIFICATION Update Successfully";
        $json['status'] = "1";
        return $this->respond($json);
    }
    
    
     public function get_profile()
    {
       
        $id = $this->request->getGet('user_id');


         $model = new UserModel();
       
         $user = $model->where('id', $id)->first();
         
        if (is_null($user)) {
            return $this->respond(['message' => 'Invalid username or password.' , 'status' => "0"], 200);
        }

        $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);

       
        $user['image'] =  base_url() . "public/uploads/users/" . $user['image'];

       
        $email =  $user['email'];
        $id11 =  $user['id'];
        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            'id' =>$id11
           
        ];

        
        $token = JWT::encode($payload, $key, 'HS256');
         
              $response = [
            'message' => 'Login Successful',
            //'token' => $token,
            'user_data' => $user,
            'status' => '1',
           
            
        ]; 
          
         

        return $this->respond($response, 200);
    }
    
     public function get_company_profile()
    {
        $type = 'Company';//$this->request->getVar('type');
        $id = $this->request->getVar('provider_id');

         $model = new UserModel();
       
         $user = $model->where('id', $id)->where('user_type', $type)->first();
         
        if (is_null($user)) {
            return $this->respond(['message' => 'Invalid Provider' , 'status' => "0"], 200);
        }

        $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);

        $email =  $user['email'];
        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            'user_type' => $type,
        ];

       // $user1 = 'ajay';
         $user1['id'] = $user['id'];
         $user1['company_name'] = $user['company_name'];
         $user1['company_code'] = $user['company_code'];
         $user1['company_mail'] = $user['company_mail'];
         $user1['company_number'] = $user['company_number'];
         $user1['language'] = $user['language'];
         
          $user1['expertise_service_id'] = $user['expertise_service_id'];
          
          
        
         $expertise_service_id = $user['expertise_service_id'];
         
         
         $db = \Config\Database::connect();
               

         $fetch12 = $db->query("SELECT * FROM `services` WHERE `ser_id` IN ($expertise_service_id)  ")->getResultArray();
         
          if($fetch12)
         {
             foreach ($fetch12 as $val1) {
                           $data1[] = $val1;
                       }
         }
         else
         {
           $data1 = [];  
         }
            
         $user1['service'] = $data1;
            
         
         
         
         
         $user1['bio'] = $user['bio'];
         $user1['company_address_1'] = $user['company_address_1'];
         $user1['company_address_1_lat'] = $user['company_address_1_lat'];
         $user1['company_address_1_lon'] = $user['company_address_1_lon'];
         $user1['company_address_2'] = $user['company_address_2'];
         $user1['company_address_2_lat'] = $user['company_address_2_lat'];
         $user1['company_address_2_lon'] = $user['company_address_2_lon'];
         $user1['company_address_3'] = $user['company_address_3'];
         $user1['company_address_3_lat'] = $user['company_address_3_lat'];
         $user1['company_address_3_lon'] = $user['company_address_3_lon'];
        
         $user1['image'] =  base_url() . "public/uploads/users/" . $user['image'];
         $user1['upload_company_document'] =  base_url() . "public/uploads/users/" . $user['upload_company_document'];
         
         $user1['year_of_expertise'] = $user['year_of_expertise'];
         
        
        $token = JWT::encode($payload, $key, 'HS256');
         
              $response = [
            'message' => 'Login Successful',
            // 'token' => $token,
            
             'provider_data' => $user1,
            'status' => '1',
           
            
        ]; 
          
        return $this->respond($response, 200);
    }
    
    
    public function get_bank_detail()
    {
        $db = \Config\Database::connect();
        
        $id = $this->request->getVar('user_id');

         $model = new UserModel();
       
         $user = $model->where('id', $id)->first();
         
        if (is_null($user)) {
            return $this->respond(['message' => 'Invalid User' , 'status' => "0"], 200);
        }

        

       // $user1 = 'ajay';
         $user1['id'] = $user['id'];
         $user1['bank_name'] = $user['bank_name'];
         $user1['account_number'] = $user['account_number'];
         $user1['ifsc_code'] = $user['ifsc_code'];
         $user1['sort_code'] = $user['sort_code'];
         $user1['country'] = $user['country'];
        
        
              $response = [
            'message' => 'Bank Detail..',
             'provider_data' => $user1,
            'status' => '1',
           
            
        ]; 
          
        return $this->respond($response, 200);
    }
    
    
      public function get_provider_detail()
    {
        
        $db = \Config\Database::connect();
        $type = $this->request->getVar('type'); // Professional / Company
        $id = $this->request->getVar('provider_id');
        $model = new UserModel();
        if($type=='Professional')
        {
       
         $user = $model->where('id', $id)->where('user_type', $type)->first();
         
        if (is_null($user)) {
            return $this->respond(['message' => 'Invalid Provider' , 'status' => "0"], 200);
        }

        $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);

       
        $email =  $user['email'];
        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
           
            'user_type' => $type,
        ];

       // $user1 = 'ajay';
         $user1['id'] = $user['id'];
         $user1['user_name'] = $user['user_name'];
         $user1['image'] =  base_url() . "public/uploads/users/" . $user['image'];
          $user1['email'] = $user['email'];
         $user1['bio'] = $user['bio'];
         $user1['age'] = $user['age'];
         $user1['location'] = $user['address'];
         $user1['lat'] = $user['lat'];
         $user1['lon'] = $user['lon'];
         $user1['professional_number'] = $user['professional_number'];
         $user1['year_of_expertise'] = $user['year_of_expertise'];
         
         $expertise_service_id = $user['expertise_service_id'];
         
               
         $categoryList = $db->query("SELECT AVG(rating) AS rat FROM `rates` WHERE `owner_id` = '$id' ")->getResultArray();
         $rating = number_format($categoryList[0]['rat'], 1, '.', '');
         
         
         
          $review_countt = $db->query("SELECT COUNT(*) as review_count FROM `rates` WHERE `owner_id` = '$id' ")->getResultArray();
             
         $user1['rating'] =  $rating;
         $user1['review'] =  $review_countt[0]['review_count'];
              
       
               
         $fetch = $db->query("SELECT * FROM services WHERE `ser_id` = '$expertise_service_id'  ")->getResultArray();
       
         if($fetch)
         {
            $user1['service_name'] = $fetch[0]['service_name'];
         }
         else
         {
          $user1['service_name'] = ''; 
         }
          
               
         $fetch = $db->query("select * from provider_gallery where provider_id = '$id'   ORDER BY id DESC ")->getResultArray();
         if($fetch)
         {
             foreach ($fetch as $val) {
                           $val['gallery'] =  base_url() . "public/uploads/gallery/" . $val['image'];
                           $data[] = $val;
                       }
         }
         else
         {
           $data = [];  
         }
            
         $user1['provider_gallery'] = $data;
         
        
        $token = JWT::encode($payload, $key, 'HS256');
         
              $response = [
            'message' => 'Login Successful',
            // 'token' => $token,
            
             'provider_data' => $user1,
            'status' => '1',
           
            
        ]; 
          
        return $this->respond($response, 200);
        
      }
      
        if($type=='Company')
        {
           
       
         $user = $model->where('id', $id)->where('user_type', $type)->first();
         
        if (is_null($user)) {
            return $this->respond(['message' => 'Invalid Company' , 'status' => "0"], 200);
        }

        $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);

        $email =  $user['email'];
        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            'user_type' => $type,
        ];

       // $user1 = 'ajay';
         $user1['id'] = $user['id'];
         $user1['company_name'] = $user['company_name'];
         $user1['company_code'] = $user['company_code'];
         $user1['company_mail'] = $user['company_mail'];
         $user1['company_number'] = $user['company_number'];
         $user1['language'] = $user['language'];
        
         $expertise_service_id = $user['expertise_service_id'];
         $fetch = $db->query("SELECT * FROM services WHERE `ser_id` = '$expertise_service_id'  ")->getResultArray();
       
         if($fetch)
         {
            $user1['service_name'] = $fetch[0]['service_name'];
         }
         else
         {
          $user1['service_name'] = ''; 
         }
            
         
         $user1['bio'] = $user['bio'];
         $user1['company_address_1'] = $user['company_address_1'];
         $user1['company_address_1_lat'] = $user['company_address_1_lat'];
         $user1['company_address_1_lon'] = $user['company_address_1_lon'];
         $user1['company_address_2'] = $user['company_address_2'];
         $user1['company_address_2_lat'] = $user['company_address_2_lat'];
         $user1['company_address_2_lon'] = $user['company_address_2_lon'];
         $user1['company_address_3'] = $user['company_address_3'];
         $user1['company_address_3_lat'] = $user['company_address_3_lat'];
         $user1['company_address_3_lon'] = $user['company_address_3_lon'];
         $user1['year_of_expertise'] = $user['year_of_expertise'];
        
         $user1['image'] =  base_url() . "public/uploads/users/" . $user['image'];
         $user1['upload_company_document'] =  base_url() . "public/uploads/users/" . $user['upload_company_document'];
         
         $categoryList = $db->query("SELECT AVG(rating) AS rat FROM `rates` WHERE `owner_id` = '$id' ")->getResultArray();
         $rating = number_format($categoryList[0]['rat'], 1, '.', '');
         
             
       $review_countt = $db->query("SELECT COUNT(*) as review_count FROM `rates` WHERE `owner_id` = '$id' ")->getResultArray();
             
         $user1['rating'] =  $rating;
         $user1['review'] =  $review_countt[0]['review_count'];
       
         
        
        $token = JWT::encode($payload, $key, 'HS256');
         
              $response = [
            'message' => 'Login Successful',
            // 'token' => $token,
            
             'provider_data' => $user1,
            'status' => '1',
           
            
        ]; 
          
        return $this->respond($response, 200);
           
       }
      
    }
    
    public function get_professional_profile()
    {
       // $type = 'Professional';//$this->request->getVar('type');
        $id = $this->request->getVar('provider_id');

         $model = new UserModel();
       
         $user = $model->where('id', $id)->first();
         
        if (is_null($user)) {
            return $this->respond(['message' => 'Invalid Provider' , 'status' => "0"], 200);
        }

        $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);

       
       

       
        $email =  $user['email'];
        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
           
            //'user_type' => $type,
        ];

       // $user1 = 'ajay';
         $user1['id'] = $user['id'];
         $user1['user_name'] = $user['user_name'];
         $user1['image'] =  base_url() . "public/uploads/users/" . $user['image'];
           $user1['email'] = $user['email'];
         $user1['bio'] = $user['bio'];
         $user1['age'] = $user['age'];
         $user1['location'] = $user['address'];
         $user1['lat'] = $user['lat'];
         $user1['lon'] = $user['lon'];
         $user1['professional_number'] = $user['professional_number'];
         
          $user1['expertise_service_id'] = $user['expertise_service_id'];
          
          $user1['year_of_expertise'] = $user['year_of_expertise'];
         
         $expertise_service_id = $user['expertise_service_id'];
         
         if($expertise_service_id)
         {
           
         $db = \Config\Database::connect();
               
         $fetch12 = $db->query("SELECT * FROM `services` WHERE `ser_id` IN ($expertise_service_id)  ")->getResultArray();
         
          if($fetch12)
         {
             foreach ($fetch12 as $val1) {
                           $data1[] = $val1;
                       }
         }
         else
         {
           $data1 = [];  
         }
            
         $user1['service'] = $data1;  
         }
         else
         {
             $user1['service'] = []; 
         }
         
       
        //  if($fetch)
        //  {
        //     $user1['service_name'] = $fetch[0]['service_name'];
        //  }
        //  else
        //  {
        //   $user1['service_name'] = ''; 
        //  }
          
          
         
         $db      = \Config\Database::connect();
               
         $fetch = $db->query("select * from provider_gallery where provider_id = '$id'   ORDER BY id DESC ")->getResultArray();
         if($fetch)
         {
             foreach ($fetch as $val) {
                           $val['gallery'] =  base_url() . "public/uploads/gallery/" . $val['image'];
                           $data[] = $val;
                       }
         }
         else
         {
           $data = [];  
         }
            
         $user1['provider_gallery'] = $data;
        
         $token = JWT::encode($payload, $key, 'HS256');
         
              $response = [
            'message' => 'Login Successful',
            // 'token' => $token,
            
             'provider_data' => $user1,
            'status' => '1',
           
            
        ]; 
          
        return $this->respond($response, 200);
    }
    
    
}