<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\BannerModel;
use App\Models\AppLogoModel;
use App\Models\ServicesModel;
use App\Models\SubcriptionModel;
use App\Models\FaqModel;
use App\Models\AboutPrivacyModel;
use App\Models\AdminModel;
use App\Models\SurveyTitleModel;
use App\Models\SurveyQuestionModel;

use CodeIgniter\Files\File;
use App\Models\Admin_common_model;
class Admin extends BaseController {
    
    public function __construct()
    {
         define("SITE_URL", 'https://server-php-8-2.technorizen.com/kammarcials/');
         define("SITE_EMAIL",'');
           $db = db_connect();
           $this->Admin_common_model = new Admin_common_model($db);
           header('Access-Control-Allow-Origin: *');
            //   $session = \Config\Services::session($config); 
           
            helper(['form', 'url']); 
    }
    
    public function index() {
        return view('admin/index');
    }
    public function register() {
        return view('admin/register');
    }
    
    public function visual_dashboard() {
        return view('admin/visual_dashboard');
    }
    
   
    
    public function postRegister()
{
    $session = \Config\Services::session();

    // Get user input from the form
    $email = $this->request->getVar('email');
    $password = $this->request->getPost('password');

    // Check if the email is already registered
    $existingUser = $this->Admin_common_model->get_where('users', ['email' => $email]);

    if ($existingUser) {
        $session->setFlashdata('error', 'Email is already registered.');
        return $this->response->redirect(site_url('/admin/register'));
    }

    // Proceed with user registration
    $userData = [
        'email' => $email,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        // Add other fields as needed
    ];

    // Use the DB helper to insert data
    $db = \Config\Database::connect();
    $db->table('users')->insert($userData);
    
    // Set success message in the session
    $session->setFlashdata('success', 'Registration successful!');

    // Set session data for the registered user
    $sessionData = [
        'id' => $db->insertID(),
        'email' => $email,
        'logged_in' => TRUE,
    ];

    $session->set($sessionData);

    // Redirect to the dashboard or another page after successful registration
    return redirect()->to(base_url('admin/login'));
}


public function updateProfile()
{
    $session = \Config\Services::session();

    // Get the user ID from the session
    $userId = $session->get('user')['id'];

    // Get the database connection from CodeIgniter's service container
    $db = \Config\Database::connect();

    // Use $db to fetch user data directly from the 'users' table
    $userData = $db->table('admins')->where('admin_id', $userId)->get()->getRowArray();

    // Check if user data is found
    if ($userData) {
        // Add user data to the $data array
        $data['user'] = $userData;
    } else {
        // Handle the case where user data is not found
        // You can redirect to an error page or display a message
        return redirect()->to(base_url('error-page'));
    }

    // Load the view with the data
    return view('admin/profileList', $data);
}


public function updateAdminProfile()
{
    // Ensure that the admin is logged in
    $session = \Config\Services::session();
    if (!$session->get('user.logged_in')) {
        // Redirect to the login page if the admin is not logged in
        return redirect()->to(base_url('admin'))->with('error', 'Authentication required');
    }

    $adminId = $session->get('user.id');

    // Fetch the admin by ID
    $db = \Config\Database::connect();

    $admin = $db->table('admins')->where('admin_id', $adminId)->get()->getRowArray();

    if (!$admin) {
        // Redirect to the dashboard with an error message
        return redirect()->to(base_url('admin/dashboard'))->with('error', 'Admin not found');
    }

    // Get the new email from the request
    $newEmail = $this->request->getPost('admin_email');

    // Validate the email format
    $validationRules = [
        'admin_email' => 'required|valid_email'
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the profile page with validation errors
        return redirect()->to(base_url('admin/profile'))->withInput()->with('errors', $this->validator->getErrors());
    }

    // Update the email field
    $db->table('admins')->where('admin_id', $adminId)->update(['admin_email' => $newEmail]);

    // Redirect to the profile page with a success message
    return redirect()->to(base_url('admin/profile'))->with('success', 'Admin Email updated successfully');
}


public function updateAdminProfilePassword()
{
    // Ensure that the admin is logged in
    $session = \Config\Services::session();
    if (!$session->get('user.logged_in')) {
        // Redirect to the login page if the admin is not logged in
        return redirect()->to(base_url('admin'))->with('error', 'Authentication required');
    }

    $adminId = $session->get('user.id');

    // Fetch the admin by ID
    $db = \Config\Database::connect();

    $admin = $db->table('admins')->where('admin_id', $adminId)->get()->getRowArray();

    if (!$admin) {
        // Redirect to the dashboard with an error message
        return redirect()->to(base_url('admin/dashboard'))->with('error', 'Admin not found');
    }

    // Get the new password and confirm password from the request
    $newPassword = $this->request->getPost('admin_password');
    $confirmPassword = $this->request->getPost('c_password');

    // Validate the form data
    $validationRules = [
        'admin_password' => 'required|min_length[6]',
        'c_password' => 'required|matches[admin_password]'
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the profile page with validation errors
        return redirect()->to(base_url('admin/profile'))->withInput()->with('errors', $this->validator->getErrors());
    }

    // Hash and update the password
    $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);

    $db->table('admins')->where('admin_id', $adminId)->update(['admin_password' => $hashedPassword]);

    // Redirect to the profile page with a success message
    return redirect()->to(base_url('admin/profile'))->with('success', 'Admin Password updated successfully');
}

public function login()
{
    $session = \Config\Services::session();

    $email = $this->request->getVar('email');
    $password = $this->request->getPost('password');

    // Fetch the user by email
    $user = $this->Admin_common_model->get_where('admins', ['admin_email' => $email]);

    if ($user) {
        // Verify the provided password with the hashed password in the database
        if (password_verify($password, $user[0]['admin_password'])) {
            $data['user'] = [
                'id' => $user[0]['admin_id'],
                'user_name' => $user[0]['user_name'],
                'admin_email' => $user[0]['admin_email'],
                'logged_in' => TRUE
            ];

            // Set success message as tempdata
            $session->setTempdata('success', 'Login successful!', 5); // 5 seconds

            // Set session data
            $session->set($data);

            // Redirect to the dashboard to avoid form resubmission
            return redirect()->to(base_url('admin/visual_dashboard'));
        }
    }

    // Set flashdata for error message
    $session->setFlashdata('error', 'Invalid Username and Password. Log in failed.');

    // Redirect back to the login page to avoid form resubmission
    return redirect()->to(base_url('admin'));
}

    public function dashboard() {
        
    $session = \Config\Services::session();
    
    if (!$session) {
        return redirect()->to(base_url('admin/login'));
    }
    
    // Continue with rendering the dashboard
        return view('admin/dashboard');
    }
    
    public function admin_logout(){
          $session = \Config\Services::session();
          $session->destroy();
          return redirect()->to(base_url('admin/login'));
  }
  
  
    public function dashboard_one() {
        
    $session = \Config\Services::session();
    
    if (!$session) {
        return redirect()->to(base_url('admin/login'));
    }
    
    // Continue with rendering the dashboard
        return view('admin/dashboard_one');
    }
    
  public function saveSubCategory() {
        // Load the UserModel
        $doctorModel = new SubCategoryModel(); 
        // Validate the form data
        
         $validationRules = [
    'name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
            'category_id' => $this->request->getPost('category_id'),
             'name' => $this->request->getPost('name'),
              'description' => $this->request->getPost('description'),
               'screen_type' => $this->request->getPost('screen_type')
            ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/sub_categories', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sub_category'))->with('success', 'Sub_category added successfully');
    }

  
    public function category() {
    
        $categoryModel = new CategoryModel();
        // Fetch all users from the 'users' table
        $data['categories'] = $categoryModel->findAll();
        // Pass the data to the view
        return view('admin/category', $data);
    }
    public function addCategory() {
        return view('admin/add_category');
    }
    public function saveCategory() {
    // Load the CategoryModel
    $categoryModel = new CategoryModel();
    
    $validationRules = [
    'category_name' => 'required',
    'main_category_id' => 'required|numeric', // Add numeric validation
    // 'description' => 'required',
    'type' => 'required|in_list[SIMPLE,PROGRESS_BAR]', // Validate against specific values
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $categoryData = [
        'category_name' => $this->request->getPost('category_name'),
        'main_category_id' => $this->request->getPost('main_category_id'),
        'description' => $this->request->getPost('description'),
        'type' => $this->request->getPost('type'),
    ];

    // Handle image upload
    $image = $this->request->getFile('category_image');
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/categories', $newName);
        // Update the category data with the new image name
        $categoryData['category_image'] = $newName;
    }

    // Save category data
    $categoryModel->insert($categoryData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/category'))->with('success', 'Category added successfully');
}
public function editCategory($category_id) {
        // Load the UserModel
        $categoryModel = new CategoryModel();
        // Fetch the user data based on the provided ID
        $data['category'] = $categoryModel->find($category_id);
        // Pass the data to the view
        return view('admin/edit_category', $data);
    }
    public function updateCategory($category_id) {
        // Load the UserModel
        $categoryModel = new CategoryModel();
        // Fetch the user data based on the provided ID
        $category = $categoryModel->find($category_id);
        // Check if the user exists
        if (!$category) {
            // Handle the case where the user is not found
            echo 'Category not found';
            die();
        }
        // Validate the form data
        $validationRules = ['category_name' => 'required', 'main_category_id' => 'required', 'description' => 'required', 'type' => 'required'
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $categoryData = ['category_name' => $this->request->getVar('category_name'), 'main_category_id' => $this->request->getVar('main_category_id'), 'description' => $this->request->getVar('description'), 'type' => $this->request->getVar('type') ];
        // Handle image upload
        $image = $this->request->getFile('category_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/categories', $newName);
            // Delete the old image if it exists
            if ($category['category_image'] && file_exists(ROOTPATH . 'public/uploads/categories/' . $category['category_image'])) {
                unlink(ROOTPATH . 'public/uploads/categories/' . $category['category_image']);
            }
            // Update the user data with the new image name
            $categoryData['category_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($categoryModel->update($category_id, $categoryData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/category"))->with('success', 'Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/category/edit/{$category_id}"))->with('errors', 'Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
public function deleteCategory($category_id) {
        // Load the UserModel
        $categoryModel = new CategoryModel();
        // Fetch the user data based on the provided ID
        $category = $categoryModel->find($category_id);
        // Check if the user exists
        if (!$category) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/category'))->with('error', 'Category not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($category['category_image'] && file_exists(ROOTPATH . 'public/uploads/categories/' . $category['category_image'])) {
            unlink(ROOTPATH . 'public/uploads/categories/' . $category['category_image']);
        }
        // Delete the user
        $categoryModel->delete($category_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/category'))->with('success', 'Category deleted successfully');
    }
    public function mainCategory() {
    
        $MainCategoryModel = new MainCategoryModel();
        // Fetch all users from the 'users' table
        $data['main_categories'] = $MainCategoryModel->findAll();
        // Pass the data to the view
        return view('admin/main-category', $data);
    }
     public function addMaincategory() {
        return view('admin/add_main_category');
    }
    public function saveMaincategory() {
    // Load the CategoryModel
    $MainCategoryModel = new MainCategoryModel();
    
    $validationRules = [
        'name' => 'required',
        'status' => 'required', // Use colon instead of square brackets
        'description' => 'required',
        'image' => 'uploaded[image]|mime_in[image,image/jpg,image/jpeg,image/png]|max_size[image,1024]',
         // Adjust max size as needed
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $maincategoryData = [
        'name' => $this->request->getPost('name'),
        'description' => $this->request->getPost('description'),
        'status' => $this->request->getPost('status'),
    ];

    // Handle image upload
    $image = $this->request->getFile('image');
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
        // Update the category data with the new image name
        $maincategoryData['image'] = $newName;
    }
    
    // Handle image upload
    $banner_image = $this->request->getFile('banner_image');
    if ($banner_image->isValid() && !$banner_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $banner_image->getRandomName();
        // Move the uploaded image to the correct directory
        $banner_image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
        // Update the category data with the new image name
        $maincategoryData['banner_image'] = $newName;
    }
    
    // Handle video upload
    $banner_video = $this->request->getFile('banner_video');
    if ($banner_video->isValid() && !$banner_video->hasMoved()) {
        // Check if the file is a valid video file
        if ($banner_video->getClientMimeType() == 'video/mp4' || $banner_video->getClientMimeType() == 'video/quicktime') {
            // Generate a unique name for the video
            $newName = $banner_video->getRandomName();
            // Move the uploaded video to the correct directory
            $banner_video->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Update the category data with the new video name
            $maincategoryData['banner_video'] = $newName;
        } else {
            // Invalid video file format
            return redirect()->back()->withInput()->with('errors', ['banner_video' => 'Invalid video file format']);
        }
    }

    // Save category data
    $MainCategoryModel->insert($maincategoryData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/main-category'))->with('success', 'Main Category added successfully');
}
public function editMainCategory($id) {
        // Load the UserModel
        $MainCategoryModel = new MainCategoryModel();
        // Fetch the user data based on the provided ID
        $data['maincategory'] = $MainCategoryModel->find($id);
        // Pass the data to the view
        return view('admin/edit_main_category', $data);
    }
    public function updateMainCategory($id) {
        // Load the UserModel
        $MainCategoryModel = new MainCategoryModel();
        // Fetch the user data based on the provided ID
        $maincategory = $MainCategoryModel->find($id);
        // Check if the user exists
        if (!$maincategory) {
            // Handle the case where the user is not found
            echo 'Main Category not found';
            die();
        }
        // Validate the form data
        $validationRules = ['name' => 'required', 'status' => 'required', 'description' => 'required'
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $MainCategoryData = ['name' => $this->request->getVar('name'), 'status' => $this->request->getVar('status'), 'description' => $this->request->getVar('description')];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Delete the old image if it exists
            if ($maincategory['image'] && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['image'])) {
                unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['image']);
            }
            // Update the user data with the new image name
            $MainCategoryData['image'] = $newName;
        }
        
        // Handle banner image upload
        $image = $this->request->getFile('banner_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Delete the old image if it exists
            if ($maincategory['banner_image'] && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_image'])) {
                unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_image']);
            }
            // Update the user data with the new image name
            $MainCategoryData['banner_image'] = $newName;
        }
        
         // Handle banner video upload
        $banner_video = $this->request->getFile('banner_video');
        if ($banner_video->isValid() && !$banner_video->hasMoved()) {
            // Check if the file is a valid video file
            if ($banner_video->getClientMimeType() == 'video/mp4' || $banner_video->getClientMimeType() == 'video/quicktime') {
            // Generate a unique name for the image
            $newName = $banner_video->getRandomName();
            // Move the uploaded image to the correct directory
            $banner_video->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Delete the old video if it exists
            if ($maincategory['banner_video'] && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_video'])) {
                unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_video']);
            }
            // Update the user data with the new image name
            $MainCategoryData['banner_video'] = $newName;
        }
        else {
            // Invalid video file format
            return redirect()->back()->withInput()->with('errors', ['banner_video' => 'Invalid video file format']);
        }
    }
    
        // Update user data only if the image upload is successful
        if ($MainCategoryModel->update($id, $MainCategoryData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/main-category"))->with('success', 'Main Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/main-category/edit/{$id}"))->with('errors', 'Main Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
public function deleteMaincategory($id) {
        // Load the UserModel
        $MainCategoryModel = new MainCategoryModel();
        // Fetch the user data based on the provided ID
        $maincategory = $MainCategoryModel->find($id);
        // Check if the user exists
        if (!$maincategory) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/main-category'))->with('error', 'Main Category not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($maincategory['image'] && file_exists(ROOTPATH . 'public/uploads/main-categories/' . $maincategory['image'])) {
            unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['image']);
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($maincategory['banner_image'] && file_exists(ROOTPATH . 'public/uploads/main-categories/' . $maincategory['banner_image'])) {
            unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_image']);
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($maincategory['banner_video'] && file_exists(ROOTPATH . 'public/uploads/main-categories/' . $maincategory['banner_video'])) {
            unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_video']);
        }
        // Delete the user
        $MainCategoryModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/main-category'))->with('success', 'Main Category deleted successfully');
    }
    /*
    public function login() {
        $session = session();
        $model = new AdminModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $user = $model->where('admin_email', $email)->first();
        if ($user) {
            if (password_verify($password, $user['admin_password'])) {
                $session->set('user_id', $user['admin_id']);
                 return redirect()->to(base_url('admin/dashboard'))->with('success', 'Login Successfull.');
            } else {
                $session->setFlashdata('error', 'Invalid password');
            }
        } else {
            $session->setFlashdata('error', 'Invalid email');
        }
        return redirect()->to(base_url('admin'))->with('error', 'Invalid Creadentials');
        //return view('index');
        
    }
    */
    
    public function complain_list()
      { return view('admin/complain_list');  }
    
      public function contact_us()
      { return view('admin/contact_us');  }
      
       public function privacy_policy()
      { return view('admin/privacy_policy');  }
      
       public function about_us()
      { return view('admin/about_us');  }
      
       public function company_dashboard()
      { return view('admin/company_dashboard');  }
      
        public function add_withdraw_requests_payment_admin($su_id) {
        $db = \Config\Database::connect();
               $builder = $db->table('withdraw');
            $datac = $builder->where('id', $su_id)->get()->getResultArray();
                                            
        $data['user'] = $datac[0];
        // Pass the data to the view
        return view('admin/withdraw_requests_payment_admin', $data);
    }
      
      public function editabout_us($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new AboutPrivacyModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $SonographyUltrasoundsModel->find($su_id);
        // Pass the data to the view
        return view('admin/about_us', $data);
    }
    
     public function editprivacy_policy($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new AboutPrivacyModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $SonographyUltrasoundsModel->find($su_id);
        // Pass the data to the view
        return view('admin/privacy_policy', $data);
    }
    
    //  public function user_dashboard() {
    //     return view('admin/user_dashboard');
    // }
    
     public function user_dashboard() {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch all users from the 'users' table
        $data['users'] = $userModel->findAll();
        // Pass the data to the view
        return view('admin/user_dashboard', $data);
    }
    
    
    public function users() {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch all users from the 'users' table
        $data['users'] = $userModel->findAll();
        // Pass the data to the view
        return view('admin/users', $data);
    }
    public function editUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/edit_user', $data);
    }
    public function updateUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            echo 'User not found';
            die();
        }
        // Validate the form data
        $validationRules = ['user_name' => 'required', 'email' => 'required', 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $userData = ['user_name' => $this->request->getVar('user_name'), 
        'email' => $this->request->getVar('email'),
        'country_id' => $this->request->getVar('country_id'),
        'mobile' => $this->request->getVar('mobile')
        //  'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)

        ];
        // Handle image upload
        // $image = $this->request->getFile('image');
        // if ($image->isValid() && !$image->hasMoved()) {
        //     // Generate a unique name for the image
        //     $newName = $image->getRandomName();
        //     // Move the uploaded image to the correct directory
        //     $image->move(ROOTPATH . 'public/uploads/users', $newName);
        //     // Delete the old image if it exists
        //     if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
        //         unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
        //     }
        //     // Update the user data with the new image name
        //     $userData['image'] = $newName;
        // }
        // Update user data only if the image upload is successful
        if ($userModel->update($id, $userData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/user_dashboard"))->with('success', 'User updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/users/edit/{$id}"))->with('errors', 'User Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function viewUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/view-user', $data);
    }
    public function addUser() {
        return view('admin/add_user');
    }
    
      public function updatewithdraw_requests($id) {
        $db = \Config\Database::connect();
        $userModel = new UserModel();
       
       
       $status  = $this->request->getVar('status');
    
           $builder = $db->table('withdraw');
            $datac = $builder->where('id', $id)->get()->getResultArray();
         $uidd = $datac[0]['user_id'];
        
       
        $userData = 
        [
            'amount' => $this->request->getVar('amount'), 
            'added_by' => $this->request->getVar('added_by'),
            'status' => $status

        ];
        
       
         
        
        $db->table('withdraw')->where('id', $id)->update($userData);
        
        if($status=='Confirm')
        {
           $db->table('users')->where('id', $uidd)->update(['wallet' => '0']);  
        }
        
       
        return redirect()->to(base_url("admin/withdraw_history"))->with('success', 'Withdraw Payment  successfully');
        
    }
    
    public function saveUser() {
        // Load the UserModel
        $userModel = new UserModel();
        // Validate the form data
        $validationRules = ['user_name' => 'required', 'email' => 'required|valid_email', 'mobile' => 'permit_empty|numeric', // Adjust validation rules based on your UserModel
        ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $userData = ['user_name' => $this->request->getPost('user_name'),
        'email' => $this->request->getPost('email'),
        'country_id' => $this->request->getPost('country_id'),'mobile' => $this->request->getPost('mobile'),
                    'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),

        ];
        // Handle image upload
        $image = $this->request->getFile('image');
        // if ($image->isValid() && !$image->hasMoved()) {
        //     // Generate a unique name for the image
        //     $newName = $image->getRandomName();
        //     // Move the uploaded image to the correct directory
        //     $image->move(ROOTPATH . 'public/uploads/users', $newName);
        //     // Update the user data with the new image name
        //     $userData['image'] = $newName;
        // }
        // Save user data
        $userModel->insert($userData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/user_dashboard'))->with('success', 'User added successfully');
    }
    public function deleteUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/user_dashboard'))->with('error', 'User not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
            unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
        }
        // Delete the user
        $userModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/user_dashboard'))->with('success', 'User deleted successfully');
    }
    
    
    
    public function professional() {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch all users from the 'users' table

        $data['users'] = $userModel->where('type','Provider')->where('user_type','Professional')->findAll();
        // Pass the data to the view
        return view('admin/professional', $data);
    }
    public function editprofessional($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/edit_professional', $data);
    }
    public function updateprofessional($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            echo 'Professional not found';
            die();
        }
        // Validate the form data
        $validationRules = ['user_name' => 'required', 'email' => 'required', 'age' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        
         $member_array =   $this->request->getPost('expertise_service_id');
      $member = "";
      foreach ($member_array as $key => $value) {
        $member .= $value;
        $member .= ",";
      }
      $str = $member;
      $data1 = rtrim($str, ",");
      
        // Get form data using getVar
         $userData = ['expertise_service_id'=>$data1,
        'user_name' => $this->request->getPost('user_name'),
        'email' => $this->request->getPost('email'),
        'professional_number' => $this->request->getPost('professional_number'),
        
        'age' => $this->request->getPost('age'),
        'language' => $this->request->getPost('language'),
        'bio' => $this->request->getPost('bio'),
        'address' => $this->request->getPost('address'),
        'lat' => $this->request->getPost('lat'),
        'lon' => $this->request->getPost('lon'),
        'year_of_expertise' => $this->request->getPost('year_of_expertise'),
        'account_status'=>'verify',
        'step'=>1,
        'mobile' => $this->request->getPost('mobile')
        

        ];
     
        
        
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/users', $newName);
            // Delete the old image if it exists
            if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
                unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
            }
            // Update the user data with the new image name
            $userData['image'] = $newName;
        }
        
        
        // Update user data only if the image upload is successful
        if ($userModel->update($id, $userData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/professional"))->with('success', 'Professional updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/professional/edit/{$id}"))->with('errors', 'Professional Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function viewprofessional($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/view-professional', $data);
    }
    public function addprofessional() {
        return view('admin/add_professional');
    }
    public function saveprofessional() {
        // Load the UserModel
        $userModel = new UserModel();
        // Validate the form data
        $validationRules = ['user_name' => 'required', 'email' => 'required|valid_email', 'age' => 'required' // Adjust validation rules based on your UserModel
        ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        
         $member_array =   $this->request->getPost('expertise_service_id');
      $member = "";
      foreach ($member_array as $key => $value) {
        $member .= $value;
        $member .= ",";
      }
      $str = $member;
      $data1 = rtrim($str, ",");
      
        
        // Get form data
        $userData = [
            
        'user_name' => $this->request->getPost('user_name'),
        'professional_number' => $this->request->getPost('professional_number'),
        'type'=>'Provider',
        'user_type'=>'Professional', 
        'account_status'=>'verify',
        'step'=>1,
         'bio' => $this->request->getPost('bio'),
        'email' => $this->request->getPost('email'),
        'age' => $this->request->getPost('age'),
        'mobile' => $this->request->getPost('mobile'),
        'expertise_service_id'=>$data1,
         'address' => $this->request->getPost('address'),
        'lat' => $this->request->getPost('lat'),
        'lon' => $this->request->getPost('lon'),
        'year_of_expertise' => $this->request->getPost('year_of_expertise'),
        'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),

        ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/users', $newName);
            // Update the user data with the new image name
            $userData['image'] = $newName;
        }
        // Save user data
        $userModel->insert($userData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/professional'))->with('success', 'Professional added successfully');
    }
    public function deleteprofessional($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/users'))->with('error', 'User not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
            unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
        }
        // Delete the user
        $userModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/professional'))->with('success', 'professional deleted successfully');
    }
    
    
    
    
    public function company() {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch all users from the 'users' table
        $data['users'] = $userModel->where('type','Provider')->where('user_type','Company')->findAll();
        // Pass the data to the view
        return view('admin/company', $data);
    }
    public function editcompany($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/edit_company', $data);
    }
    
    
    public function updateprivacy_policy($id) {
        // Load the UserModel
        $userModel = new AboutPrivacyModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            echo 'Privacy not found';
            die();
        }
        // Validate the form data
        $validationRules = ['name' => 'required', 'description' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $userData = ['name' => $this->request->getVar('name'), 
        'description' => $this->request->getVar('description')
        //  'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)

        ];
        // Handle image upload
       
        // Update user data only if the image upload is successful
        if ($userModel->update($id, $userData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/privacy_policy/edit/1"))->with('success', 'privacy policy updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/privacy_policy/edit/1"))->with('errors', 'company Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
      public function updateabout_us($id) {
        // Load the UserModel
        $userModel = new AboutPrivacyModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            echo 'Privacy not found';
            die();
        }
        // Validate the form data
        $validationRules = ['name' => 'required', 'description' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $userData = ['name' => $this->request->getVar('name'), 
        'description' => $this->request->getVar('description')
        //  'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)

        ];
        // Handle image upload
       
        // Update user data only if the image upload is successful
        if ($userModel->update($id, $userData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/about_us/edit/2"))->with('success', 'About Us updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/about_us/edit/2"))->with('errors', 'company Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
    
    public function updatecompany($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            echo 'company not found';
            die();
        }
        // Validate the form data
        $validationRules = ['company_name' => 'required'
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        
        $member_array =   $this->request->getPost('expertise_service_id');
      $member = "";
      foreach ($member_array as $key => $value) {
        $member .= $value;
        $member .= ",";
      }
      $str = $member;
      $data1 = rtrim($str, ",");
      
        // Get form data using getVar
         $userData = ['expertise_service_id'=>$data1,
        'company_name' => $this->request->getPost('company_name'),
        'type'=>'Provider',
        'user_type'=>'Company',
        'company_code' => $this->request->getPost('company_code'),
        'company_mail' => $this->request->getPost('company_mail'),
        
        'company_number' => $this->request->getPost('company_number'),
        'language' => $this->request->getPost('language'),
        'bio' => $this->request->getPost('bio'),
        'company_address_1' => $this->request->getPost('company_address_1'),
        'company_address_1_lat' => $this->request->getPost('company_address_1_lat'),
        'company_address_1_lon' => $this->request->getPost('company_address_1_lon'),
        'company_address_2' => $this->request->getPost('company_address_2'),
        'company_address_2_lat' => $this->request->getPost('company_address_2_lat'),
        'company_address_2_lon' => $this->request->getPost('company_address_2_lon'),
        
        'company_address_3' => $this->request->getPost('company_address_3'),
        'company_address_3_lat' => $this->request->getPost('company_address_3_lat'),
        'company_address_3_lon' => $this->request->getPost('company_address_3_lon'),
        'year_of_expertise' => $this->request->getPost('year_of_expertise'),
        'account_status'=>'verify',
        'step'=>1,
        'mobile' => $this->request->getPost('mobile'),
        'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),

        ];
     
        
        
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/users', $newName);
            // Delete the old image if it exists
            if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
                unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
            }
            // Update the user data with the new image name
            $userData['image'] = $newName;
        }
        
        
          $image1 = $this->request->getFile('upload_company_document');
        if ($image1->isValid() && !$image1->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image1->getRandomName();
            // Move the uploaded image to the correct directory
            $image1->move(ROOTPATH . 'public/uploads/users', $newName);
            // Delete the old image if it exists
            if ($user['upload_company_document'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['upload_company_document'])) {
                unlink(ROOTPATH . 'public/uploads/users/' . $user['upload_company_document']);
            }
            // Update the user data with the new image name
            $userData['upload_company_document'] = $newName;
        }
        
        
        // Update user data only if the image upload is successful
        if ($userModel->update($id, $userData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/company"))->with('success', 'company updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/company/edit/{$id}"))->with('errors', 'company Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function viewcompany($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/view-company', $data);
    }
    public function addcompany() {
        return view('admin/add_company');
    }
    public function savecompany() {
        // Load the UserModel
        $userModel = new UserModel();
        // Validate the form data
        $validationRules = ['company_name' => 'required',
        'company_code' => 'required'
         // Adjust validation rules based on your UserModel
        ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
      $member_array =   $this->request->getPost('expertise_service_id');
      $member = "";
      foreach ($member_array as $key => $value) {
        $member .= $value;
        $member .= ",";
      }
      $str = $member;
      $data1 = rtrim($str, ",");
      
        // Get form data
        $userData = ['expertise_service_id'=>$data1,
        'company_name' => $this->request->getPost('company_name'),
        'type'=>'Provider',
        'user_type'=>'Company',
        'company_code' => $this->request->getPost('company_code'),
        'company_mail' => $this->request->getPost('company_mail'),
        
        'company_number' => $this->request->getPost('company_number'),
        'language' => $this->request->getPost('language'),
        'bio' => $this->request->getPost('bio'),
        'company_address_1' => $this->request->getPost('company_address_1'),
        'company_address_1_lat' => $this->request->getPost('company_address_1_lat'),
        'company_address_1_lon' => $this->request->getPost('company_address_1_lon'),
        'company_address_2' => $this->request->getPost('company_address_2'),
        'company_address_2_lat' => $this->request->getPost('company_address_2_lat'),
        'company_address_2_lon' => $this->request->getPost('company_address_2_lon'),
        
        'company_address_3' => $this->request->getPost('company_address_3'),
        'company_address_3_lat' => $this->request->getPost('company_address_3_lat'),
        'company_address_3_lon' => $this->request->getPost('company_address_3_lon'),
        'year_of_expertise' => $this->request->getPost('year_of_expertise'),
        'account_status'=>'verify',
        'step'=>1,
        'mobile' => $this->request->getPost('mobile'),
        'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),

        ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/users', $newName);
            // Update the user data with the new image name
            $userData['image'] = $newName;
        }
        
         $image1 = $this->request->getFile('upload_company_document');
        if ($image1->isValid() && !$image1->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image1->getRandomName();
            // Move the uploaded image to the correct directory
            $image1->move(ROOTPATH . 'public/uploads/users', $newName);
            // Update the user data with the new image name
            $userData['upload_company_document'] = $newName;
        }
        
        
      //  print_r($userData);die;
        // Save user data
        $userModel->insert($userData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/company'))->with('success', 'company added successfully');
    }
    public function deletecompany($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/users'))->with('error', 'User not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
            unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
        }
        // Delete the user
        $userModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/company'))->with('success', 'company deleted successfully');
    }
    
    
    public function deleteTrainer($id) {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/trainer'))->with('error', 'trainer not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['personal_trainer_image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['personal_trainer_image'])) {
            unlink(ROOTPATH . 'public/uploads/personal_trainers/' . $doctor['personal_trainer_image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/trainer'))->with('success', 'Trainer deleted successfully');
    }
    
    public function trainer() {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch all users from the 'users' table
        $data['trainer'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/trainer', $data);
    }
    
    public function editsurvey_title($id) {
        // Load the UserModel
        
        $doctorModel1 = new SurveyTitleModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel1->find($id);
        // Pass the data to the view
        return view('admin/edit_survey_title', $data);
    }
    
    public function deletesurvey_title($id) {
        // Load the UserModel
        $doctorModel = new SurveyTitleModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/survey_title'))->with('error', 'Survey Title not found');
        }
        
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/survey_title'))->with('success', 'Survey Title deleted successfully');
    }
    
      public function updatesurvey_title($id) {
        // Load the UserModel
        $doctorModel = new SurveyTitleModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'DATA Type not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'title' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'title' => $this->request->getPost('title')
            ];
            
       
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/survey_title"))->with('success', 'Survey Title Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/survey_title/edit/{$id}"))->with('errors', 'Survey Title Type Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
     public function savesurvey_title() {
        // Load the UserModel
        $doctorModel = new SurveyTitleModel(); 
        // Validate the form data
        $validationRules = [
            'title' => 'required'
           ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = [
            'title' => $this->request->getPost('title')
            ];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/survey_title'))->with('success', 'Survey Title added successfully');
    }
    
    
    
     public function editProgressworkout($id) {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_progress_workout', $data);
    }
    
    public function deleteProgressworkout($id) {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/progress_workout'))->with('error', 'progress_workout not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/workout/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/workout/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/progress_workout'))->with('success', 'Progress Workout deleted successfully');
    }
    
    
    
    public function progress_workout() {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/progress_workout', $data);
    }
    
     public function survey_title() {
        // Load the UserModel
        $doctorModel = new SurveyTitleModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/survey_title', $data);
    }
    
     public function delete_forum_topic($id) {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/forum_topic'))->with('error', 'forum_topic not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic'))->with('success', 'forum_topic deleted successfully');
    }
    
     public function update_forum_topic($id) {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'forum topic  not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'name' => $this->request->getPost('name')
            ];
            
        
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/forum_topic"))->with('success', 'Forum Topic updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/forum_topic/edit/{$id}"))->with('errors', 'forum_topic Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function edit_forum_topic($id) {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_forum_topic', $data);
    }
    
     public function save_forum_topic() {
        // Load the UserModel
        $doctorModel = new ForumTopicModel(); 
        // Validate the form data
        
         $validationRules = [
    'name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
             'name' => $this->request->getPost('name')];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic'))->with('success', 'forum_topic added successfully');
    }
    
    public function delete_forum_topic_discussion($id) {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/forum_topic_discussion'))->with('error', 'forum_topic not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic_discussion'))->with('success', 'forum_topic_discussion deleted successfully');
    }
    
     public function update_forum_topic_discussion($id) {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'forum topic Discussion  not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'title' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
       
            
             'title' => $this->request->getPost('title'),
             'description' => $this->request->getPost('description'),
             'topic_id' => $this->request->getPost('topic_id')
             ];
            
        
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/forum_topic_discussion"))->with('success', 'Forum Topic Discussion updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/forum_topic_discussion/edit/{$id}"))->with('errors', 'forum_topic_discussion Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
     public function save_forum_topic_discussion() {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel(); 
        // Validate the form data
        
         $validationRules = [
    'title' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
            
             'title' => $this->request->getPost('title'),
             'description' => $this->request->getPost('description'),
             'topic_id' => $this->request->getPost('topic_id')
             ];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic_discussion'))->with('success', 'forum_topic_discussion added successfully');
    }
    
      public function edit_forum_topic_discussion($id) {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_forum_topic_discussion', $data);
    }
    
      public function forum_topic_discussion() {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/forum_topic_discussion', $data);
    }
    
     public function forum_categories() {
        // Load the UserModel
        $doctorModel = new EmplyeeLeaveModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/forum_topic_discussion', $data);
    }
    
     public function forum_topic() {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/forum_topic', $data);
    }
    
     public function editSubCategory($id) {
        // Load the UserModel
        $doctorModel = new SubCategoryModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_sub_category', $data);
    }
    
    public function sub_category() {
        // Load the UserModel
        $doctorModel = new SubCategoryModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/sub_category', $data);
    }
    public function deletesubcription($id) {
        // Load the UserModel
        $doctorModel = new SubcriptionModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/subcription'))->with('error', 'subcription not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/subcription'))->with('success', 'subcription deleted successfully');
    }
    
     public function deleteservices($id) {
        // Load the UserModel
        $doctorModel = new ServicesModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/services'))->with('error', 'services not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['ser_image'] && file_exists(ROOTPATH . 'public/uploads/services/' . $doctor['ser_image'])) {
            unlink(ROOTPATH . 'public/uploads/services/' . $doctor['ser_image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/services'))->with('success', 'Services deleted successfully');
    }
    
     public function deletefaq($id) {
        // Load the UserModel
        $doctorModel = new FaqModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/faq'))->with('error', 'faq not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        // if ($doctor['ser_image'] && file_exists(ROOTPATH . 'public/uploads/services/' . $doctor['ser_image'])) {
        //     unlink(ROOTPATH . 'public/uploads/services/' . $doctor['ser_image']);
        // }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/faq'))->with('success', 'faq deleted successfully');
    }
    
    public function updatefaq($id) {
        // Load the UserModel
        $doctorModel = new FaqModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Faq not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'question' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $doctorData = [
             'question' => $this->request->getPost('question'),
              'answer' => $this->request->getPost('answer')
            ];
            
       
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/faq"))->with('success', 'faq updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/faq/edit/{$id}"))->with('errors', 'faq Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
     public function updatesubcription($id) {
        // Load the UserModel
        $doctorModel = new SubcriptionModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'subcription not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'day' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $doctorData = [
             'day' => $this->request->getPost('day'),
             'amount' => $this->request->getPost('amount'),
             'status' => $this->request->getPost('status')
            ];
            
        
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/subcription"))->with('success', 'Subcription updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/subcription/edit/{$id}"))->with('errors', 'subcription Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
     public function updateservices($id) {
        // Load the UserModel
        $doctorModel = new ServicesModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'services not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'service_name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $doctorData = [
             'service_name' => $this->request->getPost('service_name')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('ser_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/services', $newName);
            // Delete the old image if it exists
            if ($doctor['ser_image'] && file_exists(ROOTPATH . 'public/uploads/services/' . $doctor['ser_image'])) {
                unlink(ROOTPATH . 'public/uploads/services/' . $doctor['ser_image']);
            }
            // Update the user data with the new image name
            $doctorData['ser_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/services"))->with('success', 'Services updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/services/edit/{$id}"))->with('errors', 'Services Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function updateProgressworkout($id) {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Progress workout not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'description' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'description' => $this->request->getPost('description')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/workout', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/workout/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/workout/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/progress_workout"))->with('success', 'Progress Workout updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/progress_workout/edit/{$id}"))->with('errors', 'Progress Workout Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
     public function lab() {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch all users from the 'users' table
        $data['lab'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/lab', $data);
    }
    
    public function doctors() {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch all users from the 'users' table
        $data['doctors'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/doctors', $data);
    }
    
    public function addDoctor() {
        return view('admin/add_doctor');
    }
    public function addLab() {
        return view('admin/add_lab');
    }
    
    public function addTrainer() {
        return view('admin/add_trainer');
    }
    public function addProgressworkout() {
        return view('admin/add_progress_workout');
    }
    public function addsurvey_title() {
        return view('admin/add_survey_title');
    }
     public function addSubcategory() {
        return view('admin/add_sub_category');
    }
    public function add_forum_topic() {
        return view('admin/add_forum_topic');
    }
    
    public function add_forum_topic_discussion() {
        return view('admin/add_forum_topic_discussion');
    }
    
    public function updateTrainer($id) {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Trainer not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'personal_trainer_email' => 'required',
            'personal_trainer_user_name' => 'required',
            'personal_trainer_company_name' => 'required',
            'personal_trainer_mobile' => 'required', 
            'personal_trainer_gender' => 'required',
            'personal_trainer_dob' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'personal_trainer_user_name' => $this->request->getPost('personal_trainer_user_name'),
            'personal_trainer_email' => $this->request->getPost('personal_trainer_email'),
            'personal_trainer_company_name' => $this->request->getPost('personal_trainer_company_name'),
            'personal_trainer_mobile' => $this->request->getPost('personal_trainer_mobile'),
            'personal_trainer_gender' => $this->request->getPost('personal_trainer_gender'),
            'personal_trainer_dob' => $this->request->getPost('personal_trainer_dob')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('personal_trainer_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/personal_trainers', $newName);
            // Delete the old image if it exists
            if ($doctor['personal_trainer_image'] && file_exists(ROOTPATH . 'public/uploads/personal_trainers/' . $doctor['personal_trainer_image'])) {
                unlink(ROOTPATH . 'public/uploads/personal_trainers/' . $doctor['personal_trainer_image']);
            }
            // Update the user data with the new image name
            $doctorData['personal_trainer_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/trainer"))->with('success', 'Trainer updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/trainer/edit/{$id}"))->with('errors', 'Trainer Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function saveTrainer() {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel(); 
        // Validate the form data
        $validationRules = [
            'personal_trainer_email' => 'required',
            'personal_trainer_user_name' => 'required',
            'personal_trainer_company_name' => 'required',
            'personal_trainer_mobile' => 'required', 
            'personal_trainer_gender' => 'required',
            'personal_trainer_dob' => 'required'
           ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = [
            'personal_trainer_user_name' => $this->request->getPost('personal_trainer_user_name'),
            'personal_trainer_email' => $this->request->getPost('personal_trainer_email'),
            'personal_trainer_company_name' => $this->request->getPost('personal_trainer_company_name'),
            'personal_trainer_mobile' => $this->request->getPost('personal_trainer_mobile'),
            'personal_trainer_gender' => $this->request->getPost('personal_trainer_gender'),
            'personal_trainer_dob' => $this->request->getPost('personal_trainer_dob')
            ];
        // Handle image upload
        $image = $this->request->getFile('personal_trainer_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/personal_trainers', $newName);
            // Update the user data with the new image name
            $doctorData['personal_trainer_image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/trainer'))->with('success', 'Trainer added successfully');
    }
    
     public function editTrainer($id) {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_trainer', $data);
    }
    
    public function saveLab() {
        // Load the UserModel
        $doctorModel = new LabModel(); 
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', // Adjust validation rules based on your UserModel
        'clinic' => 'required', 'year_of_experience' => 'required', 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]', 'languages' => 'required', 'education' => 'required'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = ['name' => $this->request->getPost('name'), 'post' => $this->request->getPost('post'), 'professional_profile' => $this->request->getPost('professional_profile'), 'consult_fee' => $this->request->getPost('consult_fee'), 'clinic' => $this->request->getPost('clinic'), 'year_of_experience' => $this->request->getPost('year_of_experience'), 'languages' => $this->request->getPost('languages'), 'education' => $this->request->getPost('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/lab'))->with('success', 'Lab Member added successfully');
    }
    
    public function editLab($id) {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_lab', $data);
    }
    
    public function updateLab($id) {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Lab not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', 'clinic' => 'required', 'year_of_experience' => 'required','languages' => 'required', 'education' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $doctorData = ['name' => $this->request->getVar('name'), 'post' => $this->request->getVar('post'), 'professional_profile' => $this->request->getVar('professional_profile'), 'consult_fee' => $this->request->getVar('consult_fee'), 'clinic' => $this->request->getVar('clinic'), 'year_of_experience' => $this->request->getVar('year_of_experience'), 'languages' => $this->request->getVar('languages'), 'education' => $this->request->getVar('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/lab"))->with('success', 'Lab updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/lab/edit/{$id}"))->with('errors', 'Lab Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function deleteLab($id) {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/lab'))->with('error', 'Lab not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/lab'))->with('success', 'Lab deleted successfully');
    }
    
    public function saveDoctor() {
        // Load the UserModel
        $doctorModel = new DoctorModel(); 
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', // Adjust validation rules based on your UserModel
        'clinic' => 'required', 'year_of_experience' => 'required', 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]', 'languages' => 'required', 'education' => 'required'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = ['name' => $this->request->getPost('name'), 'post' => $this->request->getPost('post'), 'professional_profile' => $this->request->getPost('professional_profile'), 'consult_fee' => $this->request->getPost('consult_fee'), 'clinic' => $this->request->getPost('clinic'), 'year_of_experience' => $this->request->getPost('year_of_experience'), 'languages' => $this->request->getPost('languages'), 'education' => $this->request->getPost('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/doctors'))->with('success', 'Doctor added successfully');
    }
    public function editDoctor($id) {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_doctor', $data);
    }
    public function updateDoctor($id) {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Doctor not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', 'clinic' => 'required', 'year_of_experience' => 'required','languages' => 'required', 'education' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $doctorData = ['name' => $this->request->getVar('name'), 'post' => $this->request->getVar('post'), 'professional_profile' => $this->request->getVar('professional_profile'), 'consult_fee' => $this->request->getVar('consult_fee'), 'clinic' => $this->request->getVar('clinic'), 'year_of_experience' => $this->request->getVar('year_of_experience'), 'languages' => $this->request->getVar('languages'), 'education' => $this->request->getVar('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/doctors"))->with('success', 'Doctor updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/doctors/edit/{$id}"))->with('errors', 'Doctor Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteDoctor($id) {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/doctors'))->with('error', 'Doctor not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/doctors'))->with('success', 'Doctor deleted successfully');
    }
     public function availableClinic() {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch all users from the 'users' table
        $data['available_clinics'] = $availableclinicModel->findAll();
        
        // Pass the data to the view
        return view('admin/available-clinics', $data);
    }
    public function addAvailableclinic() {
        return view('admin/add_available_clinics');
    }
    public function saveAvailableclinic() {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel(); 
        // Validate the form data
        $validationRules = ['clinic_name' => 'required', 'clinic_address' => 'required', 'clinic_monday' => 'required', 'clinic_tuesday' => 'required', // Adjust validation rules based on your UserModel
        'clinic_wednesday' => 'required', 'clinic_thursday' => 'required', 'clinic_image' => 'uploaded[clinic_image]|max_size[clinic_image,1024]|is_image[clinic_image]', 'clinic_friday' => 'required', 'clinic_saturday' => 'required', 'clinic_sunday' => 'required',];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $availableclinicData = ['clinic_name' => $this->request->getPost('clinic_name'), 'clinic_address' => $this->request->getPost('clinic_address'), 'clinic_monday' => $this->request->getPost('clinic_monday'), 'clinic_tuesday' => $this->request->getPost('clinic_tuesday'), 'clinic_wednesday' => $this->request->getPost('clinic_wednesday'), 'clinic_thursday' => $this->request->getPost('clinic_thursday'), 'clinic_friday' => $this->request->getPost('clinic_friday'), 'clinic_saturday' => $this->request->getPost('clinic_saturday'), 'clinic_sunday' => $this->request->getPost('clinic_sunday'), ];
        // Handle image upload
        $image = $this->request->getFile('clinic_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_clinics', $newName);
            // Update the user data with the new image name
            $availableclinicData['clinic_image'] = $newName;
        }
        // Save user data
        $availableclinicModel->insert($availableclinicData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-clinics'))->with('success', 'Clinic added successfully');
    }
    public function editAvailableclinic($clinic_id) {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch the user data based on the provided ID
        $data['available_clinic'] = $availableclinicModel->find($clinic_id);
        // Pass the data to the view
        return view('admin/edit_available_clinics', $data);
    }
    public function updateAvailableclinic($clinic_id) {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch the user data based on the provided ID
        $available_clinic = $availableclinicModel->find($clinic_id);
        // Check if the user exists
        if (!$available_clinic) {
            // Handle the case where the user is not found
            echo 'Clinic not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['clinic_name' => 'required', 'clinic_address' => 'required', 'clinic_monday' => 'required', 'clinic_tuesday' => 'required', 'clinic_wednesday' => 'required', 'clinic_thursday' => 'required','clinic_friday' => 'required', 'clinic_saturday' => 'required', 'clinic_sunday' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $availableclinicData = ['clinic_name' => $this->request->getVar('clinic_name'),
                                'clinic_address' => $this->request->getVar('clinic_address'),
                                'clinic_monday' => $this->request->getVar('clinic_monday'),
                                'clinic_tuesday' => $this->request->getVar('clinic_tuesday'),
                                'clinic_wednesday' => $this->request->getVar('clinic_wednesday'),
                                'clinic_thursday' => $this->request->getVar('clinic_thursday'),
                                'clinic_friday' => $this->request->getVar('clinic_friday'),
                                'clinic_saturday' => $this->request->getVar('clinic_saturday'),
                                'clinic_sunday' => $this->request->getVar('clinic_sunday')];
        // Handle image upload
        $image = $this->request->getFile('clinic_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_clinics', $newName);
            // Delete the old image if it exists
            if ($available_clinic['clinic_image'] && file_exists(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image'])) {
                unlink(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image']);
            }
            // Update the user data with the new image name
            $availableclinicData['clinic_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($availableclinicModel->update($clinic_id, $availableclinicData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/available-clinics/edit/{$clinic_id}"))->with('success', 'Clinic updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/available-clinics/edit/{$clinic_id}"))->with('errors', 'Clinic Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteAvailableclinic($clinic_id) {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch the user data based on the provided ID
        $available_clinic = $availableclinicModel->find($clinic_id);
        // Check if the user exists
        if (!$available_clinic) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/available-clinics'))->with('error', 'Clinic not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($available_clinic['clinic_image'] && file_exists(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image'])) {
            unlink(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image']);
        }
        // Delete the user
        $availableclinicModel->delete($clinic_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-clinics'))->with('success', 'Clinic deleted successfully');
    }
    public function availableTest() {
        // Load the UserModel
        $availableTestModel = new AvailableTestModel();
        // Fetch all users from the 'users' table
        $data['available_tests'] = $availableTestModel->findAll();
        
        // Pass the data to the view
        return view('admin/available-tests', $data);
    }
     public function addAvailabletest() {
        return view('admin/add_available_tests');
    }
    public function saveAvailabletest() {
        // Load the UserModel
        $availableTestModel = new AvailableTestModel(); 
        // Validate the form data
        $validationRules = ['test_name' => 'required', 'test_status' => 'required', 'test_tags' => 'required', 'test_image' => 'uploaded[test_image]|max_size[test_image,1024]|is_image[test_image]'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $availabletestData = ['test_name' => $this->request->getPost('test_name'), 'test_status' => $this->request->getPost('test_status'), 'test_tags' => $this->request->getPost('test_tags') ];
        // Handle image upload
        $image = $this->request->getFile('test_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_test', $newName);
            // Update the user data with the new image name
            $availabletestData['test_image'] = $newName;
        }
        // Save user data
        $availableTestModel->insert($availabletestData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-tests'))->with('success', 'Test added successfully');
    }
    public function editAvailabletest($test_id) {
        // Load the UserModel
        $availabletestModel = new AvailableTestModel();
        // Fetch the user data based on the provided ID
        $data['available_test'] = $availabletestModel->find($test_id);
        // Pass the data to the view
        return view('admin/edit_available_tests', $data);
    }
    public function updateAvailabletest($test_id) {
        // Load the UserModel
        $availabletestModel = new AvailableTestModel();
        // Fetch the user data based on the provided ID
        $available_test = $availabletestModel->find($test_id);
        // Check if the user exists
        if (!$available_test) {
            // Handle the case where the user is not found
            echo 'Test not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['test_name' => 'required', 'test_status' => 'required', 'test_tags' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $availabletestData = ['test_name' => $this->request->getVar('test_name'),
                                'test_status' => $this->request->getVar('test_status'),
                                'test_tags' => $this->request->getVar('test_tags'),];
        // Handle image upload
        $image = $this->request->getFile('test_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_test', $newName);
            // Delete the old image if it exists
            if ($available_test['test_image'] && file_exists(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image'])) {
                unlink(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image']);
            }
            // Update the user data with the new image name
            $availabletestData['test_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($availabletestModel->update($test_id, $availabletestData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/available-tests/edit/{$test_id}"))->with('success', 'Test updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/available-tests/edit/{$test_id}"))->with('errors', 'Test Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteAvailabletest($test_id) {
        // Load the UserModel
        $availabletestModel = new AvailableTestModel();
        // Fetch the user data based on the provided ID
        $available_test = $availabletestModel->find($test_id);
        // Check if the user exists
        if (!$available_test) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/available-test'))->with('error', 'Test not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($available_test['test_image'] && file_exists(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image'])) {
            unlink(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image']);
        }
        // Delete the user
        $availabletestModel->delete($test_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-tests'))->with('success', 'Test deleted successfully');
    }
    public function products() {
    
        $ProductModel = new ProductModel();
        // Fetch all users from the 'users' table
        $data['products'] = $ProductModel->findAll();
        // Pass the data to the view
        return view('admin/products', $data);
    }
    public function addProduct() {
        return view('admin/add_product');
    }
    public function saveProduct() {
    // Load the CategoryModel
    $ProductModel = new ProductModel();
    
    $validationRules = [
    'product_name' => 'required',
    'product_category_id' => 'required|numeric', // Add numeric validation
    'product_price' => 'required',
    'product_unit' => 'required|numeric',
    'product_description' => 'required',
    'product_unit_measure' => 'required|in_list[ML,KG]', // Validate against specific values
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $productData = [
        'product_name' => $this->request->getPost('product_name'),
        'product_category_id' => $this->request->getPost('product_category_id'),
        'description' => $this->request->getPost('description'),
        'product_price' => $this->request->getPost('product_price'),
        'product_unit' => $this->request->getPost('product_unit'),
        'product_unit_measure' => $this->request->getPost('product_unit_measure'),
    ];

    // Handle image upload
    $product_image = $this->request->getFile('product_image');
    if ($product_image->isValid() && !$product_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $product_image->getRandomName();
        // Move the uploaded image to the correct directory
        $product_image->move(ROOTPATH . 'public/uploads/products', $newName);
        // Update the category data with the new image name
        $productData['product_image'] = $newName;
    }

    // Save category data
    $ProductModel->insert($productData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/products'))->with('success', 'Product added successfully');
}
public function editProduct($product_id) {
        // Load the UserModel
        $ProductModel = new ProductModel();
        // Fetch the user data based on the provided ID
        $data['product'] = $ProductModel->find($product_id);
        // Pass the data to the view
        return view('admin/edit_product', $data);
    }
    public function updateProduct($product_id) {
        // Load the UserModel
        $ProductModel = new ProductModel();
        // Fetch the user data based on the provided ID
        $product = $ProductModel->find($product_id);
        // Check if the user exists
        if (!$product) {
            // Handle the case where the user is not found
            echo 'Product not found';
            die();
        }
        // Validate the form data
        $validationRules = ['product_name' => 'required', 'product_category_id' => 'required', 'product_description' => 'required', 'product_unit' => 'required', 'product_unit_measure' => 'required', 'product_price' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $productData = ['product_name' => $this->request->getVar('product_name'), 'product_category_id' => $this->request->getVar('product_category_id'), 'product_description' => $this->request->getVar('product_description'), 'product_unit' => $this->request->getVar('product_unit'), 'product_unit_measure' => $this->request->getVar('product_unit_measure'), 'product_price' => $this->request->getVar('product_price') ];
        // Handle image upload
        $product_image = $this->request->getFile('product_image');
        if ($product_image->isValid() && !$product_image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $product_image->getRandomName();
            // Move the uploaded image to the correct directory
            $product_image->move(ROOTPATH . 'public/uploads/products', $newName);
            // Delete the old image if it exists
            if ($product['product_image'] && file_exists(ROOTPATH . 'public/uploads/products/' . $product['product_image'])) {
                unlink(ROOTPATH . 'public/uploads/products/' . $product['product_image']);
            }
            // Update the user data with the new image name
            $productData['product_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($ProductModel->update($product_id, $productData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/products"))->with('success', 'Product updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/products/edit_product/{$product_id}"))->with('errors', 'Product Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteProduct($product_id) {
        // Load the UserModel
        $ProductModel = new ProductModel();
        // Fetch the user data based on the provided ID
        $product = $ProductModel->find($product_id);
        // Check if the user exists
        if (!$product) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/products'))->with('error', 'Product not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($product['product_image'] && file_exists(ROOTPATH . 'public/uploads/products/' . $product['product_image'])) {
            unlink(ROOTPATH . 'public/uploads/products/' . $product['product_image']);
        }
        // Delete the user
        $ProductModel->delete($product_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/products'))->with('success', 'Product deleted successfully');
    }
    public function guide() {
    
        $GuideModel = new GuideModel();
        // Fetch all users from the 'users' table
        $data['guide'] = $GuideModel->findAll();
        // Pass the data to the view
        return view('admin/guide', $data);
    }
    public function addGuide() {
        return view('admin/add-guide');
    }
    public function saveGuide() {
    // Load the CategoryModel
    $GuideModel = new GuideModel();
    
    $validationRules = [
    'guide_question' => 'required',
    'guide_sub_category_id' => 'required|numeric', // Add numeric validation
    'guide_answer' => 'required',
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $GuideData = [
        'guide_question' => $this->request->getPost('guide_question'),
        'guide_sub_category_id' => $this->request->getPost('guide_sub_category_id'),
        'guide_answer' => $this->request->getPost('guide_answer'),
    ];

    // Handle image upload
    $guide_image = $this->request->getFile('guide_image');
    if ($guide_image->isValid() && !$guide_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $guide_image->getRandomName();
        // Move the uploaded image to the correct directory
        $guide_image->move(ROOTPATH . 'public/uploads/guide', $newName);
        // Update the category data with the new image name
        $GuideData['guide_image'] = $newName;
    }

    // Save category data
    $GuideModel->insert($GuideData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/guide'))->with('success', 'Guide added successfully');
}
public function editGuide($guide_id) {
        // Load the UserModel
        $GuideModel = new GuideModel();
        // Fetch the user data based on the provided ID
        $data['guide'] = $GuideModel->find($guide_id);
        // Pass the data to the view
        return view('admin/edit-guide', $data);
    }
    public function updateGuide($guide_id) {
        // Load the UserModel
        $GuideModel = new GuideModel();
        // Fetch the user data based on the provided ID
        $guide = $GuideModel->find($guide_id);
        // Check if the user exists
        if (!$guide) {
            // Handle the case where the user is not found
            echo 'Guide not found';
            die();
        }
        // Validate the form data
        $validationRules = ['guide_question' => 'required', 'guide_answer' => 'required', 'guide_sub_category_id' => 'required'
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $GuideData = ['guide_question' => $this->request->getVar('guide_question'), 'guide_answer' => $this->request->getVar('guide_answer'), 'guide_sub_category_id' => $this->request->getVar('guide_sub_category_id') ];
        // Handle image upload
        $guide_image = $this->request->getFile('guide_image');
        if ($guide_image->isValid() && !$guide_image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $guide_image->getRandomName();
            // Move the uploaded image to the correct directory
            $guide_image->move(ROOTPATH . 'public/uploads/guide', $newName);
            // Delete the old image if it exists
            if ($guide['guide_image'] && file_exists(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image'])) {
                unlink(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image']);
            }
            // Update the user data with the new image name
            $GuideData['guide_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($GuideModel->update($guide_id, $GuideData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/guide/edit-guide/{$guide_id}"))->with('success', 'Guide updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/guide/edit-guide/{$guide_id}"))->with('errors', 'Guide Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
public function deleteGuide($guide_id) {
        // Load the UserModel
        $GuideModel = new GuideModel();
        // Fetch the user data based on the provided ID
        $guide = $GuideModel->find($guide_id);
        // Check if the user exists
        if (!$guide) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/guide'))->with('error', 'Guide not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($guide['guide_image'] && file_exists(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image'])) {
            unlink(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image']);
        }
        // Delete the user
        $GuideModel->delete($guide_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/guide'))->with('success', 'Guide deleted successfully');
    }
    public function healthRecord() {
    
        $HealthRecordModel = new HealthRecordModel();
        // Fetch all users from the 'users' table
        $data['health_record'] = $HealthRecordModel->findAll();
        // Pass the data to the view
        return view('admin/health-record', $data);
    }
    public function addHealthRecord() {
        return view('admin/add-health-record');
    }
    public function saveHealthRecord() {
    // Load the CategoryModel
    $HealthRecordModel = new HealthRecordModel();
    
    $validationRules = [
    'blood_name' => 'required',
    'user_id' => 'required|numeric', // Add numeric validation
    'report_date' => 'required',
    'blood' => 'required',
    'date_time' => 'required',
    'type' => 'required|in_list[Blood,Document]', // Validate against specific values
    'document' => 'uploaded[document]|mime_in[document,image/jpg,image/jpeg,image/png,application/pdf,application/msword]|max_size[document,1024]',
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $HealthRecordData = [
        'blood_name' => $this->request->getPost('blood_name'),
        'user_id' => $this->request->getPost('user_id'),
        'report_date' => $this->request->getPost('report_date'),
        'blood' => $this->request->getPost('blood'),
        'date_time' => $this->request->getPost('date_time'),
        'type' => $this->request->getPost('type'),
    ];

    // Handle image upload
    $document = $this->request->getFile('document');
    if ($document->isValid() && !$document->hasMoved()) {
        // Generate a unique name for the image
        $newName = $document->getRandomName();
        // Move the uploaded image to the correct directory
        $document->move(ROOTPATH . 'public/uploads/health_report', $newName);
        // Update the category data with the new image name
        $HealthRecordData['document'] = $newName;
    }

    // Save category data
    $HealthRecordModel->insert($HealthRecordData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/health-record'))->with('success', 'Health Record added successfully');
}
public function deleteHealthRecord($id) {
        // Load the UserModel
        $HealthRecordModel = new HealthRecordModel();
        // Fetch the user data based on the provided ID
        $healthrecord = $HealthRecordModel->find($id);
        // Check if the user exists
        if (!$healthrecord) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/health-record'))->with('error', 'Health Record found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($healthrecord['document'] && file_exists(ROOTPATH . 'public/uploads/health_report/' . $healthrecord['document'])) {
            unlink(ROOTPATH . 'public/uploads/health_report/' . $healthrecord['document']);
        }
        // Delete the user
        $HealthRecordModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/health-record'))->with('success', 'Health Record deleted successfully');
    }
    public function editHealthRecord($id) {
        // Load the UserModel
        $HealthRecordModel = new HealthRecordModel();
        // Fetch the user data based on the provided ID
        $data['health_record'] = $HealthRecordModel->find($id);
        // Pass the data to the view
        return view('admin/health-record', $data);
    }
    public function SleepManagementCategory() {
    
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch all users from the 'users' table
        $data['sleep_management_categories'] = $SleepManagementCategoryModel->findAll();
        // Pass the data to the view
        return view('admin/sleep-management-category', $data);
    }
    public function addSleepManagementCategory() {
        return view('admin/add-sleep-management-category');
    }    
    public function saveSleepManagementCategory() {
    // Load the CategoryModel
    $SleepManagementCategoryModel = new SleepManagementCategoryModel();
    
    $validationRules = [
    'smc_name' => 'required',
    'smc_status' => 'required|in_list[ACTIVE,DEACTIVE]', // Validate against specific values
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $SleepManagementCategoryData = [
        'smc_name' => $this->request->getPost('smc_name'),
        'smc_status' => $this->request->getPost('smc_status'),
    ];

  
    // Save category data
    $SleepManagementCategoryModel->insert($SleepManagementCategoryData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/sleep-management-category/add-sleep-management-category'))->with('success', 'Sleep Management Category added successfully');
}
public function editSleepManagementCategory($smc_id) {
        // Load the UserModel
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $data['sleep_management_categories'] = $SleepManagementCategoryModel->find($smc_id);
        // Pass the data to the view
        return view('admin/edit-sleep-management-category', $data);
    }
public function updateSleepManagementCategory($smc_id) {
        // Load the UserModel
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $SleepManagementCategory = $SleepManagementCategoryModel->find($smc_id);
        // Check if the user exists
        if (!$SleepManagementCategoryModel) {
            // Handle the case where the user is not found
            echo 'Sleep Management Category not found';
            die();
        }
        // Validate the form data
        $validationRules = ['smc_name' => 'required', 'smc_status' => 'required'
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SleepManagementCategoryData = ['smc_name' => $this->request->getVar('smc_name'), 'smc_status' => $this->request->getVar('smc_status')];
        
        // Update user data only if the image upload is successful
        if ($SleepManagementCategoryModel->update($smc_id, $SleepManagementCategoryData)) {
            // Redirect to the user list page with a success message
            
            return redirect()->to(base_url("admin/sleep-management-category/edit/{$smc_id}"))->with('success', 'Sleep Management Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/sleep-management-category/edit/{$smc_id}"))->with('errors', 'Sleep Management Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
public function deleteSleepManagementCategory($smc_id) {
        // Load the UserModel
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $SleepManagementCategory = $SleepManagementCategoryModel->find($smc_id);
        // Check if the user exists
        if (!$SleepManagementCategory) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sleep-management-category'))->with('error', 'Sleep Management Category Not found');
        }
        
        // Delete the user
        $SleepManagementCategoryModel->delete($smc_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep-management-category'))->with('success', 'Sleep Management Category deleted successfully');
    }
public function SonographyUltrasound() {
    
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch all users from the 'users' table
        $data['sonography_ultrasounds'] = $SonographyUltrasoundsModel->findAll();
        // Pass the data to the view
        return view('admin/sonography-ultrasound', $data);
    }
public function addSonographyUltrasound() {
        return view('admin/add-sonography-ultrasound');
    }     
public function saveSonographyUltrasound() {
    // Load the CategoryModel
    $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
    
    $validationRules = [
    'su_user_id' => 'required|numeric',
    'su_title' => 'required', 
    'su_description' => 'required', 
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $SonographyUltrasoundsData = [
        'su_user_id' => $this->request->getPost('su_user_id'),
        'su_title' => $this->request->getPost('su_title'),
        'su_description' => $this->request->getPost('su_description'),
    ];
    
     // Handle image upload
    $su_image = $this->request->getFile('su_image');
    if ($su_image->isValid() && !$su_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $su_image->getRandomName();
        // Move the uploaded image to the correct directory
        $su_image->move(ROOTPATH . 'public/uploads/sonography_ultrasounds', $newName);
        // Update the category data with the new image name
        $SonographyUltrasoundsData['su_image'] = $newName;
    }
  
    // Save category data
    $SonographyUltrasoundsModel->insert($SonographyUltrasoundsData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/sonography-ultrasound/add-sonography-ultrasound'))->with('success', 'Sonography Ultrasounds added successfully');
}
public function editSonographyUltrasound($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $SonographyUltrasoundsModel->find($su_id);
        // Pass the data to the view
        return view('admin/edit-sonography-ultrasound', $data);
    }
public function updateSonographyUltrasound($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch the user data based on the provided ID
        $SonographyUltrasounds = $SonographyUltrasoundsModel->find($su_id);
        // Check if the user exists
        if (!$SonographyUltrasounds) {
            // Handle the case where the user is not found
            echo 'Sonography Ultrasounds not found';
            die();
        }
        // Validate the form data
        $validationRules = ['su_user_id' => 'required|numeric',
                            'su_title' => 'required',
                            'su_description' => 'required'    
                            ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SonographyUltrasoundsData = ['su_user_id' => $this->request->getVar('su_user_id'),
                                      'su_title' => $this->request->getVar('su_title'),
                                      'su_description' => $this->request->getVar('su_description')
                                      ];
        // Handle image upload
        $su_image = $this->request->getFile('su_image');
        if ($su_image->isValid() && !$su_image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $su_image->getRandomName();
            // Move the uploaded image to the correct directory
            $su_image->move(ROOTPATH . 'public/uploads/sonography_ultrasounds', $newName);
            // Delete the old image if it exists
            if ($SonographyUltrasounds['su_image'] && file_exists(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image'])) {
                unlink(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image']);
            }
            // Update the user data with the new image name
            $SonographyUltrasoundsData['su_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($SonographyUltrasoundsModel->update($su_id, $SonographyUltrasoundsData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/sonography-ultrasound/edit/{$su_id}"))->with('success', 'Sonography Ultrasounds updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/sonography-ultrasound/edit/{$su_id}"))->with('errors', 'Sonography Ultrasounds Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteSonographyUltrasound($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch the user data based on the provided ID
        $SonographyUltrasounds = $SonographyUltrasoundsModel->find($su_id);
        // Check if the user exists
        if (!$SonographyUltrasounds) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sonography-ultrasound'))->with('error', 'Sonography Ultrasound not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($SonographyUltrasounds['su_image'] && file_exists(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image'])) {
            unlink(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image']);
        }
        // Delete the user
        $SonographyUltrasoundsModel->delete($su_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sonography-ultrasound'))->with('success', 'Sonography Ultrasound deleted successfully');
    }
    public function survey_question() {
    
        $SupplimentModel = new SurveyQuestionModel();
        // Fetch all users from the 'users' table
        $data['suppliment_plan'] = $SupplimentModel->findAll();
        // Pass the data to the view
        return view('admin/survey_question', $data);
    }
    
    public function withdraw_requests()
    {
        return view('admin/withdraw_requests');
    }
    
    public function withdraw_history()
    {
        return view('admin/withdraw_history');
    }
    
public function addsurvey_question() {
        return view('admin/add_survey_question');
    }
public function savesurvey_question() {
    // Load the CategoryModel
    $SupplimentModel = new SurveyQuestionModel();
    
    $validationRules = [
    'survey_id' => 'required|numeric',
    'question' => 'required', 
    'answer' => 'required',
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $SupplimentPlanData = [
        'survey_id' => $this->request->getPost('survey_id'),
        'question' => $this->request->getPost('question'),
        'answer' => $this->request->getPost('answer'),
        'option1' => $this->request->getPost('option1'),
        'option2' => $this->request->getPost('option2'),
        'option3' => $this->request->getPost('option3'),
        'option4' => $this->request->getPost('option4'),
        'rewardPoint' => $this->request->getPost('rewardPoint'),
    ];
    
    
  
    // Save category data
    $SupplimentModel->insert($SupplimentPlanData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/survey_question'))->with('success', 'Survey Question added successfully');
}
public function editsurvey_question($id) {
        // Load the UserModel
        $SupplimentModel = new SurveyQuestionModel();
        // Fetch the user data based on the provided ID
        $data['suppliment_plan'] = $SupplimentModel->find($id);
        // Pass the data to the view
        return view('admin/edit_survey_question', $data);
    }
    
public function updatesurvey_question($id) {
        // Load the UserModel
        $SupplimentModel = new SurveyQuestionModel();
        // Fetch the user data based on the provided ID
        $Suppliment = $SupplimentModel->find($id);
        // Check if the user exists
        if (!$Suppliment) {
            // Handle the case where the user is not found
            echo 'Data not found';
            die();
        }
        // Validate the form data
        $validationRules = ['survey_id' => 'required|numeric',
                            'question' => 'required',
                            'answer' => 'required',
    
                            ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SupplimentData = ['survey_id' => $this->request->getVar('survey_id'),
                                      'question' => $this->request->getVar('question'),
                                      'answer' => $this->request->getVar('answer'),
                                      'option1' => $this->request->getVar('option1'),
                                      'option2' => $this->request->getVar('option2'),
                                      'option3' => $this->request->getVar('option3'),
                                      'option4' => $this->request->getVar('option4'),
                                      'rewardPoint' => $this->request->getVar('rewardPoint')
                                      ];
       
        // Update user data only if the image upload is successful
        if ($SupplimentModel->update($id, $SupplimentData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/survey_question"))->with('success', 'Survey Question updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/survey_question/edit/{$id}"))->with('errors', 'Survey Question Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deletesurvey_question($id) {
        // Load the UserModel
        $SupplimentModel = new SurveyQuestionModel();
        // Fetch the user data based on the provided ID
        $Suppliment = $SupplimentModel->find($id);
        // Check if the user exists
        if (!$Suppliment) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/survey_question'))->with('error', 'Data not found');
        }
      
        // Delete the user
        $SupplimentModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/survey_question'))->with('success', 'Survey Question deleted successfully');
    }
    
    public function tvs_scan() {
        // Load the UserModel
        $TvsScanModel = new TvsScanModel();
        // Fetch all users from the 'users' table
        $data['tvs_scan_clinic'] = $TvsScanModel->findAll();
        
        // Pass the data to the view
        return view('admin/tvs_scan', $data);
    }
    public function addTvsscan() {
        return view('admin/add_tvs_scan');
    }
    
    public function saveTvsScan() {
        // Load the UserModel
        $TvsScanModel = new TvsScanModel(); 
        // Validate the form data
        $validationRules = ['clinic_name' => 'required', 'service_address' => 'required', 'clinic_monday' => 'required', 'clinic_tuesday' => 'required', // Adjust validation rules based on your UserModel
        'clinic_wednesday' => 'required', 'clinic_thursday' => 'required', 'clinic_image' => 'uploaded[clinic_image]|max_size[clinic_image,1024]|is_image[clinic_image]', 'clinic_friday' => 'required', 'clinic_saturday' => 'required', 'clinic_sunday' => 'required','service_address' => 'required', 'consultan_fees' => 'required',];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        
        // Get form data
        $tvsScanData = ['clinic_name' => $this->request->getPost('clinic_name'), 'service_address' => $this->request->getPost('service_address'), 'clinic_monday' => $this->request->getPost('clinic_monday'), 'clinic_tuesday' => $this->request->getPost('clinic_tuesday'), 'clinic_wednesday' => $this->request->getPost('clinic_wednesday'), 'clinic_thursday' => $this->request->getPost('clinic_thursday'), 'clinic_friday' => $this->request->getPost('clinic_friday'), 'clinic_saturday' => $this->request->getPost('clinic_saturday'), 'clinic_sunday' => $this->request->getPost('clinic_sunday'), 'service_address' => $this->request->getPost('service_address'), 'consultan_fees' => $this->request->getPost('consultan_fees'), ];
        // Handle image upload
        $image = $this->request->getFile('clinic_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/tvs_scan', $newName);
            // Update the user data with the new image name
            $tvsScanData['clinic_image'] = $newName;
        }
        // Save user data
        $TvsScanModel->insert($tvsScanData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/tvs_scan'))->with('success', 'Tvs Scan added successfully');
    }
    public function editTvsScan($id) {
        // Load the UserModel
        $TvsScanModel = new TvsScanModel();
        // Fetch the user data based on the provided ID
        $data['tvs_scan_clinic'] = $TvsScanModel->find($id);
        // Pass the data to the view
        return view('admin/edit_tvs_scan', $data);
    }
    public function updateTvsScan($id) {
        // Load the UserModel
        $TvsScanModel = new TvsScanModel();
        // Fetch the user data based on the provided ID
        $tvsscan = $TvsScanModel->find($id);
        // Check if the user exists
        if (!$tvsscan) {
            // Handle the case where the user is not found
            echo 'TVS Scan not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['clinic_name' => 'required', 'service_address' => 'required', 'clinic_monday' => 'required', 'clinic_tuesday' => 'required', 'clinic_wednesday' => 'required', 'clinic_thursday' => 'required','clinic_friday' => 'required', 'clinic_saturday' => 'required', 'clinic_sunday' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $tvsScanData = ['clinic_name' => $this->request->getVar('clinic_name'),
                                    'clinic_monday' => $this->request->getVar('clinic_monday'),
                                'clinic_tuesday' => $this->request->getVar('clinic_tuesday'),
                                'clinic_wednesday' => $this->request->getVar('clinic_wednesday'),
                                'clinic_thursday' => $this->request->getVar('clinic_thursday'),
                                'clinic_friday' => $this->request->getVar('clinic_friday'),
                                'clinic_saturday' => $this->request->getVar('clinic_saturday'),
                                'clinic_sunday' => $this->request->getVar('clinic_sunday'),
                                'service_address' => $this->request->getVar('service_address'),
                                'consultan_fees' => $this->request->getVar('consultan_fees')];
        // Handle image upload
        $image = $this->request->getFile('clinic_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/tvs_scan', $newName);
            // Delete the old image if it exists
            if ($tvsscan['clinic_image'] && file_exists(ROOTPATH . 'public/uploads/tvs_scan/' . $tvsscan['clinic_image'])) {
                unlink(ROOTPATH . 'public/uploads/tvs_scan/' . $tvsscan['clinic_image']);
            }
            // Update the user data with the new image name
            $tvsScanData['clinic_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($TvsScanModel->update($id, $tvsScanData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/tvs_scan"))->with('success', 'Tvs Scan updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_tvsscan/edit/{$id}"))->with('errors', 'Tvs Scan Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteTvsScan($id) {
        // Load the UserModel
        $TvsScanModel = new TvsScanModel();
        // Fetch the user data based on the provided ID
        $tvsscan = $TvsScanModel->find($id);
        // Check if the user exists
        if (!$tvsscan) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/tvsscan'))->with('error', 'Tvs Scan not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($tvsscan['clinic_image'] && file_exists(ROOTPATH . 'public/uploads/tvs_scan/' . $tvsscan['clinic_image'])) {
            unlink(ROOTPATH . 'public/uploads/tvs_scan/' . $tvsscan['clinic_image']);
        }
        // Delete the user
        $TvsScanModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/tvs_scan'))->with('success', 'Tvs Scan deleted successfully');
    }
    
    public function zen_book_packages() {
        // Load the UserModel
        $SleepManagementZenBookPackageModel = new SleepManagementZenBookPackageModel();
        // Fetch all users from the 'users' table
        $data['sleep_management_zen_book_packages'] = $SleepManagementZenBookPackageModel->findAll();
        
        // Pass the data to the view
        return view('admin/zen_book_packages', $data);
    }
    public function addZenBookPackages() {
        return view('admin/add_zen_book_packages');
    }
    
    public function saveZenBookPackages() {
        // Load the UserModel
        $SleepManagementZenBookPackageModel = new SleepManagementZenBookPackageModel(); 
        // Validate the form data
        $validationRules = ['zmzbp_name' => 'required', 'zmzbp_description' => 'required', 'zmzbp_image' => 'uploaded[zmzbp_image]|max_size[zmzbp_image,1024]|is_image[zmzbp_image]'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        
        // Get form data
        $SleepManagementZenBookPackageData = ['zmzbp_name' => $this->request->getPost('zmzbp_name'), 'zmzbp_description' => $this->request->getPost('zmzbp_description')];
        // Handle image upload
        $image = $this->request->getFile('zmzbp_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/zen_book', $newName);
            // Update the user data with the new image name
            $SleepManagementZenBookPackageData['zmzbp_image'] = $newName;
        }
        // Save user data
        $SleepManagementZenBookPackageModel->insert($SleepManagementZenBookPackageData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/zen_book_packages'))->with('success', 'Sleep Management ZenBook Package added successfully');
    }
    public function editZenBookPackages($id) {
        // Load the UserModel
        $SleepManagementZenBookPackageModel = new SleepManagementZenBookPackageModel();
        // Fetch the user data based on the provided ID
        $data['sleep_management_zen_book_packages'] = $SleepManagementZenBookPackageModel->find($id);
        // Pass the data to the view
        return view('admin/edit_zen_book_packages', $data);
    }
    public function updateZenBookPackages($id) {
        // Load the UserModel
        $SleepManagementZenBookPackageModel = new SleepManagementZenBookPackageModel();
        // Fetch the user data based on the provided ID
        $zenbookpackage = $SleepManagementZenBookPackageModel->find($id);
        // Check if the user exists
        if (!$zenbookpackage) {
            // Handle the case where the user is not found
            echo 'Zen Book Package not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['zmzbp_name' => 'required','zmzbp_description' => 'required' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $zenbookpackageData = ['zmzbp_name' => $this->request->getVar('zmzbp_name'),
                                    'zmzbp_description' => $this->request->getVar('zmzbp_description'),
                                ];
        // Handle image upload
        $image = $this->request->getFile('zmzbp_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/zen_book', $newName);
            // Delete the old image if it exists
            if ($zenbookpackage['zmzbp_image'] && file_exists(ROOTPATH . 'public/uploads/zen_book/' . $zenbookpackage['zmzbp_image'])) {
                unlink(ROOTPATH . 'public/uploads/zen_book/' . $zenbookpackage['zmzbp_image']);
            }
            // Update the user data with the new image name
            $zenbookpackageData['zmzbp_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($SleepManagementZenBookPackageModel->update($id, $zenbookpackageData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/zen_book_packages"))->with('success', 'Sleep Management ZenBook Package updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_tvsscan/edit/{$id}"))->with('errors', 'Sleep Management ZenBook Package Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteZenBookPackages($id) {
        // Load the UserModel
        $SleepManagementZenBookPackageModel = new SleepManagementZenBookPackageModel();
        // Fetch the user data based on the provided ID
        $zenbookpackage = $SleepManagementZenBookPackageModel->find($id);
        // Check if the user exists
        if (!$zenbookpackage) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/zen_book_packages'))->with('error', 'Sleep Management ZenBook Package not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($zenbookpackage['zmzbp_image'] && file_exists(ROOTPATH . 'public/uploads/zen_book/' . $zenbookpackage['zmzbp_image'])) {
            unlink(ROOTPATH . 'public/uploads/zen_book/' . $zenbookpackage['zmzbp_image']);
        }
        // Delete the user
        $SleepManagementZenBookPackageModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/zen_book_packages'))->with('success', 'Sleep Management ZenBook Package deleted successfully');
    }
    
    public function zen_book_category() {
        // Load the UserModel
        $ZenbooklocationCategoryModel = new ZenbooklocationCategoryModel();
        // Fetch all users from the 'users' table
        $data['zen_book_category'] = $ZenbooklocationCategoryModel->findAll();
        
        // Pass the data to the view
        return view('admin/zen_book_category', $data);
    }
    public function addZenBookCategory() {
        return view('admin/add_zen_book_category');
    }
    
    public function saveZenBookCategory() {
        // Load the UserModel
        $ZenbooklocationCategoryModel = new ZenbooklocationCategoryModel(); 
        // Validate the form data
        $validationRules = ['name' => 'required', 'status' => 'required', 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        
        // Get form data
        $ZenbooklocationCategoryData = ['name' => $this->request->getPost('name'), 'status' => $this->request->getPost('status')];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/zen_book', $newName);
            // Update the user data with the new image name
            $ZenbooklocationCategoryData['image'] = $newName;
        }
        // Save user data
        $ZenbooklocationCategoryModel->insert($ZenbooklocationCategoryData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/zen_book_category'))->with('success', 'ZenBook Category added successfully');
    }
    public function editZenBookCategory($id) {
        // Load the UserModel
        $ZenbooklocationCategoryModel = new ZenbooklocationCategoryModel();
        // Fetch the user data based on the provided ID
        $data['zen_book_category'] = $ZenbooklocationCategoryModel->find($id);
        // Pass the data to the view
        return view('admin/edit_zen_book_category', $data);
    }
    public function updateZenBookCategory($id) {
        // Load the UserModel
        $ZenbooklocationCategoryModel = new ZenbooklocationCategoryModel();
        // Fetch the user data based on the provided ID
        $zenbookcategory = $ZenbooklocationCategoryModel->find($id);
        // Check if the user exists
        if (!$zenbookcategory) {
            // Handle the case where the user is not found
            echo 'Zen Book Category not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['name' => 'required','status' => 'required' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $ZenbooklocationCategoryData = ['name' => $this->request->getVar('name'),
                                    'status' => $this->request->getVar('status'),
                                ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/zen_book', $newName);
            // Delete the old image if it exists
            if ($zenbookcategory['image'] && file_exists(ROOTPATH . 'public/uploads/zen_book/' . $zenbookcategory['image'])) {
                unlink(ROOTPATH . 'public/uploads/zen_book/' . $zenbookcategory['image']);
            }
            // Update the user data with the new image name
            $ZenbooklocationCategoryData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($ZenbooklocationCategoryModel->update($id, $ZenbooklocationCategoryData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/zen_book_category"))->with('success', 'ZenBook Category updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_zen_book_category/edit/{$id}"))->with('errors', 'ZenBook Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteZenBookCategory($id) {
        // Load the UserModel
        $ZenbooklocationCategoryModel = new ZenbooklocationCategoryModel();
        // Fetch the user data based on the provided ID
        $zenbookcategory = $ZenbooklocationCategoryModel->find($id);
        // Check if the user exists
        if (!$zenbookcategory) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/zen_book_category'))->with('error', 'ZenBook Category not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($zenbookcategory['image'] && file_exists(ROOTPATH . 'public/uploads/zen_book/' . $zenbookcategory['image'])) {
            unlink(ROOTPATH . 'public/uploads/zen_book/' . $zenbookcategory['image']);
        }
        // Delete the user
        $ZenbooklocationCategoryModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/zen_book_category'))->with('success', 'ZenBook Category deleted successfully');
    }
    
    public function sleep_management_sound_recommended() {
        // Load the UserModel
        $SleepManagementSoundRecommendedModel = new SleepManagementSoundRecommendedModel();
        // Fetch all users from the 'users' table
        $data['sleep_management_sound_recommended'] = $SleepManagementSoundRecommendedModel->findAll();
        
        // Pass the data to the view
        return view('admin/sleep_management_sound_recommended', $data);
    }
    public function addSleepManagementSoundRecommended() {
        return view('admin/add_sleep_management_sound_recommended');
    }
    
    public function saveSleepManagementSoundRecommended() {
        // Load the UserModel
        $SleepManagementSoundRecommendedModel = new SleepManagementSoundRecommendedModel(); 
        // Validate the form data
        $validationRules = ['title' => 'required', 'description' => 'required', 'status' => 'required', 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        
        // Get form data
        $SleepManagementSoundRecommendedData = ['title' => $this->request->getPost('title'),
        'description' => $this->request->getPost('description'),'status' => $this->request->getPost('status')];
        
        // print_r($SleepManagementSoundRecommendedData);
        // die;
        // echo "Debug - Status before insert: $SleepManagementSoundRecommendedData[status]"; // Check this line
        // die;
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/sleep_soundtrack_recommended', $newName);
            // Update the user data with the new image name
            $SleepManagementSoundRecommendedData['image'] = $newName;
        }
        // echo $SleepManagementSoundRecommendedData[status];
        // echo $SleepManagementSoundRecommendedData['status'];
        // die;
        // Save user data
        $SleepManagementSoundRecommendedModel->insert($SleepManagementSoundRecommendedData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep_management_sound_recommended'))->with('success', 'Sleep Management Sound Recommendation added successfully');
    }
    public function editSleepManagementSoundRecommended($id) {
        // Load the UserModel
        $SleepManagementSoundRecommendedModel = new SleepManagementSoundRecommendedModel();
        // Fetch the user data based on the provided ID
        $data['sleep_management_sound_recommended'] = $SleepManagementSoundRecommendedModel->find($id);
        // Pass the data to the view
        return view('admin/edit_sleep_management_sound_recommended', $data);
    }
    public function updateSleepManagementSoundRecommended($id) {
        // Load the UserModel
        $SleepManagementSoundRecommendedModel = new SleepManagementSoundRecommendedModel();
        // Fetch the user data based on the provided ID
        $sleepmanagementsoundrecommended = $SleepManagementSoundRecommendedModel->find($id);
        // Check if the user exists
        if (!$sleepmanagementsoundrecommended) {
            // Handle the case where the user is not found
            echo 'Sleep Management Sound Recommendation not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['title' => 'required','description' => 'required', 'status' => 'required' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SleepManagementSoundRecommendedData = ['title' => $this->request->getVar('title'),
        'status' => $this->request->getVar('status'),'description' => $this->request->getVar('description'),
                                ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/sleep_soundtrack_recommended', $newName);
            // Delete the old image if it exists
            if ($sleepmanagementsoundrecommended['image'] && file_exists(ROOTPATH . 'public/uploads/sleep_soundtrack_recommended/' . $sleepmanagementsoundrecommended['image'])) {
                unlink(ROOTPATH . 'public/uploads/sleep_soundtrack_recommended/' . $sleepmanagementsoundrecommended['image']);
            }
            // Update the user data with the new image name
            $SleepManagementSoundRecommendedData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($SleepManagementSoundRecommendedModel->update($id, $SleepManagementSoundRecommendedData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/sleep_management_sound_recommended"))->with('success', 'Sleep Management Sound Recommendation updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_sleep_management_sound_recommended/edit/{$id}"))->with('errors', 'Sleep Management Sound Recommendation Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteSleepManagementSoundRecommended($id) {
        // Load the UserModel
        $SleepManagementSoundRecommendedModel = new SleepManagementSoundRecommendedModel();
        // Fetch the user data based on the provided ID
        $sleepmanagementsoundrecommended = $SleepManagementSoundRecommendedModel->find($id);
        // Check if the user exists
        if (!$sleepmanagementsoundrecommended) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sleep_management_sound_recommended'))->with('error', 'Sleep Management Sound Recommendation not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($sleepmanagementsoundrecommended['image'] && file_exists(ROOTPATH . 'public/uploads/sleep_soundtrack_recommended/' . $sleepmanagementsoundrecommended['image'])) {
            unlink(ROOTPATH . 'public/uploads/sleep_soundtrack_recommended/' . $sleepmanagementsoundrecommended['image']);
        }
        // Delete the user
        $SleepManagementSoundRecommendedModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep_management_sound_recommended'))->with('success', 'Sleep Management Sound Recommendation deleted successfully');
    }
    
    public function sleep_management_sound_tracks_category() {
        // Load the UserModel
        $SleepManagementSoundCategoriesModel = new SleepManagementSoundCategoriesModel();
        // Fetch all users from the 'users' table
        $data['sleep_management_sound_tracks_category'] = $SleepManagementSoundCategoriesModel->findAll();
        
        // Pass the data to the view
        return view('admin/sleep_management_sound_tracks_category', $data);
    }
    public function addSleepManagementSoundTracksCategory() {
        return view('admin/add_sleep_management_sound_tracks_category');
    }
    
    public function saveSleepManagementSoundTracksCategory()
{
    // Load the SleepManagementSoundCategoriesModel
    $sleepManagementSoundCategoriesModel = new SleepManagementSoundCategoriesModel(); 
    
    // Validate the form data
    $validationRules = [
        'smst_name' => 'required',
        'smst_image' => 'uploaded[smst_image]|max_size[smst_image,1024]|is_image[smst_image]'
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $sleepManagementSoundCategoriesData = [
        'smst_name' => $this->request->getPost('smst_name')
    ];
    
    // Handle image upload
    $image = $this->request->getFile('smst_image');
    
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/sleep_soundtrack_categories', $newName);
        
        // Update the data with the new image name
        $sleepManagementSoundCategoriesData['smst_image'] = $newName;
    }

    // Save data
    $sleepManagementSoundCategoriesModel->insert($sleepManagementSoundCategoriesData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/sleep_management_sound_tracks_category'))->with('success', 'Sleep Management Sound Track Category added successfully');
}


    public function editSleepManagementSoundTracksCategory($id) {
        // Load the UserModel
        $SleepManagementSoundCategoriesModel = new SleepManagementSoundCategoriesModel();
        // Fetch the user data based on the provided ID
        $data['sleep_management_sound_tracks_category'] = $SleepManagementSoundCategoriesModel->find($id);
        // Pass the data to the view
        return view('admin/edit_sleep_management_sound_tracks_category', $data);
    }
    public function updateSleepManagementSoundTracksCategory($id) {
        // Load the UserModel
        $SleepManagementSoundCategoriesModel = new SleepManagementSoundCategoriesModel();
        // Fetch the user data based on the provided ID
        $SleepManagementSoundCategories = $SleepManagementSoundCategoriesModel->find($id);
        // Check if the user exists
        if (!$SleepManagementSoundCategories) {
            // Handle the case where the user is not found
            echo 'Sleep Management Sound Track Category not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['smst_name' => 'required' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SleepManagementSoundCategoriesData = ['smst_name' => $this->request->getVar('smst_name')];
        // Handle image upload
        $image = $this->request->getFile('smst_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/sleep_soundtrack_categories', $newName);
            // Delete the old image if it exists
            if ($SleepManagementSoundCategories['smst_image'] && file_exists(ROOTPATH . 'public/uploads/sleep_soundtrack_categories/' . $SleepManagementSoundCategories['smst_image'])) {
                unlink(ROOTPATH . 'public/uploads/sleep_soundtrack_categories/' . $SleepManagementSoundCategories['smst_image']);
            }
            // Update the user data with the new image name
            $SleepManagementSoundCategoriesData['smst_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($SleepManagementSoundCategoriesModel->update($id, $SleepManagementSoundCategoriesData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/sleep_management_sound_tracks_category"))->with('success', 'Sleep Management Sound Track Category updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_sleep_management_sound_tracks_category/edit/{$id}"))->with('errors', 'Sleep Management Sound Track Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteSleepManagementSoundTracksCategory($id) {
        // Load the UserModel
        $SleepManagementSoundCategoriesModel = new SleepManagementSoundCategoriesModel();
        // Fetch the user data based on the provided ID
        $SleepManagementSoundCategories = $SleepManagementSoundCategoriesModel->find($id);
        // Check if the user exists
        if (!$SleepManagementSoundCategories) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sleep_management_sound_tracks_category'))->with('error', 'Sleep Management Sound Track Category not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($SleepManagementSoundCategories['smst_image'] && file_exists(ROOTPATH . 'public/uploads/sleep_soundtrack_categories/' . $SleepManagementSoundCategories['smst_image'])) {
            unlink(ROOTPATH . 'public/uploads/sleep_soundtrack_categories/' . $SleepManagementSoundCategories['smst_image']);
        }
        // Delete the user
        $SleepManagementSoundCategoriesModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep_management_sound_tracks_category'))->with('success', 'Sleep Management Sound Track Category deleted successfully');
    }
    
    public function banner() {
        // Load the UserModel
        $LoveLanguageModel = new BannerModel();
        // Fetch all users from the 'users' table
        $data['love_language'] = $LoveLanguageModel->findAll();
        
        // Pass the data to the view
        return view('admin/banner', $data);
    }
    public function app_logo() {
        // Load the UserModel
        $LoveLanguageModel = new AppLogoModel();
        // Fetch all users from the 'users' table
        $data['love_language'] = $LoveLanguageModel->findAll();
        
        // Pass the data to the view
        return view('admin/app_logo', $data);
    }
    
     public function editfaq($id) {
        // Load the UserModel
        $LoveLanguageModel = new FaqModel();
        // Fetch the user data based on the provided ID
        $data['love_language'] = $LoveLanguageModel->find($id);
        // Pass the data to the view
        return view('admin/edit_faq', $data);
    }
    
     public function faq() {
        // Load the UserModel
        $LoveLanguageModel = new FaqModel();
        // Fetch all users from the 'users' table
        $data['love_language'] = $LoveLanguageModel->findAll();
        
        // Pass the data to the view
        return view('admin/faq', $data);
    }
    
    public function editsubcription($id) {
        // Load the UserModel
        $LoveLanguageModel = new SubcriptionModel();
        // Fetch the user data based on the provided ID
        $data['love_language'] = $LoveLanguageModel->find($id);
        // Pass the data to the view
        return view('admin/edit_subcription', $data);
    }
    
     public function editservices($id) {
        // Load the UserModel
        $LoveLanguageModel = new ServicesModel();
        // Fetch the user data based on the provided ID
        $data['love_language'] = $LoveLanguageModel->find($id);
        // Pass the data to the view
        return view('admin/edit_services', $data);
    }
    
       public function subcription() {
        // Load the UserModel
        $LoveLanguageModel = new SubcriptionModel();
        // Fetch all users from the 'users' table
        $data['love_language'] = $LoveLanguageModel->findAll();
        
        // Pass the data to the view
        return view('admin/subcription', $data);
    }
    
      public function services() {
        // Load the UserModel
        $LoveLanguageModel = new ServicesModel();
        // Fetch all users from the 'users' table
        $data['love_language'] = $LoveLanguageModel->findAll();
        
        // Pass the data to the view
        return view('admin/services', $data);
    }
    
    
    
    public function addbanner() {
        return view('admin/add_banner');
    }
    
    public function addservices() {
        return view('admin/add_services');
    }
    
    public function addsubcription() {
        return view('admin/add_subcription');
    }
    
     public function addfaq() {
        return view('admin/add_faq');
    }
    
    public function savefaq()
{
    // Load the SleepManagementSoundCategoriesModel
    $LoveLanguageModel = new FaqModel(); 
    
    // Validate the form data
    $validationRules = [
       'question' => 'required',
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $LoveLanguageData = [
        'question' => $this->request->getPost('question'),
        'answer' => $this->request->getPost('answer')
    ];
    
  
    // Save data
    $LoveLanguageModel->insert($LoveLanguageData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/faq'))->with('success', 'faq added successfully');
}


 public function savesubcription()
{
    // Load the SleepManagementSoundCategoriesModel
    $LoveLanguageModel = new SubcriptionModel(); 
    
    // Validate the form data
    $validationRules = [
       'day' => 'required',
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $LoveLanguageData = [
        'amount' => $this->request->getPost('amount'),
         'day' => $this->request->getPost('day'),
        'status' => $this->request->getPost('status')
    ];
    
 

    // Save data
    $LoveLanguageModel->insert($LoveLanguageData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/subcription'))->with('success', 'Subcription added successfully');
}
    
    
    public function saveservices()
{
    // Load the SleepManagementSoundCategoriesModel
    $LoveLanguageModel = new ServicesModel(); 
    
    // Validate the form data
    $validationRules = [
       'service_name' => 'required',
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $LoveLanguageData = [
        'service_name' => $this->request->getPost('service_name'),
        'status' => $this->request->getPost('status')
    ];
    
    // Handle image upload
    $image = $this->request->getFile('ser_image');
    
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/services', $newName);
        
        // Update the data with the new image name
        $LoveLanguageData['ser_image'] = $newName;
    }

    // Save data
    $LoveLanguageModel->insert($LoveLanguageData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/services'))->with('success', 'Services added successfully');
}

    
    public function savebanner()
{
    // Load the SleepManagementSoundCategoriesModel
    $LoveLanguageModel = new BannerModel(); 
    
    // Validate the form data
    $validationRules = [
        'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]'
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $LoveLanguageData = [
        'status' => $this->request->getPost('status')
    ];
    
    // Handle image upload
    $image = $this->request->getFile('image');
    
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/banner', $newName);
        
        // Update the data with the new image name
        $LoveLanguageData['image'] = $newName;
    }

    // Save data
    $LoveLanguageModel->insert($LoveLanguageData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/banner'))->with('success', 'Banner added successfully');
}


 public function deletebanner($id) {
        // Load the UserModel
        $userModel = new BannerModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/banner'))->with('error', 'Banner not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/banner/' . $user['image'])) {
            unlink(ROOTPATH . 'public/uploads/banner/' . $user['image']);
        }
        // Delete the user
        $userModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/banner'))->with('success', 'Banner deleted successfully');
    }
    
      public function editapp_logo($id) {
        // Load the UserModel
        $LoveLanguageModel = new AppLogoModel();
        // Fetch the user data based on the provided ID
        $data['love_language'] = $LoveLanguageModel->find($id);
        // Pass the data to the view
        return view('admin/edit_app_logo', $data);
    }

    public function editbanner($id) {
        // Load the UserModel
        $LoveLanguageModel = new BannerModel();
        // Fetch the user data based on the provided ID
        $data['love_language'] = $LoveLanguageModel->find($id);
        // Pass the data to the view
        return view('admin/edit_banner', $data);
    }
    
    
    public function updateapp_logo($id) {
        // Load the UserModel
        $LoveLanguageModel = new AppLogoModel();
        // Fetch the user data based on the provided ID
        $LoveLanguage = $LoveLanguageModel->find($id);
        // Check if the user exists
        if (!$LoveLanguage) {
            // Handle the case where the user is not found
            echo 'app_logo not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['status' => 'required' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $LoveLanguageData = ['status' => $this->request->getVar('status')];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/app_logo', $newName);
            // Delete the old image if it exists
            if ($LoveLanguage['image'] && file_exists(ROOTPATH . 'public/uploads/app_logo/' . $LoveLanguage['image'])) {
                unlink(ROOTPATH . 'public/uploads/app_logo/' . $LoveLanguage['image']);
            }
            // Update the user data with the new image name
            $LoveLanguageData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($LoveLanguageModel->update($id, $LoveLanguageData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/app_logo"))->with('success', 'logo updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/editapp_logo/edit/{$id}"))->with('errors', 'app_logo Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
    public function updatebanner($id) {
        // Load the UserModel
        $LoveLanguageModel = new BannerModel();
        // Fetch the user data based on the provided ID
        $LoveLanguage = $LoveLanguageModel->find($id);
        // Check if the user exists
        if (!$LoveLanguage) {
            // Handle the case where the user is not found
            echo 'Banner not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['status' => 'required' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $LoveLanguageData = ['status' => $this->request->getVar('status')];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/banner', $newName);
            // Delete the old image if it exists
            if ($LoveLanguage['image'] && file_exists(ROOTPATH . 'public/uploads/banner/' . $LoveLanguage['image'])) {
                unlink(ROOTPATH . 'public/uploads/banner/' . $LoveLanguage['image']);
            }
            // Update the user data with the new image name
            $LoveLanguageData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($LoveLanguageModel->update($id, $LoveLanguageData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/banner"))->with('success', 'Banner updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_banner/edit/{$id}"))->with('errors', 'Banner Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteLoveLanguage($id) {
        // Load the UserModel
        $LoveLanguageModel = new LoveLanguageModel();
        // Fetch the user data based on the provided ID
        $LoveLanguage = $LoveLanguageModel->find($id);
        // Check if the user exists
        if (!$LoveLanguage) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/love_language'))->with('error', 'Love Language not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($LoveLanguage['image'] && file_exists(ROOTPATH . 'public/uploads/love_language/' . $LoveLanguage['image'])) {
            unlink(ROOTPATH . 'public/uploads/love_language/' . $LoveLanguage['image']);
        }
        // Delete the user
        $LoveLanguageModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/love_language'))->with('success', 'Love Language deleted successfully');
    }
    
    public function peace_category() {
        // Load the UserModel
        $PeaceCategoryModel = new PeaceCategoryModel();
        // Fetch all users from the 'users' table
        $data['peace_category'] = $PeaceCategoryModel->findAll();
        
        // Pass the data to the view
        return view('admin/peace_category', $data);
    }
    public function addPeaceCategory() {
        return view('admin/add_peace_category');
    }
    
    public function savePeaceCategory()
{
    // Load the SleepManagementSoundCategoriesModel
    $PeaceCategoryModel = new PeaceCategoryModel(); 
    
    // Validate the form data
    $validationRules = [
        'name' => 'required',
        'status' => 'required',
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $PeaceCategoryData = [
        'name' => $this->request->getPost('name'),
        'status' => $this->request->getPost('status')
    ];
    
    // Save data
    $PeaceCategoryModel->insert($PeaceCategoryData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/peace_category'))->with('success', 'Peace Category added successfully');
}


    public function editPeaceCategory($id) {
        // Load the UserModel
        $PeaceCategoryModel = new PeaceCategoryModel();
        // Fetch the user data based on the provided ID
        $data['peace_category'] = $PeaceCategoryModel->find($id);
        // Pass the data to the view
        return view('admin/edit_peace_category', $data);
    }
    public function updatePeaceCategory($id) {
        // Load the UserModel
        $PeaceCategoryModel = new PeaceCategoryModel();
        // Fetch the user data based on the provided ID
        $PeaceCategory = $PeaceCategoryModel->find($id);
        // Check if the user exists
        if (!$PeaceCategory) {
            // Handle the case where the user is not found
            echo 'Peace Category not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['name' => 'required','status' => 'required' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $PeaceCategoryData = ['name' => $this->request->getVar('name'), 'status' => $this->request->getVar('status')];
        
        // Update user data only if the image upload is successful
        if ($PeaceCategoryModel->update($id, $PeaceCategoryData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/peace_category"))->with('success', 'Peace Category updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_peace_category/edit/{$id}"))->with('errors', 'Peace Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deletePeaceCategory($id) {
        // Load the UserModel
        $PeaceCategoryModel = new PeaceCategoryModel();
        // Fetch the user data based on the provided ID
        $PeaceCategory = $PeaceCategoryModel->find($id);
        // Check if the user exists
        if (!$PeaceCategory) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/peace_category'))->with('error', 'Peace Category not found');
        }
       
        // Delete the user
        $PeaceCategoryModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/peace_category'))->with('success', 'Peace Category deleted successfully');
    }
    
    public function love_sublanguage() {
        // Load the UserModel
        $LovesubLanguageModel = new LovesubLanguageModel();
        // Fetch all users from the 'users' table
        $data['love_sublanguage'] = $LovesubLanguageModel->findAll();
        
        // Pass the data to the view
        return view('admin/love_sublanguage', $data);
    }
    public function addLoveSubLanguage() {
        return view('admin/add_love_sublanguage');
    }
    
    public function saveLoveSubLanguage()
{
    // Load the SleepManagementSoundCategoriesModel
    $LovesubLanguageModel = new LovesubLanguageModel(); 
    
    // Validate the form data
    $validationRules = [
        'name' => 'required',
        'love_language_id' => 'required|numeric', // Add numeric validation
        'description' => 'required',
        'status' => 'required',
        'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]'
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $LovesubLanguageData = [
        'name' => $this->request->getPost('name'),
        'love_language_id' => $this->request->getPost('love_language_id'),
        'description' => $this->request->getPost('description'),
        'status' => $this->request->getPost('status')
    ];
    
    // Handle image upload
    $image = $this->request->getFile('image');
    
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/love_language', $newName);
        
        // Update the data with the new image name
        $LovesubLanguageData['image'] = $newName;
    }

    // Save data
    $LovesubLanguageModel->insert($LovesubLanguageData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/love_sublanguage'))->with('success', 'Love Sub Language added successfully');
}


    public function editLoveSubLanguage($id) {
        // Load the UserModel
        $LovesubLanguageModel = new LovesubLanguageModel();
        // Fetch the user data based on the provided ID
        $data['love_sublanguage'] = $LovesubLanguageModel->find($id);
        // Pass the data to the view
        return view('admin/edit_love_sublanguage', $data);
    }
    public function updateLoveSubLanguage($id) {
        // Load the UserModel
        $LovesubLanguageModel = new LovesubLanguageModel();
        // Fetch the user data based on the provided ID
        $LovesubLanguage = $LovesubLanguageModel->find($id);
        // Check if the user exists
        if (!$LovesubLanguage) {
            // Handle the case where the user is not found
            echo 'Love Sub Language not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['name' => 'required','status' => 'required','description' => 'required', 'love_language_id' => 'required|numeric' 
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $LovesubLanguageData = ['name' => $this->request->getVar('name'), 'status' => $this->request->getVar('status'), 'description' => $this->request->getVar('description')];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/love_language', $newName);
            // Delete the old image if it exists
            if ($LovesubLanguage['image'] && file_exists(ROOTPATH . 'public/uploads/love_language/' . $LovesubLanguage['image'])) {
                unlink(ROOTPATH . 'public/uploads/love_language/' . $LovesubLanguage['image']);
            }
            // Update the user data with the new image name
            $LovesubLanguageData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($LovesubLanguageModel->update($id, $LovesubLanguageData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/love_sublanguage"))->with('success', 'Love Sub Language updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_love_sublanguage/edit/{$id}"))->with('errors', 'Love Sub Language Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteLoveSubLanguage($id) {
        // Load the UserModel
        $LovesubLanguageModel = new LovesubLanguageModel();
        // Fetch the user data based on the provided ID
        $LovesubLanguage = $LovesubLanguageModel->find($id);
        // Check if the user exists
        if (!$LovesubLanguage) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/love_sublanguage'))->with('error', 'Love Sub Language not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($LovesubLanguage['image'] && file_exists(ROOTPATH . 'public/uploads/love_language/' . $LovesubLanguage['image'])) {
            unlink(ROOTPATH . 'public/uploads/love_language/' . $LovesubLanguage['image']);
        }
        // Delete the user
        $LovesubLanguageModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/love_sublanguage'))->with('success', 'Love Sub Language deleted successfully');
    }
    
    public function sleep_management_video_list_discover() {
        // Load the UserModel
        $SleepManagementVideoListDiscoverModel = new SleepManagementVideoListDiscoverModel();
        // Fetch all users from the 'users' table
        $data['sleep_management_video_list_discover'] = $SleepManagementVideoListDiscoverModel->findAll();
        
        // Pass the data to the view
        return view('admin/sleep_management_video_list_discover', $data);
    }
    public function addSleepManagementVideoListDiscover() {
        return view('admin/add_sleep_management_video_list_discover');
    }
    
    public function saveSleepManagementVideoListDiscover()
{
    // Load the SleepManagementSoundCategoriesModel
    $SleepManagementVideoListDiscoverModel = new SleepManagementVideoListDiscoverModel();
    
    // Validate the form data
    $validationRules = [
        'name' => 'required',
        'filter_id' => 'required|numeric', // Add numeric validation
        'type' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]',
        // 'video' => 'uploaded[video]|max_size[video,1024]|is_video[video]',
        'status' => 'required',
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add user form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }
    
    // Get form data
    $SleepManagementVideoListDiscoverData = [
        'name' => $this->request->getPost('name'),
        'filter_id' => $this->request->getPost('filter_id'),
        'type' => $this->request->getPost('type'),
        'status' => $this->request->getPost('status'),
    ];
    
    // Handle image upload
    $image = $this->request->getFile('image');
    
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/sleep_video_list_discover', $newName);
        
        // Update the data with the new image name
        $SleepManagementVideoListDiscoverData['image'] = $newName;
    }
    
    // Handle video upload
    $video = $this->request->getFile('video');
    if ($video->isValid() && !$video->hasMoved()) {
        // Check if the file is a valid video file
        if ($video->getClientMimeType() == 'video/mp4' || $video->getClientMimeType() == 'video/quicktime') {
            // Generate a unique name for the video
            $newName = $video->getRandomName();
            // Move the uploaded video to the correct directory
            $video->move(ROOTPATH . 'public/uploads/sleep_video_list_discover', $newName);
            // Update the category data with the new video name
            $SleepManagementVideoListDiscoverData['video'] = $newName;
        } else {
            // Invalid video file format
            return redirect()->back()->withInput()->with('errors', ['video' => 'Invalid video file format']);
        }
    }

    // Save data
    $SleepManagementVideoListDiscoverModel->insert($SleepManagementVideoListDiscoverData);

    // Redirect to the user list page with a success message
    return redirect()->to(base_url('admin/sleep_management_video_list_discover'))->with('success', 'Sleep Management Video List Discover added successfully');
}


    public function editSleepManagementVideoListDiscover($id) {
        // Load the UserModel
        $SleepManagementVideoListDiscoverModel = new SleepManagementVideoListDiscoverModel();
        // Fetch the user data based on the provided ID
        $data['sleep_management_video_list_discover'] = $SleepManagementVideoListDiscoverModel->find($id);
        // Pass the data to the view
        return view('admin/edit_sleep_management_video_list_discover', $data);
    }
    public function updateSleepManagementVideoListDiscover($id) {
        // Load the UserModel
        $SleepManagementVideoListDiscoverModel = new SleepManagementVideoListDiscoverModel();
        // Fetch the user data based on the provided ID
        $SleepManagementVideoListDiscover = $SleepManagementVideoListDiscoverModel->find($id);
        // Check if the user exists
        if (!$SleepManagementVideoListDiscover) {
            // Handle the case where the user is not found
            echo 'Sleep Management Video List Discover not found';
            die();
        }
        
        // Validate the form data
        $validationRules = [
            'name' => 'required',
            'filter_id' => 'required|numeric', // Add numeric validation
            'type' => 'required',
            // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]',
            // 'video' => 'uploaded[video]|max_size[video,1024]|is_video[video]',
            'status' => 'required'    
            ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SleepManagementVideoListDiscoverData = ['name' => $this->request->getVar('name'),
                                                 'filter_id' => $this->request->getVar('filter_id'),
                                                 'type' => $this->request->getVar('type'),
                                                 'status' => $this->request->getVar('status'),
                                                 ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/sleep_video_list_discover', $newName);
            // Delete the old image if it exists
            if ($SleepManagementVideoListDiscover['image'] && file_exists(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['image'])) {
                unlink(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['image']);
            }
            // Update the user data with the new image name
            $SleepManagementVideoListDiscoverData['image'] = $newName;
        }
        
        // Handle banner video upload
        $video = $this->request->getFile('video');
        if ($video->isValid() && !$video->hasMoved()) {
            // Check if the file is a valid video file
            if ($video->getClientMimeType() == 'video/mp4' || $video->getClientMimeType() == 'video/quicktime') {
            // Generate a unique name for the image
            $newName = $video->getRandomName();
            // Move the uploaded image to the correct directory
            $video->move(ROOTPATH . 'public/uploads/sleep_video_list_discover', $newName);
            // Delete the old video if it exists
            if ($SleepManagementVideoListDiscover['video'] && file_exists(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['video'])) {
                unlink(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['video']);
            }
            // Update the user data with the new image name
            $SleepManagementVideoListDiscoverData['video'] = $newName;
        }
        else {
            // Invalid video file format
            return redirect()->back()->withInput()->with('errors', ['video' => 'Invalid video file format']);
        }
    }
    
        // Update user data only if the image upload is successful
        if ($SleepManagementVideoListDiscoverModel->update($id, $SleepManagementVideoListDiscoverData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/sleep_management_video_list_discover"))->with('success', 'Sleep Management Video List Discover updated successfully');
            // return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/edit_sleep_management_video_list_discover/edit/{$id}"))->with('errors', 'Sleep Management Video List Discover Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteSleepManagementVideoListDiscover($id) {
        // Load the UserModel
        $SleepManagementVideoListDiscoverModel = new SleepManagementVideoListDiscoverModel();
        // Fetch the user data based on the provided ID
        $SleepManagementVideoListDiscover = $SleepManagementVideoListDiscoverModel->find($id);
        // Check if the user exists
        if (!$SleepManagementVideoListDiscover) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sleep_management_video_list_discover'))->with('error', 'Sleep Management Video List Discover not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($SleepManagementVideoListDiscover['image'] && file_exists(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['image'])) {
            unlink(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['image']);
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($SleepManagementVideoListDiscover['video'] && file_exists(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['video'])) {
            unlink(ROOTPATH . 'public/uploads/sleep_video_list_discover/' . $SleepManagementVideoListDiscover['video']);
        }
        // Delete the user
        $SleepManagementVideoListDiscoverModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep_management_video_list_discover'))->with('success', 'Sleep Management Video List Discover deleted successfully');
    }
    
    public function ebooks() {
        // Load the UserModel
        $EbookByCategoryModel = new EbookByCategoryModel();
        // Fetch all users from the 'users' table
        $data['ebooks'] = $EbookByCategoryModel->findAll();
        
        // Pass the data to the view
        return view('admin/ebooks', $data);
    }
    public function addEbooks() {
        return view('admin/add_ebooks');
    }
    
}
