<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\DoctorModel;
use App\Models\LabModel;
use App\Models\SubCategoryModel;
use App\Models\AvailableClinicModel;
use App\Models\EmplyeeLeaveModel;
use App\Models\AvailableTestModel;
use App\Models\CategoryModel;
use App\Models\ForumTopicModel;
use App\Models\ForumDiscussionModel;
use App\Models\MainCategoryModel;
use App\Models\PersonalTrainerModel;
use App\Models\AdminModel;
use App\Models\WorkoutModel;
use App\Models\WorkoutTypeModel;

use App\Models\SleepDiscoverFiltersModel;
use App\Models\RomanticspotCategoryModel;
use App\Models\FindCategoryCoachModel;
use CodeIgniter\Files\File;
use App\Models\Admin_common_model;
class Admindata extends BaseController {
    
    public function __construct()
    {
         define("SITE_URL", 'https://server-php-8-2.technorizen.com/nuru/');
         define("SITE_EMAIL",'');
           $db = db_connect();
           $this->Admin_common_model = new Admin_common_model($db);
           header('Access-Control-Allow-Origin: *');
            //   $session = \Config\Services::session($config); 
           
            helper(['form', 'url']); 
    }
    
    public function index() {
        return view('admin/index');
    }
    public function register() {
        return view('admin/register');
    }
    
    public function postRegister()
{
    $session = \Config\Services::session();

    // Get user input from the form
    $email = $this->request->getVar('email');
    $password = $this->request->getPost('password');

    // Check if the email is already registered
    $existingUser = $this->Admin_common_model->get_where('users', ['email' => $email]);

    if ($existingUser) {
        $session->setFlashdata('error', 'Email is already registered.');
        return $this->response->redirect(site_url('/admin/register'));
    }

    // Proceed with user registration
    $userData = [
        'email' => $email,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        // Add other fields as needed
    ];

    // Use the DB helper to insert data
    $db = \Config\Database::connect();
    $db->table('users')->insert($userData);
    
    // Set success message in the session
    $session->setFlashdata('success', 'Registration successful!');

    // Set session data for the registered user
    $sessionData = [
        'id' => $db->insertID(),
        'email' => $email,
        'logged_in' => TRUE,
    ];

    $session->set($sessionData);

    // Redirect to the dashboard or another page after successful registration
    return redirect()->to(base_url('admin/login'));
}


public function login()
{
    $session = \Config\Services::session();

    $email = $this->request->getVar('email');
    $password = $this->request->getPost('password');

    // Fetch the user by email
    $user = $this->Admin_common_model->get_where('users', ['email' => $email]);

    if ($user) {
        // Verify the provided password with the hashed password in the database
        if (password_verify($password, $user[0]['password'])) {
            $data['user'] = [
                'id' => $user[0]['id'],
                'email' => $user[0]['email'],
                'logged_in' => TRUE
            ];

            // Set success message as tempdata
            $session->setTempdata('success', 'Login successful!', 5); // 5 seconds

            // Set session data
            $session->set($data);

            // Redirect to the dashboard to avoid form resubmission
            return redirect()->to(base_url('admin/dashboard'));
        }
    }

    // Set flashdata for error message
    $session->setFlashdata('error', 'Invalid Username and Password. Log in failed.');

    // Redirect back to the login page to avoid form resubmission
    return redirect()->to(base_url('admin'));
}

    public function dashboard() {
        
    $session = \Config\Services::session();
    
    if (!$session) {
        return redirect()->to(base_url('admin/login'));
    }
    
    // Continue with rendering the dashboard
        return view('admin/dashboard');
    }
    
    public function admin_logout(){
          $session = \Config\Services::session();
          $session->destroy();
          return redirect()->to(base_url('admin/login'));
  }
  
   public function add_find_coach_category() {
        return view('admin/add_find_coach_category');
    }

  
  public function find_coach_category() {
        // Load the UserModel
        $doctorModel = new FindCategoryCoachModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/find_coach_category', $data);
    }
    
     public function delete_find_coach_category($id) {
        // Load the UserModel
        $doctorModel = new FindCategoryCoachModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/find_coach_category'))->with('error', 'Find Category Coach  Type not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/find_coach_category'))->with('success', 'Find Category Coach  Type deleted successfully');
    }
    
    public function save_find_coach_category() {
        // Load the UserModel
        $doctorModel = new FindCategoryCoachModel(); 
        // Validate the form data
        
         $validationRules = [
    'name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
             'name' => $this->request->getPost('name')
             ];
        // Handle image upload
        
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/expert_consultations', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/find_coach_category'))->with('success', 'find_coach_category added successfully');
    }
    
     public function edit_find_coach_category($id) {
        // Load the UserModel
        $doctorModel = new FindCategoryCoachModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_find_coach_category', $data);
    }
    
    
     public function update_find_coach_category($id) {
        // Load the UserModel
        $doctorModel = new FindCategoryCoachModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Data not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $doctorData = [
            
               'name' => $this->request->getPost('name')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/expert_consultations', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/expert_consultations/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/expert_consultations/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/find_coach_category"))->with('success', 'find_coach_category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/find_coach_category/edit/{$id}"))->with('errors', 'find_coach_category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
    public function expert_consultations($id) {
        // Load the UserModel
        $doctorModel = new FindCategoryCoachModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/find_coach_category'))->with('error', 'Data not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/expert_consultations/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/expert_consultations/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/find_coach_category'))->with('success', 'Data deleted successfully');
    }
    
   
   public function romantic_spot_category() {
        // Load the UserModel
        $doctorModel = new RomanticspotCategoryModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/romantic_spot_category', $data);
    }
    
    public function add_romantic_spot_category() {
        return view('admin/add_romantic_spot_category');
    }


public function edit_romantic_spot_category($id) {
        // Load the UserModel
        $doctorModel = new RomanticspotCategoryModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_romantic_spot_category', $data);
    }
    
    public function save_romantic_spot_category() {
        // Load the UserModel
        $doctorModel = new RomanticspotCategoryModel(); 
        // Validate the form data
        
         $validationRules = [
    'name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
             'name' => $this->request->getPost('name')
             ];
        // Handle image upload
        
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/romantic_spot_category', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/romantic_spot_category'))->with('success', 'forum_topic_Description added successfully');
    }
    
    public function update_romantic_spot_category($id) {
        // Load the UserModel
        $doctorModel = new RomanticspotCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Data not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $doctorData = [
            
               'name' => $this->request->getPost('name')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/romantic_spot_category', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/romantic_spot_category/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/romantic_spot_category/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/romantic_spot_category"))->with('success', 'romantic_spot_category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/romantic_spot_category/edit/{$id}"))->with('errors', 'romantic_spot_category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
     public function delete_romantic_spot_category($id) {
        // Load the UserModel
        $doctorModel = new RomanticspotCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/romantic_spot_category'))->with('error', 'Data not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/romantic_spot_category/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/romantic_spot_category/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/romantic_spot_category'))->with('success', 'Data deleted successfully');
    }
    
  
  public function saveSubCategory() {
        // Load the UserModel
        $doctorModel = new SubCategoryModel(); 
        // Validate the form data
        
         $validationRules = [
    'name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
            'category_id' => $this->request->getPost('category_id'),
             'name' => $this->request->getPost('name'),
              'description' => $this->request->getPost('description'),
               'screen_type' => $this->request->getPost('screen_type')
            ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/sub_categories', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sub_category'))->with('success', 'Sub_category added successfully');
    }


   
   public function add_sleep_feature_type() {
        return view('admin/add_sleep_feature_type');
    }
    
    
 public function sleep_feature_type() {
        // Load the UserModel
        $doctorModel = new SleepDiscoverFiltersModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/sleep_feature_type', $data);
    }
    
    
    
       public function save_sleep_feature_type() {
        // Load the UserModel
        $doctorModel = new SleepDiscoverFiltersModel(); 
        // Validate the form data
        
         $validationRules = [
    'smc_name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
             'smc_name' => $this->request->getPost('smc_name')];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep_feature_type'))->with('success', 'Sleep Feature Type  added successfully');
    }
    
    
 public function edit_sleep_feature_type($id) {
        // Load the UserModel
        $doctorModel = new SleepDiscoverFiltersModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_sleep_feature_type', $data);
    }
    
    
    public function update_sleep_feature_type($id) {
        // Load the UserModel
        $doctorModel = new SleepDiscoverFiltersModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Data  not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'smc_name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'smc_name' => $this->request->getPost('smc_name')
            ];
            
        
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/sleep_feature_type"))->with('success', 'Sleep Feature Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/sleep_feature_type/edit/{$id}"))->with('errors', 'Sleep Feature Type Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
     public function delete_sleep_feature_type($id) {
        // Load the UserModel
        $doctorModel = new SleepDiscoverFiltersModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sleep_feature_type'))->with('error', 'Sleep Feature Type not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep_feature_type'))->with('success', 'Sleep Feature Type deleted successfully');
    }
    
    
  
    public function category() {
    
        $categoryModel = new CategoryModel();
        // Fetch all users from the 'users' table
        $data['categories'] = $categoryModel->findAll();
        // Pass the data to the view
        return view('admin/category', $data);
    }
    public function addCategory() {
        return view('admin/add_category');
    }
    public function saveCategory() {
    // Load the CategoryModel
    $categoryModel = new CategoryModel();
    
    $validationRules = [
    'category_name' => 'required',
    'main_category_id' => 'required|numeric', // Add numeric validation
    // 'description' => 'required',
    'type' => 'required|in_list[SIMPLE,PROGRESS_BAR]', // Validate against specific values
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $categoryData = [
        'category_name' => $this->request->getPost('category_name'),
        'main_category_id' => $this->request->getPost('main_category_id'),
        'description' => $this->request->getPost('description'),
        'type' => $this->request->getPost('type'),
    ];

    // Handle image upload
    $image = $this->request->getFile('category_image');
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/categories', $newName);
        // Update the category data with the new image name
        $categoryData['category_image'] = $newName;
    }

    // Save category data
    $categoryModel->insert($categoryData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/category'))->with('success', 'Category added successfully');
}
public function editCategory($category_id) {
        // Load the UserModel
        $categoryModel = new CategoryModel();
        // Fetch the user data based on the provided ID
        $data['category'] = $categoryModel->find($category_id);
        // Pass the data to the view
        return view('admin/edit_category', $data);
    }
    public function updateCategory($category_id) {
        // Load the UserModel
        $categoryModel = new CategoryModel();
        // Fetch the user data based on the provided ID
        $category = $categoryModel->find($category_id);
        // Check if the user exists
        if (!$category) {
            // Handle the case where the user is not found
            echo 'Category not found';
            die();
        }
        // Validate the form data
        $validationRules = ['category_name' => 'required', 'main_category_id' => 'required', 'description' => 'required', 'type' => 'required'
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $categoryData = ['category_name' => $this->request->getVar('category_name'), 'main_category_id' => $this->request->getVar('main_category_id'), 'description' => $this->request->getVar('description'), 'type' => $this->request->getVar('type') ];
        // Handle image upload
        $image = $this->request->getFile('category_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/categories', $newName);
            // Delete the old image if it exists
            if ($category['category_image'] && file_exists(ROOTPATH . 'public/uploads/categories/' . $category['category_image'])) {
                unlink(ROOTPATH . 'public/uploads/categories/' . $category['category_image']);
            }
            // Update the user data with the new image name
            $categoryData['category_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($categoryModel->update($category_id, $categoryData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/category"))->with('success', 'Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/category/edit/{$category_id}"))->with('errors', 'Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
public function deleteCategory($category_id) {
        // Load the UserModel
        $categoryModel = new CategoryModel();
        // Fetch the user data based on the provided ID
        $category = $categoryModel->find($category_id);
        // Check if the user exists
        if (!$category) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/category'))->with('error', 'Category not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($category['category_image'] && file_exists(ROOTPATH . 'public/uploads/categories/' . $category['category_image'])) {
            unlink(ROOTPATH . 'public/uploads/categories/' . $category['category_image']);
        }
        // Delete the user
        $categoryModel->delete($category_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/category'))->with('success', 'Category deleted successfully');
    }
    public function mainCategory() {
    
        $MainCategoryModel = new MainCategoryModel();
        // Fetch all users from the 'users' table
        $data['main_categories'] = $MainCategoryModel->findAll();
        // Pass the data to the view
        return view('admin/main-category', $data);
    }
     public function addMaincategory() {
        return view('admin/add_main_category');
    }
    public function saveMaincategory() {
    // Load the CategoryModel
    $MainCategoryModel = new MainCategoryModel();
    
    $validationRules = [
        'name' => 'required',
        'status' => 'required', // Use colon instead of square brackets
        'description' => 'required',
        'image' => 'uploaded[image]|mime_in[image,image/jpg,image/jpeg,image/png]|max_size[image,1024]',
         // Adjust max size as needed
    ];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $maincategoryData = [
        'name' => $this->request->getPost('name'),
        'description' => $this->request->getPost('description'),
        'status' => $this->request->getPost('status'),
    ];

    // Handle image upload
    $image = $this->request->getFile('image');
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
        // Update the category data with the new image name
        $maincategoryData['image'] = $newName;
    }
    
    // Handle image upload
    $banner_image = $this->request->getFile('banner_image');
    if ($banner_image->isValid() && !$banner_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $banner_image->getRandomName();
        // Move the uploaded image to the correct directory
        $banner_image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
        // Update the category data with the new image name
        $maincategoryData['banner_image'] = $newName;
    }
    
    // Handle video upload
    $banner_video = $this->request->getFile('banner_video');
    if ($banner_video->isValid() && !$banner_video->hasMoved()) {
        // Check if the file is a valid video file
        if ($banner_video->getClientMimeType() == 'video/mp4' || $banner_video->getClientMimeType() == 'video/quicktime') {
            // Generate a unique name for the video
            $newName = $banner_video->getRandomName();
            // Move the uploaded video to the correct directory
            $banner_video->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Update the category data with the new video name
            $maincategoryData['banner_video'] = $newName;
        } else {
            // Invalid video file format
            return redirect()->back()->withInput()->with('errors', ['banner_video' => 'Invalid video file format']);
        }
    }

    // Save category data
    $MainCategoryModel->insert($maincategoryData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/main-category'))->with('success', 'Main Category added successfully');
}
public function editMainCategory($id) {
        // Load the UserModel
        $MainCategoryModel = new MainCategoryModel();
        // Fetch the user data based on the provided ID
        $data['maincategory'] = $MainCategoryModel->find($id);
        // Pass the data to the view
        return view('admin/edit_main_category', $data);
    }
    public function updateMainCategory($id) {
        // Load the UserModel
        $MainCategoryModel = new MainCategoryModel();
        // Fetch the user data based on the provided ID
        $maincategory = $MainCategoryModel->find($id);
        // Check if the user exists
        if (!$maincategory) {
            // Handle the case where the user is not found
            echo 'Main Category not found';
            die();
        }
        // Validate the form data
        $validationRules = ['name' => 'required', 'status' => 'required', 'description' => 'required'
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $MainCategoryData = ['name' => $this->request->getVar('name'), 'status' => $this->request->getVar('status'), 'description' => $this->request->getVar('description')];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Delete the old image if it exists
            if ($maincategory['image'] && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['image'])) {
                unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['image']);
            }
            // Update the user data with the new image name
            $MainCategoryData['image'] = $newName;
        }
        
        // Handle banner image upload
        $image = $this->request->getFile('banner_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Delete the old image if it exists
            if ($maincategory['banner_image'] && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_image'])) {
                unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_image']);
            }
            // Update the user data with the new image name
            $MainCategoryData['banner_image'] = $newName;
        }
        
         // Handle banner video upload
        $banner_video = $this->request->getFile('banner_video');
        if ($banner_video->isValid() && !$banner_video->hasMoved()) {
            // Check if the file is a valid video file
            if ($banner_video->getClientMimeType() == 'video/mp4' || $banner_video->getClientMimeType() == 'video/quicktime') {
            // Generate a unique name for the image
            $newName = $banner_video->getRandomName();
            // Move the uploaded image to the correct directory
            $banner_video->move(ROOTPATH . 'public/uploads/main_categories', $newName);
            // Delete the old video if it exists
            if ($maincategory['banner_video'] && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_video'])) {
                unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_video']);
            }
            // Update the user data with the new image name
            $MainCategoryData['banner_video'] = $newName;
        }
        else {
            // Invalid video file format
            return redirect()->back()->withInput()->with('errors', ['banner_video' => 'Invalid video file format']);
        }
    }
    
        // Update user data only if the image upload is successful
        if ($MainCategoryModel->update($id, $MainCategoryData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/main-category"))->with('success', 'Main Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/main-category/edit/{$id}"))->with('errors', 'Main Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
public function deleteMaincategory($id) {
        // Load the UserModel
        $MainCategoryModel = new MainCategoryModel();
        // Fetch the user data based on the provided ID
        $maincategory = $MainCategoryModel->find($id);
        // Check if the user exists
        if (!$maincategory) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/main-category'))->with('error', 'Main Category not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($maincategory['image'] && file_exists(ROOTPATH . 'public/uploads/main-categories/' . $maincategory['image'])) {
            unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['image']);
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($maincategory['banner_image'] && file_exists(ROOTPATH . 'public/uploads/main-categories/' . $maincategory['banner_image'])) {
            unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_image']);
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($maincategory['banner_video'] && file_exists(ROOTPATH . 'public/uploads/main-categories/' . $maincategory['banner_video'])) {
            unlink(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_video']);
        }
        // Delete the user
        $MainCategoryModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/main-category'))->with('success', 'Main Category deleted successfully');
    }
    /*
    public function login() {
        $session = session();
        $model = new AdminModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $user = $model->where('admin_email', $email)->first();
        if ($user) {
            if (password_verify($password, $user['admin_password'])) {
                $session->set('user_id', $user['admin_id']);
                 return redirect()->to(base_url('admin/dashboard'))->with('success', 'Login Successfull.');
            } else {
                $session->setFlashdata('error', 'Invalid password');
            }
        } else {
            $session->setFlashdata('error', 'Invalid email');
        }
        return redirect()->to(base_url('admin'))->with('error', 'Invalid Creadentials');
        //return view('index');
        
    }
    */
    public function users() {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch all users from the 'users' table
        $data['users'] = $userModel->findAll();
        // Pass the data to the view
        return view('admin/users', $data);
    }
    public function editUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/edit_user', $data);
    }
    public function updateUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            echo 'User not found';
            die();
        }
        // Validate the form data
        $validationRules = ['user_name' => 'required', 'email' => 'required', 'company_name' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $userData = ['user_name' => $this->request->getVar('user_name'), 'email' => $this->request->getVar('email'), 'company_name' => $this->request->getVar('company_name'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/users', $newName);
            // Delete the old image if it exists
            if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
                unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
            }
            // Update the user data with the new image name
            $userData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($userModel->update($id, $userData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/users/edit/{$id}"))->with('success', 'User updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/users/edit/{$id}"))->with('errors', 'User Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function viewUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $data['user'] = $userModel->find($id);
        // Pass the data to the view
        return view('admin/view-user', $data);
    }
    public function addUser() {
        return view('admin/add_user');
    }
    public function saveUser() {
        // Load the UserModel
        $userModel = new UserModel();
        // Validate the form data
        $validationRules = ['user_name' => 'required', 'email' => 'required|valid_email', 'company_name' => 'required', 'mobile' => 'permit_empty|numeric', // Adjust validation rules based on your UserModel
        'gender' => 'permit_empty|in_list[male,female]', 'dob' => 'permit_empty|valid_date', 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]', ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $userData = ['user_name' => $this->request->getPost('user_name'), 'email' => $this->request->getPost('email'), 'company_name' => $this->request->getPost('company_name'), 'mobile' => $this->request->getPost('mobile'), 'gender' => $this->request->getPost('gender'), 'dob' => $this->request->getPost('dob'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/users', $newName);
            // Update the user data with the new image name
            $userData['image'] = $newName;
        }
        // Save user data
        $userModel->insert($userData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/users'))->with('success', 'User added successfully');
    }
    public function deleteUser($id) {
        // Load the UserModel
        $userModel = new UserModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/users'))->with('error', 'User not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])) {
            unlink(ROOTPATH . 'public/uploads/users/' . $user['image']);
        }
        // Delete the user
        $userModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/users'))->with('success', 'User deleted successfully');
    }
    
    
     public function deletebanner($id) {
        // Load the UserModel
        $userModel = new BannerModel();
        // Fetch the user data based on the provided ID
        $user = $userModel->find($id);
        // Check if the user exists
        if (!$user) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/banner'))->with('error', 'Banner not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($user['image'] && file_exists(ROOTPATH . 'public/uploads/banner/' . $user['image'])) {
            unlink(ROOTPATH . 'public/uploads/banner/' . $user['image']);
        }
        // Delete the user
        $userModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/banner'))->with('success', 'Banner deleted successfully');
    }
    
    public function deleteTrainer($id) {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/trainer'))->with('error', 'trainer not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['personal_trainer_image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['personal_trainer_image'])) {
            unlink(ROOTPATH . 'public/uploads/personal_trainers/' . $doctor['personal_trainer_image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/trainer'))->with('success', 'Trainer deleted successfully');
    }
    
    public function trainer() {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch all users from the 'users' table
        $data['trainer'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/trainer', $data);
    }
    
    public function editProgressworkout_type($id) {
        // Load the UserModel
        
        $doctorModel1 = new WorkoutTypeModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel1->find($id);
        // Pass the data to the view
        return view('admin/edit_progress_workout_type', $data);
    }
    
    public function deleteProgressworkout_type($id) {
        // Load the UserModel
        $doctorModel = new WorkoutTypeModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/progress_workout_type'))->with('error', 'progress_workout not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['wt_image'] && file_exists(ROOTPATH . 'public/uploads/workout_types/' . $doctor['wt_image'])) {
            unlink(ROOTPATH . 'public/uploads/workout_types/' . $doctor['wt_image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/progress_workout_type'))->with('success', 'Progress Workout Type deleted successfully');
    }
    
      public function updateProgressworkout_type($id) {
        // Load the UserModel
        $doctorModel = new WorkoutTypeModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Progress workout Type not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'wt_name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'wt_name' => $this->request->getPost('wt_name')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('wt_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/workout_types', $newName);
            // Delete the old image if it exists
            if ($doctor['wt_image'] && file_exists(ROOTPATH . 'public/uploads/workout/' . $doctor['wt_image'])) {
                unlink(ROOTPATH . 'public/uploads/workout_types/' . $doctor['wt_image']);
            }
            // Update the user data with the new image name
            $doctorData['wt_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/progress_workout_type"))->with('success', 'Progress Workout Type updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/progress_workout_type/edit/{$id}"))->with('errors', 'Progress Workout Type Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
     public function saveProgressworkout_type() {
        // Load the UserModel
        $doctorModel = new WorkoutTypeModel(); 
        // Validate the form data
        $validationRules = [
            'wt_name' => 'required'
           ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = [
            'wt_name' => $this->request->getPost('wt_name')
            ];
        // Handle image upload
        $image = $this->request->getFile('wt_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/workout_types', $newName);
            // Update the user data with the new image name
            $doctorData['wt_image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/progress_workout_type'))->with('success', 'Progress workout Type added successfully');
    }
    
    public function saveProgressworkout() {
        // Load the UserModel
        $doctorModel = new WorkoutModel(); 
        // Validate the form data
        $validationRules = [
            'description' => 'required'
           ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = [
            'personal_trainer_user_name' => $this->request->getPost('description')
            ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/workout', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/progress_workout'))->with('success', 'Progress_workout added successfully');
    }
    
     public function editProgressworkout($id) {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_progress_workout', $data);
    }
    
    public function deleteProgressworkout($id) {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/progress_workout'))->with('error', 'progress_workout not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/workout/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/workout/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/progress_workout'))->with('success', 'Progress Workout deleted successfully');
    }
    
    
    
    public function progress_workout() {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/progress_workout', $data);
    }
    
    public function edit_intimacy_category($id) {
        // Load the UserModel
        $doctorModel = new IntimacyCategoryModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_intimacy_category', $data);
    }
    

public function update_intimacy_category($id) {
        // Load the UserModel
        $doctorModel = new IntimacyCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Data  not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'name' => $this->request->getPost('name')
            ];
            
        
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/intimacy_category"))->with('success', 'Intimacy Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/intimacy_category/edit/{$id}"))->with('errors', 'intimacy_category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function delete_intimacy_category($id) {
        // Load the UserModel
        $doctorModel = new IntimacyCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/intimacy_category'))->with('error', 'intimacy_category not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/intimacy_category'))->with('success', 'intimacy_category deleted successfully');
    }
    
     public function intimacy_category() {
        // Load the UserModel
        $doctorModel = new IntimacyCategoryModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/intimacy_category', $data);
    }
    
    

  public function save_intimacy_category() {
        // Load the UserModel
        $doctorModel = new IntimacyCategoryModel(); 
        // Validate the form data
        
         $validationRules = [
    'name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
             'name' => $this->request->getPost('name')];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/intimacy_category'))->with('success', 'intimacy_category added successfully');
    }

    
     public function progress_workout_type() {
        // Load the UserModel
        $doctorModel = new WorkoutTypeModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/progress_workout_type', $data);
    }
    
     public function delete_forum_topic($id) {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/forum_topic'))->with('error', 'forum_topic not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic'))->with('success', 'forum_topic deleted successfully');
    }
    
     public function update_forum_topic($id) {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'forum topic  not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'name' => $this->request->getPost('name')
            ];
            
        
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/forum_topic"))->with('success', 'Forum Topic updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/forum_topic/edit/{$id}"))->with('errors', 'forum_topic Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function edit_forum_topic($id) {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_forum_topic', $data);
    }
    
     public function save_forum_topic() {
        // Load the UserModel
        $doctorModel = new ForumTopicModel(); 
        // Validate the form data
        
         $validationRules = [
    'name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
             'name' => $this->request->getPost('name')];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic'))->with('success', 'forum_topic added successfully');
    }
    
    public function delete_forum_topic_discussion($id) {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/forum_topic_discussion'))->with('error', 'forum_topic not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic_discussion'))->with('success', 'forum_topic_discussion deleted successfully');
    }
    
     public function update_forum_topic_discussion($id) {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'forum topic Discussion  not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'title' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
       
            
             'title' => $this->request->getPost('title'),
             'description' => $this->request->getPost('description'),
             'topic_id' => $this->request->getPost('topic_id')
             ];
            
        
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/forum_topic_discussion"))->with('success', 'Forum Topic Discussion updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/forum_topic_discussion/edit/{$id}"))->with('errors', 'forum_topic_discussion Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
    public function add_intimacy_category() {
        return view('admin/add_intimacy_category');
    }
    
    public function add_intimacy_management_blogs() {
        return view('admin/add_intimacy_management_blogs');
    }
    
    
 public function edit_intimacy_management_blogs($id) {
        // Load the UserModel
        $doctorModel = new IntimacyManagementBlogModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_intimacy_management_blogs', $data);
    }
    
     public function intimacy_management_blogs() {
        // Load the UserModel
        $doctorModel = new IntimacyManagementBlogModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/intimacy_management_blogs', $data);
    }
    
     public function delete_intimacy_management_blogs($id) {
        // Load the UserModel
        $doctorModel = new IntimacyManagementBlogModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/intimacy_management_blogs'))->with('error', 'Data not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['imb_image'] && file_exists(ROOTPATH . 'public/uploads/intimacy_management_blogs/' . $doctor['imb_image'])) {
            unlink(ROOTPATH . 'public/uploads/intimacy_management_blogs/' . $doctor['imb_image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/intimacy_management_blogs'))->with('success', 'Intimacy Management Blogs deleted successfully');
    }
    
    public function update_intimacy_management_blogs($id) {
        // Load the UserModel
        $doctorModel = new IntimacyManagementBlogModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Description not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'imb_title' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $doctorData = [
            'imb_intimacy_management_categories_id' => $this->request->getPost('imb_intimacy_management_categories_id'),
             'imb_title' => $this->request->getPost('imb_title'),
              'imb_description' => $this->request->getPost('imb_description')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('imb_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/intimacy_management_blogs', $newName);
            // Delete the old image if it exists
            if ($doctor['imb_image'] && file_exists(ROOTPATH . 'public/uploads/intimacy_management_blogs/' . $doctor['imb_image'])) {
                unlink(ROOTPATH . 'public/uploads/intimacy_management_blogs/' . $doctor['imb_image']);
            }
            // Update the user data with the new image name
            $doctorData['imb_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/intimacy_management_blogs"))->with('success', 'intimacy_management_blogs updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/intimacy_management_blogs/edit/{$id}"))->with('errors', 'intimacy_management_blogs Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
    
    public function save_intimacy_management_blogs() {
        // Load the UserModel
        $doctorModel = new IntimacyManagementBlogModel(); 
        // Validate the form data
        
         $validationRules = [
    'imb_title' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
            
             'imb_title' => $this->request->getPost('imb_title'),
             'imb_description' => $this->request->getPost('imb_description'),
             'imb_intimacy_management_categories_id' => $this->request->getPost('imb_intimacy_management_categories_id')
             ];
        // Handle image upload
        
        $image = $this->request->getFile('imb_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/intimacy_management_blogs', $newName);
            // Update the user data with the new image name
            $doctorData['imb_image'] = $newName;
        }
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/intimacy_management_blogs'))->with('success', 'intimacy_management_blogs added successfully');
    }
    
     
    public function update_forum_categories($id) {
        // Load the UserModel
        $doctorModel = new EmplyeeLeaveModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Description not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'status' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $status1 = $this->request->getPost('status');
         
         if($status1=='Accept')
         {
            $doctorData = [
            'status' => $this->request->getPost('status')
            ]; 
         }
         if($status1=='Reject')
         {
           $doctorData = [
            'status' => $this->request->getPost('status'),
             'admin_reply' => $this->request->getPost('admin_reply')
            ];
         }
         
         
    
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/forum_categories"))->with('success', 'User Leave Status updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/forum_categories/edit/{$id}"))->with('errors', ' Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
     public function save_forum_categories() {
        // Load the UserModel
        $doctorModel = new ForumCategoriesModel(); 
        // Validate the form data
        
         $validationRules = [
    'title' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
            
             'title' => $this->request->getPost('title'),
             'type' => $this->request->getPost('type'),
             'description' => $this->request->getPost('description'),
             'forum_discussion_id' => $this->request->getPost('forum_discussion_id')
             ];
        // Handle image upload
        
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/forum', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_categories'))->with('success', 'forum_topic_Description added successfully');
    }
    
     public function save_forum_topic_discussion() {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel(); 
        // Validate the form data
        
         $validationRules = [
    'title' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
            
             'title' => $this->request->getPost('title'),
             'description' => $this->request->getPost('description'),
             'topic_id' => $this->request->getPost('topic_id')
             ];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_topic_discussion'))->with('success', 'forum_topic_discussion added successfully');
    }
    
      public function edit_forum_topic_discussion($id) {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_forum_topic_discussion', $data);
    }
    
     public function edit_forum_categories($id) {
        // Load the UserModel
        $doctorModel = new EmplyeeLeaveModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_forum_categories', $data);
    }
    
      public function forum_topic_discussion() {
        // Load the UserModel
        $doctorModel = new ForumDiscussionModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/forum_topic_discussion', $data);
    }
    
    public function delete_forum_categories($id) {
        // Load the UserModel
        $doctorModel = new ForumCategoriesModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/forum_categories'))->with('error', 'Data not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/forum/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/forum/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/forum_categories'))->with('success', 'Data deleted successfully');
    }
    
     public function forum_categories() {
        // Load the UserModel
        $doctorModel = new EmplyeeLeaveModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/forum_categories', $data);
    }
    
     public function forum_topic() {
        // Load the UserModel
        $doctorModel = new ForumTopicModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/forum_topic', $data);
    }
    
     public function editSubCategory($id) {
        // Load the UserModel
        $doctorModel = new SubCategoryModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_sub_category', $data);
    }
    
    public function sub_category() {
        // Load the UserModel
        $doctorModel = new SubCategoryModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/sub_category', $data);
    }
    
     public function deleteSubCategory($id) {
        // Load the UserModel
        $doctorModel = new SubCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sub_category'))->with('error', 'sub_categories not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/sub_categories/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/sub_categories/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sub_category'))->with('success', 'Sub Categories deleted successfully');
    }
    
     public function updateSubCategory($id) {
        // Load the UserModel
        $doctorModel = new SubCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Sub Category not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
         $doctorData = [
            'category_id' => $this->request->getPost('category_id'),
             'name' => $this->request->getPost('name'),
              'description' => $this->request->getPost('description'),
               'screen_type' => $this->request->getPost('screen_type')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/sub_categories', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/sub_categories/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/sub_categories/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/sub_category"))->with('success', 'Sub Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/sub_category/edit/{$id}"))->with('errors', 'Sub Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function updateProgressworkout($id) {
        // Load the UserModel
        $doctorModel = new WorkoutModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Progress workout not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'description' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'description' => $this->request->getPost('description')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/workout', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/workout/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/workout/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/progress_workout"))->with('success', 'Progress Workout updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/progress_workout/edit/{$id}"))->with('errors', 'Progress Workout Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
    

     public function save_intimacy_management_category() {
        // Load the UserModel
        $doctorModel = new IntimacyManagementCategoryModel(); 
        // Validate the form data
        
         $validationRules = [
    'imc_name' => 'required', // Validate against specific values
];
      
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
             
        // Get form data
        $doctorData = [
       
             'imc_name' => $this->request->getPost('imc_name')];
        // Handle image upload
        
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/intimacy_management_category'))->with('success', 'intimacy_management_category added successfully');
    }
    
      public function intimacy_management_category() {
        // Load the UserModel
        $doctorModel = new IntimacyManagementCategoryModel();
        // Fetch all users from the 'users' table
        $data['progress_workout'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/intimacy_management_category', $data);
    }
    
     public function add_intimacy_management_category() {
        return view('admin/add_intimacy_management_category');
    }
    
    
      public function edit_intimacy_management_category($id) {
        // Load the UserModel
        $doctorModel = new IntimacyManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_intimacy_management_category', $data);
    }


    
    public function update_intimacy_management_category($id) {
        // Load the UserModel
        $doctorModel = new IntimacyManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Data  not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'imc_name' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'imc_name' => $this->request->getPost('imc_name')
            ];
            
        
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/intimacy_management_category"))->with('success', 'intimacy_management_category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/intimacy_management_category/edit/{$id}"))->with('errors', 'intimacy_management_category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    
     public function delete_intimacy_management_category($id) {
        // Load the UserModel
        $doctorModel = new IntimacyManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/intimacy_management_category'))->with('error', 'intimacy_management_category not found');
        }
       
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/intimacy_management_category'))->with('success', 'intimacy_management_category deleted successfully');
    }
    
    
     public function lab() {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch all users from the 'users' table
        $data['lab'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/lab', $data);
    }
    
    public function doctors() {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch all users from the 'users' table
        $data['doctors'] = $doctorModel->findAll();
        // Pass the data to the view
        return view('admin/doctors', $data);
    }
    
    public function addDoctor() {
        return view('admin/add_doctor');
    }
    public function addLab() {
        return view('admin/add_lab');
    }
    
    public function addTrainer() {
        return view('admin/add_trainer');
    }
    public function addProgressworkout() {
        return view('admin/add_progress_workout');
    }
    public function addProgressworkout_type() {
        return view('admin/add_progress_workout_type');
    }
     public function addSubcategory() {
        return view('admin/add_sub_category');
    }
    public function add_forum_topic() {
        return view('admin/add_forum_topic');
    }
    
    public function add_forum_topic_discussion() {
        return view('admin/add_forum_topic_discussion');
    }
     public function add_forum_categories() {
        return view('admin/add_forum_categories');
    }
    
    public function updateTrainer($id) {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Trainer not found';
            die();
        }
        
        // Validate the form data
      $validationRules = [
            'personal_trainer_email' => 'required',
            'personal_trainer_user_name' => 'required',
            'personal_trainer_company_name' => 'required',
            'personal_trainer_mobile' => 'required', 
            'personal_trainer_gender' => 'required',
            'personal_trainer_dob' => 'required'
           ];       
           

        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        
        $doctorData = [
            'personal_trainer_user_name' => $this->request->getPost('personal_trainer_user_name'),
            'personal_trainer_email' => $this->request->getPost('personal_trainer_email'),
            'personal_trainer_company_name' => $this->request->getPost('personal_trainer_company_name'),
            'personal_trainer_mobile' => $this->request->getPost('personal_trainer_mobile'),
            'personal_trainer_gender' => $this->request->getPost('personal_trainer_gender'),
            'personal_trainer_dob' => $this->request->getPost('personal_trainer_dob')
            ];
            
        // Handle image upload
        $image = $this->request->getFile('personal_trainer_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/personal_trainers', $newName);
            // Delete the old image if it exists
            if ($doctor['personal_trainer_image'] && file_exists(ROOTPATH . 'public/uploads/personal_trainers/' . $doctor['personal_trainer_image'])) {
                unlink(ROOTPATH . 'public/uploads/personal_trainers/' . $doctor['personal_trainer_image']);
            }
            // Update the user data with the new image name
            $doctorData['personal_trainer_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/trainer"))->with('success', 'Trainer updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/trainer/edit/{$id}"))->with('errors', 'Trainer Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function saveTrainer() {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel(); 
        // Validate the form data
        $validationRules = [
            'personal_trainer_email' => 'required',
            'personal_trainer_user_name' => 'required',
            'personal_trainer_company_name' => 'required',
            'personal_trainer_mobile' => 'required', 
            'personal_trainer_gender' => 'required',
            'personal_trainer_dob' => 'required'
           ];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = [
            'personal_trainer_user_name' => $this->request->getPost('personal_trainer_user_name'),
            'personal_trainer_email' => $this->request->getPost('personal_trainer_email'),
            'personal_trainer_company_name' => $this->request->getPost('personal_trainer_company_name'),
            'personal_trainer_mobile' => $this->request->getPost('personal_trainer_mobile'),
            'personal_trainer_gender' => $this->request->getPost('personal_trainer_gender'),
            'personal_trainer_dob' => $this->request->getPost('personal_trainer_dob')
            ];
        // Handle image upload
        $image = $this->request->getFile('personal_trainer_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/personal_trainers', $newName);
            // Update the user data with the new image name
            $doctorData['personal_trainer_image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/trainer'))->with('success', 'Trainer added successfully');
    }
    
     public function editTrainer($id) {
        // Load the UserModel
        $doctorModel = new PersonalTrainerModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_trainer', $data);
    }
    
    public function saveLab() {
        // Load the UserModel
        $doctorModel = new LabModel(); 
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', // Adjust validation rules based on your UserModel
        'clinic' => 'required', 'year_of_experience' => 'required', 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]', 'languages' => 'required', 'education' => 'required'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = ['name' => $this->request->getPost('name'), 'post' => $this->request->getPost('post'), 'professional_profile' => $this->request->getPost('professional_profile'), 'consult_fee' => $this->request->getPost('consult_fee'), 'clinic' => $this->request->getPost('clinic'), 'year_of_experience' => $this->request->getPost('year_of_experience'), 'languages' => $this->request->getPost('languages'), 'education' => $this->request->getPost('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/lab'))->with('success', 'Lab Member added successfully');
    }
    
    public function editLab($id) {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_lab', $data);
    }
    
    public function updateLab($id) {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Lab not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', 'clinic' => 'required', 'year_of_experience' => 'required','languages' => 'required', 'education' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $doctorData = ['name' => $this->request->getVar('name'), 'post' => $this->request->getVar('post'), 'professional_profile' => $this->request->getVar('professional_profile'), 'consult_fee' => $this->request->getVar('consult_fee'), 'clinic' => $this->request->getVar('clinic'), 'year_of_experience' => $this->request->getVar('year_of_experience'), 'languages' => $this->request->getVar('languages'), 'education' => $this->request->getVar('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/lab"))->with('success', 'Lab updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/lab/edit/{$id}"))->with('errors', 'Lab Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
    public function deleteLab($id) {
        // Load the UserModel
        $doctorModel = new LabModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/lab'))->with('error', 'Lab not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/lab'))->with('success', 'Lab deleted successfully');
    }
    
    public function saveDoctor() {
        // Load the UserModel
        $doctorModel = new DoctorModel(); 
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', // Adjust validation rules based on your UserModel
        'clinic' => 'required', 'year_of_experience' => 'required', 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]', 'languages' => 'required', 'education' => 'required'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $doctorData = ['name' => $this->request->getPost('name'), 'post' => $this->request->getPost('post'), 'professional_profile' => $this->request->getPost('professional_profile'), 'consult_fee' => $this->request->getPost('consult_fee'), 'clinic' => $this->request->getPost('clinic'), 'year_of_experience' => $this->request->getPost('year_of_experience'), 'languages' => $this->request->getPost('languages'), 'education' => $this->request->getPost('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Save user data
        $doctorModel->insert($doctorData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/doctors'))->with('success', 'Doctor added successfully');
    }
    public function editDoctor($id) {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch the user data based on the provided ID
        $data['doctor'] = $doctorModel->find($id);
        // Pass the data to the view
        return view('admin/edit_doctor', $data);
    }
    public function updateDoctor($id) {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            echo 'Doctor not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['name' => 'required', 'post' => 'required', 'professional_profile' => 'required', 'consult_fee' => 'required', 'clinic' => 'required', 'year_of_experience' => 'required','languages' => 'required', 'education' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $doctorData = ['name' => $this->request->getVar('name'), 'post' => $this->request->getVar('post'), 'professional_profile' => $this->request->getVar('professional_profile'), 'consult_fee' => $this->request->getVar('consult_fee'), 'clinic' => $this->request->getVar('clinic'), 'year_of_experience' => $this->request->getVar('year_of_experience'), 'languages' => $this->request->getVar('languages'), 'education' => $this->request->getVar('education'), ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/doctors', $newName);
            // Delete the old image if it exists
            if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
                unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
            }
            // Update the user data with the new image name
            $doctorData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($doctorModel->update($id, $doctorData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/doctors"))->with('success', 'Doctor updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/doctors/edit/{$id}"))->with('errors', 'Doctor Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteDoctor($id) {
        // Load the UserModel
        $doctorModel = new DoctorModel();
        // Fetch the user data based on the provided ID
        $doctor = $doctorModel->find($id);
        // Check if the user exists
        if (!$doctor) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/doctors'))->with('error', 'Doctor not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($doctor['image'] && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])) {
            unlink(ROOTPATH . 'public/uploads/doctors/' . $doctor['image']);
        }
        // Delete the user
        $doctorModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/doctors'))->with('success', 'Doctor deleted successfully');
    }
     public function availableClinic() {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch all users from the 'users' table
        $data['available_clinics'] = $availableclinicModel->findAll();
        
        // Pass the data to the view
        return view('admin/available-clinics', $data);
    }
    public function addAvailableclinic() {
        return view('admin/add_available_clinics');
    }
    public function saveAvailableclinic() {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel(); 
        // Validate the form data
        $validationRules = ['clinic_name' => 'required', 'clinic_address' => 'required', 'clinic_monday' => 'required', 'clinic_tuesday' => 'required', // Adjust validation rules based on your UserModel
        'clinic_wednesday' => 'required', 'clinic_thursday' => 'required', 'clinic_image' => 'uploaded[clinic_image]|max_size[clinic_image,1024]|is_image[clinic_image]', 'clinic_friday' => 'required', 'clinic_saturday' => 'required', 'clinic_sunday' => 'required',];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $availableclinicData = ['clinic_name' => $this->request->getPost('clinic_name'), 'clinic_address' => $this->request->getPost('clinic_address'), 'clinic_monday' => $this->request->getPost('clinic_monday'), 'clinic_tuesday' => $this->request->getPost('clinic_tuesday'), 'clinic_wednesday' => $this->request->getPost('clinic_wednesday'), 'clinic_thursday' => $this->request->getPost('clinic_thursday'), 'clinic_friday' => $this->request->getPost('clinic_friday'), 'clinic_saturday' => $this->request->getPost('clinic_saturday'), 'clinic_sunday' => $this->request->getPost('clinic_sunday'), ];
        // Handle image upload
        $image = $this->request->getFile('clinic_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_clinics', $newName);
            // Update the user data with the new image name
            $availableclinicData['clinic_image'] = $newName;
        }
        // Save user data
        $availableclinicModel->insert($availableclinicData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-clinics'))->with('success', 'Clinic added successfully');
    }
    public function editAvailableclinic($clinic_id) {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch the user data based on the provided ID
        $data['available_clinic'] = $availableclinicModel->find($clinic_id);
        // Pass the data to the view
        return view('admin/edit_available_clinics', $data);
    }
    public function updateAvailableclinic($clinic_id) {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch the user data based on the provided ID
        $available_clinic = $availableclinicModel->find($clinic_id);
        // Check if the user exists
        if (!$available_clinic) {
            // Handle the case where the user is not found
            echo 'Clinic not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['clinic_name' => 'required', 'clinic_address' => 'required', 'clinic_monday' => 'required', 'clinic_tuesday' => 'required', 'clinic_wednesday' => 'required', 'clinic_thursday' => 'required','clinic_friday' => 'required', 'clinic_saturday' => 'required', 'clinic_sunday' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $availableclinicData = ['clinic_name' => $this->request->getVar('clinic_name'),
                                'clinic_address' => $this->request->getVar('clinic_address'),
                                'clinic_monday' => $this->request->getVar('clinic_monday'),
                                'clinic_tuesday' => $this->request->getVar('clinic_tuesday'),
                                'clinic_wednesday' => $this->request->getVar('clinic_wednesday'),
                                'clinic_thursday' => $this->request->getVar('clinic_thursday'),
                                'clinic_friday' => $this->request->getVar('clinic_friday'),
                                'clinic_saturday' => $this->request->getVar('clinic_saturday'),
                                'clinic_sunday' => $this->request->getVar('clinic_sunday')];
        // Handle image upload
        $image = $this->request->getFile('clinic_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_clinics', $newName);
            // Delete the old image if it exists
            if ($available_clinic['clinic_image'] && file_exists(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image'])) {
                unlink(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image']);
            }
            // Update the user data with the new image name
            $availableclinicData['clinic_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($availableclinicModel->update($clinic_id, $availableclinicData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/available-clinics/edit/{$clinic_id}"))->with('success', 'Clinic updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/available-clinics/edit/{$clinic_id}"))->with('errors', 'Clinic Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteAvailableclinic($clinic_id) {
        // Load the UserModel
        $availableclinicModel = new AvailableClinicModel();
        // Fetch the user data based on the provided ID
        $available_clinic = $availableclinicModel->find($clinic_id);
        // Check if the user exists
        if (!$available_clinic) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/available-clinics'))->with('error', 'Clinic not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($available_clinic['clinic_image'] && file_exists(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image'])) {
            unlink(ROOTPATH . 'public/uploads/available_clinics/' . $available_clinic['clinic_image']);
        }
        // Delete the user
        $availableclinicModel->delete($clinic_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-clinics'))->with('success', 'Clinic deleted successfully');
    }
    public function availableTest() {
        // Load the UserModel
        $availableTestModel = new AvailableTestModel();
        // Fetch all users from the 'users' table
        $data['available_tests'] = $availableTestModel->findAll();
        
        // Pass the data to the view
        return view('admin/available-tests', $data);
    }
     public function addAvailabletest() {
        return view('admin/add_available_tests');
    }
    public function saveAvailabletest() {
        // Load the UserModel
        $availableTestModel = new AvailableTestModel(); 
        // Validate the form data
        $validationRules = ['test_name' => 'required', 'test_status' => 'required', 'test_tags' => 'required', 'test_image' => 'uploaded[test_image]|max_size[test_image,1024]|is_image[test_image]'];
        if (!$this->validate($validationRules)) {
            // Redirect back to the add user form with validation errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        // Get form data
        $availabletestData = ['test_name' => $this->request->getPost('test_name'), 'test_status' => $this->request->getPost('test_status'), 'test_tags' => $this->request->getPost('test_tags') ];
        // Handle image upload
        $image = $this->request->getFile('test_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_test', $newName);
            // Update the user data with the new image name
            $availabletestData['test_image'] = $newName;
        }
        // Save user data
        $availableTestModel->insert($availabletestData);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-tests'))->with('success', 'Test added successfully');
    }
    public function editAvailabletest($test_id) {
        // Load the UserModel
        $availabletestModel = new AvailableTestModel();
        // Fetch the user data based on the provided ID
        $data['available_test'] = $availabletestModel->find($test_id);
        // Pass the data to the view
        return view('admin/edit_available_tests', $data);
    }
    public function updateAvailabletest($test_id) {
        // Load the UserModel
        $availabletestModel = new AvailableTestModel();
        // Fetch the user data based on the provided ID
        $available_test = $availabletestModel->find($test_id);
        // Check if the user exists
        if (!$available_test) {
            // Handle the case where the user is not found
            echo 'Test not found';
            die();
        }
        
        // Validate the form data
        $validationRules = ['test_name' => 'required', 'test_status' => 'required', 'test_tags' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $availabletestData = ['test_name' => $this->request->getVar('test_name'),
                                'test_status' => $this->request->getVar('test_status'),
                                'test_tags' => $this->request->getVar('test_tags'),];
        // Handle image upload
        $image = $this->request->getFile('test_image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/available_test', $newName);
            // Delete the old image if it exists
            if ($available_test['test_image'] && file_exists(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image'])) {
                unlink(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image']);
            }
            // Update the user data with the new image name
            $availabletestData['test_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($availabletestModel->update($test_id, $availabletestData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/available-tests/edit/{$test_id}"))->with('success', 'Test updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/available-tests/edit/{$test_id}"))->with('errors', 'Test Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteAvailabletest($test_id) {
        // Load the UserModel
        $availabletestModel = new AvailableTestModel();
        // Fetch the user data based on the provided ID
        $available_test = $availabletestModel->find($test_id);
        // Check if the user exists
        if (!$available_test) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/available-test'))->with('error', 'Test not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($available_test['test_image'] && file_exists(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image'])) {
            unlink(ROOTPATH . 'public/uploads/available_test/' . $available_test['test_image']);
        }
        // Delete the user
        $availabletestModel->delete($test_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/available-tests'))->with('success', 'Test deleted successfully');
    }
    public function products() {
    
        $ProductModel = new ProductModel();
        // Fetch all users from the 'users' table
        $data['products'] = $ProductModel->findAll();
        // Pass the data to the view
        return view('admin/products', $data);
    }
    public function addProduct() {
        return view('admin/add_product');
    }
    public function saveProduct() {
    // Load the CategoryModel
    $ProductModel = new ProductModel();
    
    $validationRules = [
    'product_name' => 'required',
    'product_category_id' => 'required|numeric', // Add numeric validation
    'product_price' => 'required',
    'product_unit' => 'required|numeric',
    'product_description' => 'required',
    'product_unit_measure' => 'required|in_list[ML,KG]', // Validate against specific values
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $productData = [
        'product_name' => $this->request->getPost('product_name'),
        'product_category_id' => $this->request->getPost('product_category_id'),
        'description' => $this->request->getPost('description'),
        'product_price' => $this->request->getPost('product_price'),
        'product_unit' => $this->request->getPost('product_unit'),
        'product_unit_measure' => $this->request->getPost('product_unit_measure'),
    ];

    // Handle image upload
    $product_image = $this->request->getFile('product_image');
    if ($product_image->isValid() && !$product_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $product_image->getRandomName();
        // Move the uploaded image to the correct directory
        $product_image->move(ROOTPATH . 'public/uploads/products', $newName);
        // Update the category data with the new image name
        $productData['product_image'] = $newName;
    }

    // Save category data
    $ProductModel->insert($productData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/products'))->with('success', 'Product added successfully');
}
public function editProduct($product_id) {
        // Load the UserModel
        $ProductModel = new ProductModel();
        // Fetch the user data based on the provided ID
        $data['product'] = $ProductModel->find($product_id);
        // Pass the data to the view
        return view('admin/edit_product', $data);
    }
    public function updateProduct($product_id) {
        // Load the UserModel
        $ProductModel = new ProductModel();
        // Fetch the user data based on the provided ID
        $product = $ProductModel->find($product_id);
        // Check if the user exists
        if (!$product) {
            // Handle the case where the user is not found
            echo 'Product not found';
            die();
        }
        // Validate the form data
        $validationRules = ['product_name' => 'required', 'product_category_id' => 'required', 'product_description' => 'required', 'product_unit' => 'required', 'product_unit_measure' => 'required', 'product_price' => 'required',
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $productData = ['product_name' => $this->request->getVar('product_name'), 'product_category_id' => $this->request->getVar('product_category_id'), 'product_description' => $this->request->getVar('product_description'), 'product_unit' => $this->request->getVar('product_unit'), 'product_unit_measure' => $this->request->getVar('product_unit_measure'), 'product_price' => $this->request->getVar('product_price') ];
        // Handle image upload
        $product_image = $this->request->getFile('product_image');
        if ($product_image->isValid() && !$product_image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $product_image->getRandomName();
            // Move the uploaded image to the correct directory
            $product_image->move(ROOTPATH . 'public/uploads/products', $newName);
            // Delete the old image if it exists
            if ($product['product_image'] && file_exists(ROOTPATH . 'public/uploads/products/' . $product['product_image'])) {
                unlink(ROOTPATH . 'public/uploads/products/' . $product['product_image']);
            }
            // Update the user data with the new image name
            $productData['product_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($ProductModel->update($product_id, $productData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/products"))->with('success', 'Product updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/products/edit_product/{$product_id}"))->with('errors', 'Product Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteProduct($product_id) {
        // Load the UserModel
        $ProductModel = new ProductModel();
        // Fetch the user data based on the provided ID
        $product = $ProductModel->find($product_id);
        // Check if the user exists
        if (!$product) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/products'))->with('error', 'Product not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($product['product_image'] && file_exists(ROOTPATH . 'public/uploads/products/' . $product['product_image'])) {
            unlink(ROOTPATH . 'public/uploads/products/' . $product['product_image']);
        }
        // Delete the user
        $ProductModel->delete($product_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/products'))->with('success', 'Product deleted successfully');
    }
    public function guide() {
    
        $GuideModel = new GuideModel();
        // Fetch all users from the 'users' table
        $data['guide'] = $GuideModel->findAll();
        // Pass the data to the view
        return view('admin/guide', $data);
    }
    public function addGuide() {
        return view('admin/add-guide');
    }
    public function saveGuide() {
    // Load the CategoryModel
    $GuideModel = new GuideModel();
    
    $validationRules = [
    'guide_question' => 'required',
    'guide_sub_category_id' => 'required|numeric', // Add numeric validation
    'guide_answer' => 'required',
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $GuideData = [
        'guide_question' => $this->request->getPost('guide_question'),
        'guide_sub_category_id' => $this->request->getPost('guide_sub_category_id'),
        'guide_answer' => $this->request->getPost('guide_answer'),
    ];

    // Handle image upload
    $guide_image = $this->request->getFile('guide_image');
    if ($guide_image->isValid() && !$guide_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $guide_image->getRandomName();
        // Move the uploaded image to the correct directory
        $guide_image->move(ROOTPATH . 'public/uploads/guide', $newName);
        // Update the category data with the new image name
        $GuideData['guide_image'] = $newName;
    }

    // Save category data
    $GuideModel->insert($GuideData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/guide'))->with('success', 'Guide added successfully');
}
public function editGuide($guide_id) {
        // Load the UserModel
        $GuideModel = new GuideModel();
        // Fetch the user data based on the provided ID
        $data['guide'] = $GuideModel->find($guide_id);
        // Pass the data to the view
        return view('admin/edit-guide', $data);
    }
    public function updateGuide($guide_id) {
        // Load the UserModel
        $GuideModel = new GuideModel();
        // Fetch the user data based on the provided ID
        $guide = $GuideModel->find($guide_id);
        // Check if the user exists
        if (!$guide) {
            // Handle the case where the user is not found
            echo 'Guide not found';
            die();
        }
        // Validate the form data
        $validationRules = ['guide_question' => 'required', 'guide_answer' => 'required', 'guide_sub_category_id' => 'required'
        // 'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]|mime_in[image,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_dims[image,1024,768]',
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $GuideData = ['guide_question' => $this->request->getVar('guide_question'), 'guide_answer' => $this->request->getVar('guide_answer'), 'guide_sub_category_id' => $this->request->getVar('guide_sub_category_id') ];
        // Handle image upload
        $guide_image = $this->request->getFile('guide_image');
        if ($guide_image->isValid() && !$guide_image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $guide_image->getRandomName();
            // Move the uploaded image to the correct directory
            $guide_image->move(ROOTPATH . 'public/uploads/guide', $newName);
            // Delete the old image if it exists
            if ($guide['guide_image'] && file_exists(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image'])) {
                unlink(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image']);
            }
            // Update the user data with the new image name
            $GuideData['guide_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($GuideModel->update($guide_id, $GuideData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/guide/edit-guide/{$guide_id}"))->with('success', 'Guide updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/guide/edit-guide/{$guide_id}"))->with('errors', 'Guide Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    
public function deleteGuide($guide_id) {
        // Load the UserModel
        $GuideModel = new GuideModel();
        // Fetch the user data based on the provided ID
        $guide = $GuideModel->find($guide_id);
        // Check if the user exists
        if (!$guide) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/guide'))->with('error', 'Guide not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($guide['guide_image'] && file_exists(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image'])) {
            unlink(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image']);
        }
        // Delete the user
        $GuideModel->delete($guide_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/guide'))->with('success', 'Guide deleted successfully');
    }
    public function healthRecord() {
    
        $HealthRecordModel = new HealthRecordModel();
        // Fetch all users from the 'users' table
        $data['health_record'] = $HealthRecordModel->findAll();
        // Pass the data to the view
        return view('admin/health-record', $data);
    }
    public function addHealthRecord() {
        return view('admin/add-health-record');
    }
    public function saveHealthRecord() {
    // Load the CategoryModel
    $HealthRecordModel = new HealthRecordModel();
    
    $validationRules = [
    'blood_name' => 'required',
    'user_id' => 'required|numeric', // Add numeric validation
    'report_date' => 'required',
    'blood' => 'required',
    'date_time' => 'required',
    'type' => 'required|in_list[Blood,Document]', // Validate against specific values
    'document' => 'uploaded[document]|mime_in[document,image/jpg,image/jpeg,image/png,application/pdf,application/msword]|max_size[document,1024]',
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $HealthRecordData = [
        'blood_name' => $this->request->getPost('blood_name'),
        'user_id' => $this->request->getPost('user_id'),
        'report_date' => $this->request->getPost('report_date'),
        'blood' => $this->request->getPost('blood'),
        'date_time' => $this->request->getPost('date_time'),
        'type' => $this->request->getPost('type'),
    ];

    // Handle image upload
    $document = $this->request->getFile('document');
    if ($document->isValid() && !$document->hasMoved()) {
        // Generate a unique name for the image
        $newName = $document->getRandomName();
        // Move the uploaded image to the correct directory
        $document->move(ROOTPATH . 'public/uploads/health_report', $newName);
        // Update the category data with the new image name
        $HealthRecordData['document'] = $newName;
    }

    // Save category data
    $HealthRecordModel->insert($HealthRecordData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/health-record'))->with('success', 'Health Record added successfully');
}
public function deleteHealthRecord($id) {
        // Load the UserModel
        $HealthRecordModel = new HealthRecordModel();
        // Fetch the user data based on the provided ID
        $healthrecord = $HealthRecordModel->find($id);
        // Check if the user exists
        if (!$healthrecord) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/health-record'))->with('error', 'Health Record found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($healthrecord['document'] && file_exists(ROOTPATH . 'public/uploads/health_report/' . $healthrecord['document'])) {
            unlink(ROOTPATH . 'public/uploads/health_report/' . $healthrecord['document']);
        }
        // Delete the user
        $HealthRecordModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/health-record'))->with('success', 'Health Record deleted successfully');
    }
    public function editHealthRecord($id) {
        // Load the UserModel
        $HealthRecordModel = new HealthRecordModel();
        // Fetch the user data based on the provided ID
        $data['health_record'] = $HealthRecordModel->find($id);
        // Pass the data to the view
        return view('admin/health-record', $data);
    }
    public function SleepManagementCategory() {
    
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch all users from the 'users' table
        $data['sleep_management_categories'] = $SleepManagementCategoryModel->findAll();
        // Pass the data to the view
        return view('admin/sleep-management-category', $data);
    }
    public function addSleepManagementCategory() {
        return view('admin/add-sleep-management-category');
    }    
    public function saveSleepManagementCategory() {
    // Load the CategoryModel
    $SleepManagementCategoryModel = new SleepManagementCategoryModel();
    
    $validationRules = [
    'smc_name' => 'required',
    'smc_status' => 'required|in_list[ACTIVE,DEACTIVE]', // Validate against specific values
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $SleepManagementCategoryData = [
        'smc_name' => $this->request->getPost('smc_name'),
        'smc_status' => $this->request->getPost('smc_status'),
    ];

  
    // Save category data
    $SleepManagementCategoryModel->insert($SleepManagementCategoryData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/sleep-management-category/add-sleep-management-category'))->with('success', 'Sleep Management Category added successfully');
}
public function editSleepManagementCategory($smc_id) {
        // Load the UserModel
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $data['sleep_management_categories'] = $SleepManagementCategoryModel->find($smc_id);
        // Pass the data to the view
        return view('admin/edit-sleep-management-category', $data);
    }
public function updateSleepManagementCategory($smc_id) {
        // Load the UserModel
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $SleepManagementCategory = $SleepManagementCategoryModel->find($smc_id);
        // Check if the user exists
        if (!$SleepManagementCategoryModel) {
            // Handle the case where the user is not found
            echo 'Sleep Management Category not found';
            die();
        }
        // Validate the form data
        $validationRules = ['smc_name' => 'required', 'smc_status' => 'required'
        ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SleepManagementCategoryData = ['smc_name' => $this->request->getVar('smc_name'), 'smc_status' => $this->request->getVar('smc_status')];
        
        // Update user data only if the image upload is successful
        if ($SleepManagementCategoryModel->update($smc_id, $SleepManagementCategoryData)) {
            // Redirect to the user list page with a success message
            
            return redirect()->to(base_url("admin/sleep-management-category/edit/{$smc_id}"))->with('success', 'Sleep Management Category updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/sleep-management-category/edit/{$smc_id}"))->with('errors', 'Sleep Management Category Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
public function deleteSleepManagementCategory($smc_id) {
        // Load the UserModel
        $SleepManagementCategoryModel = new SleepManagementCategoryModel();
        // Fetch the user data based on the provided ID
        $SleepManagementCategory = $SleepManagementCategoryModel->find($smc_id);
        // Check if the user exists
        if (!$SleepManagementCategory) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sleep-management-category'))->with('error', 'Sleep Management Category Not found');
        }
        
        // Delete the user
        $SleepManagementCategoryModel->delete($smc_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sleep-management-category'))->with('success', 'Sleep Management Category deleted successfully');
    }
public function SonographyUltrasound() {
    
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch all users from the 'users' table
        $data['sonography_ultrasounds'] = $SonographyUltrasoundsModel->findAll();
        // Pass the data to the view
        return view('admin/sonography-ultrasound', $data);
    }
public function addSonographyUltrasound() {
        return view('admin/add-sonography-ultrasound');
    }     
public function saveSonographyUltrasound() {
    // Load the CategoryModel
    $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
    
    $validationRules = [
    'su_user_id' => 'required|numeric',
    'su_title' => 'required', 
    'su_description' => 'required', 
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $SonographyUltrasoundsData = [
        'su_user_id' => $this->request->getPost('su_user_id'),
        'su_title' => $this->request->getPost('su_title'),
        'su_description' => $this->request->getPost('su_description'),
    ];
    
     // Handle image upload
    $su_image = $this->request->getFile('su_image');
    if ($su_image->isValid() && !$su_image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $su_image->getRandomName();
        // Move the uploaded image to the correct directory
        $su_image->move(ROOTPATH . 'public/uploads/sonography_ultrasounds', $newName);
        // Update the category data with the new image name
        $SonographyUltrasoundsData['su_image'] = $newName;
    }
  
    // Save category data
    $SonographyUltrasoundsModel->insert($SonographyUltrasoundsData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/sonography-ultrasound/add-sonography-ultrasound'))->with('success', 'Sonography Ultrasounds added successfully');
}
public function editSonographyUltrasound($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch the user data based on the provided ID
        $data['sonography_ultrasounds'] = $SonographyUltrasoundsModel->find($su_id);
        // Pass the data to the view
        return view('admin/edit-sonography-ultrasound', $data);
    }
public function updateSonographyUltrasound($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch the user data based on the provided ID
        $SonographyUltrasounds = $SonographyUltrasoundsModel->find($su_id);
        // Check if the user exists
        if (!$SonographyUltrasounds) {
            // Handle the case where the user is not found
            echo 'Sonography Ultrasounds not found';
            die();
        }
        // Validate the form data
        $validationRules = ['su_user_id' => 'required|numeric',
                            'su_title' => 'required',
                            'su_description' => 'required'    
                            ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SonographyUltrasoundsData = ['su_user_id' => $this->request->getVar('su_user_id'),
                                      'su_title' => $this->request->getVar('su_title'),
                                      'su_description' => $this->request->getVar('su_description')
                                      ];
        // Handle image upload
        $su_image = $this->request->getFile('su_image');
        if ($su_image->isValid() && !$su_image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $su_image->getRandomName();
            // Move the uploaded image to the correct directory
            $su_image->move(ROOTPATH . 'public/uploads/sonography_ultrasounds', $newName);
            // Delete the old image if it exists
            if ($SonographyUltrasounds['su_image'] && file_exists(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image'])) {
                unlink(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image']);
            }
            // Update the user data with the new image name
            $SonographyUltrasoundsData['su_image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($SonographyUltrasoundsModel->update($su_id, $SonographyUltrasoundsData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/sonography-ultrasound/edit/{$su_id}"))->with('success', 'Sonography Ultrasounds updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/sonography-ultrasound/edit/{$su_id}"))->with('errors', 'Sonography Ultrasounds Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteSonographyUltrasound($su_id) {
        // Load the UserModel
        $SonographyUltrasoundsModel = new SonographyUltrasoundsModel();
        // Fetch the user data based on the provided ID
        $SonographyUltrasounds = $SonographyUltrasoundsModel->find($su_id);
        // Check if the user exists
        if (!$SonographyUltrasounds) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sonography-ultrasound'))->with('error', 'Sonography Ultrasound not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($SonographyUltrasounds['su_image'] && file_exists(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image'])) {
            unlink(ROOTPATH . 'public/uploads/sonography_ultrasounds/' . $SonographyUltrasounds['su_image']);
        }
        // Delete the user
        $SonographyUltrasoundsModel->delete($su_id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/sonography-ultrasound'))->with('success', 'Sonography Ultrasound deleted successfully');
    }
    public function SupplimentPlan() {
    
        $SupplimentModel = new SupplimentModel();
        // Fetch all users from the 'users' table
        $data['suppliment_plan'] = $SupplimentModel->findAll();
        // Pass the data to the view
        return view('admin/suppliment-plan', $data);
    }
public function addSupplimentPlan() {
        return view('admin/add-suppliment-plan');
    }
public function saveSupplimentPlan() {
    // Load the CategoryModel
    $SupplimentModel = new SupplimentModel();
    
    $validationRules = [
    'sub_category_id' => 'required|numeric',
    'name' => 'required', 
    'amount' => 'required',
    'title' => 'required',
    'sub_title' => 'required',
];

    if (!$this->validate($validationRules)) {
        // Redirect back to the add category form with validation errors
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Get form data
    $SupplimentPlanData = [
        'sub_category_id' => $this->request->getPost('sub_category_id'),
        'name' => $this->request->getPost('name'),
        'amount' => $this->request->getPost('amount'),
        'title' => $this->request->getPost('title'),
        'sub_title' => $this->request->getPost('sub_title'),
    ];
    
     // Handle image upload
    $image = $this->request->getFile('image');
    if ($image->isValid() && !$image->hasMoved()) {
        // Generate a unique name for the image
        $newName = $image->getRandomName();
        // Move the uploaded image to the correct directory
        $image->move(ROOTPATH . 'public/uploads/suppliment', $newName);
        // Update the category data with the new image name
        $SupplimentPlanData['image'] = $newName;
    }
  
    // Save category data
    $SupplimentModel->insert($SupplimentPlanData);

    // Redirect to the category list page with a success message
    return redirect()->to(base_url('admin/suppliment-plan'))->with('success', 'Suppliment Plan added successfully');
}
public function editSupplimentPlan($id) {
        // Load the UserModel
        $SupplimentModel = new SupplimentModel();
        // Fetch the user data based on the provided ID
        $data['suppliment_plan'] = $SupplimentModel->find($id);
        // Pass the data to the view
        return view('admin/edit-suppliment-plan', $data);
    }
    
public function updateSupplimentPlan($id) {
        // Load the UserModel
        $SupplimentModel = new SupplimentModel();
        // Fetch the user data based on the provided ID
        $Suppliment = $SupplimentModel->find($id);
        // Check if the user exists
        if (!$Suppliment) {
            // Handle the case where the user is not found
            echo 'Suppliment Plan not found';
            die();
        }
        // Validate the form data
        $validationRules = ['sub_category_id' => 'required|numeric',
                            'name' => 'required',
                            'amount' => 'required',
                            'title' => 'required',
                            'sub_title' => 'required'
                            ];
        if (!$this->validate($validationRules)) {
            // Display validation errors for debugging
            echo '<pre>';
            print_r($this->validator->getErrors());
            echo '</pre>';
            die();
        }
        // Get form data using getVar
        $SupplimentData = ['sub_category_id' => $this->request->getVar('sub_category_id'),
                                      'name' => $this->request->getVar('name'),
                                      'amount' => $this->request->getVar('amount'),
                                      'title' => $this->request->getVar('title'),
                                      'sub_title' => $this->request->getVar('sub_title')
                                      ];
        // Handle image upload
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a unique name for the image
            $newName = $image->getRandomName();
            // Move the uploaded image to the correct directory
            $image->move(ROOTPATH . 'public/uploads/suppliment', $newName);
            // Delete the old image if it exists
            if ($Suppliment['image'] && file_exists(ROOTPATH . 'public/uploads/suppliment/' . $Suppliment['image'])) {
                unlink(ROOTPATH . 'public/uploads/suppliment/' . $Suppliment['image']);
            }
            // Update the user data with the new image name
            $SupplimentData['image'] = $newName;
        }
        // Update user data only if the image upload is successful
        if ($SupplimentModel->update($id, $SupplimentData)) {
            // Redirect to the user list page with a success message
            return redirect()->to(base_url("admin/suppliment-plan"))->with('success', 'Suppliment Plan updated successfully');
            // echo 'User updated successfully';
            // die();
            
        } else {
            // Handle the case where the update operation fails
            return redirect()->to(base_url("admin/suppliment-plan/edit/{$id}"))->with('errors', 'Suppliment Plan Not Updated');
            // echo 'Failed to update user';
            // die();
            
        }
    }
    public function deleteSupplimentPlan($id) {
        // Load the UserModel
        $SupplimentModel = new SupplimentModel();
        // Fetch the user data based on the provided ID
        $Suppliment = $SupplimentModel->find($id);
        // Check if the user exists
        if (!$Suppliment) {
            // Handle the case where the user is not found
            return redirect()->to(base_url('admin/sonography-ultrasound'))->with('error', 'Suppliment Plan not found');
        }
        // Optionally, you can also delete the user's image file here if applicable
        if ($Suppliment['image'] && file_exists(ROOTPATH . 'public/uploads/suppliment/' . $Suppliment['image'])) {
            unlink(ROOTPATH . 'public/uploads/suppliment/' . $Suppliment['image']);
        }
        // Delete the user
        $SupplimentModel->delete($id);
        // Redirect to the user list page with a success message
        return redirect()->to(base_url('admin/suppliment-plan'))->with('success', 'Suppliment Plan deleted successfully');
    }
}
