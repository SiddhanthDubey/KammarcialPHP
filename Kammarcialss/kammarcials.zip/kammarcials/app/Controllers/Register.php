<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use CodeIgniter\API\ResponseTrait;
use App\Models\UserModel;
use App\Models\LabModel;
use App\Models\DoctorModel;
use App\Models\PersonalTrainerModel;

use \Firebase\JWT\JWT;


class Register extends BaseController {
    use ResponseTrait;
    
    
    
    public function index() {
        $type = $this->request->getVar('type');
        
        
    if ($type == "trainer") {
    $model = new PersonalTrainerModel();
    $countryCode = $this->request->getVar('country_code');
    $mobile = $this->request->getVar('mobile');
    
    // Check if the combination of mobile and country code exists in the database
    $user = $model->where(['mobile' => $mobile, 'country_code' => $countryCode])->first();

    if ($user) {
        $result['message'] = 'Mobile No with country code exists';
        $result['status'] = '0';
        return $this->respond($result);
    }

    // Define validation rules
    $rules = [
        'user_name' => 'required',
        'email' => 'required',
       // 'mobile' => 'required|min_length[6]|max_length[12]|is_unique[users.mobile]',
        'password' => 'required|min_length[6]',
       // 'confirm_password' => ['label' => 'confirm password', 'rules' => 'matches[password]'],
    ];

    if ($this->validate($rules)) {
        // Continue with the rest of your registration logic
        $data = [
            'email' => $this->request->getVar('email'),
            'user_name' => $this->request->getVar('user_name'),
            // 'company_name' => $this->request->getVar('company_name'),
            'mobile' => $this->request->getVar('mobile'),
            'country_code' => $this->request->getVar('country_code'),
            'gender' => $this->request->getVar('gender'),
            'dob' => $this->request->getVar('dob'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
        ];

      $insert= $model->save($data);
         if ($insert) {
                    $idd = $model->insertID();
                    // echo $idd;
                    $userDataq = $model->find($idd);
                } 
    
    $response = [
            'message' => 'Registered Successful',
         //   'token' => $token,
            'token' => '',
            'user_data' => $userDataq,
            'status' => '1',
            'user_type' => $type
        ];

        return $this->respond($response, 200);
        

        return $this->respond(['message' => 'Registered Successfully', 'status' => '1'], 200);
    } else {
      $errors = array_values($this->validator->getErrors());
                $result['message'] = $errors[0];
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
        
    }
}

 if ($type == "lab11") {
            $model = new LabModel();
            $countryCode = $this->request->getVar('country_code');
            $mobile = $this->request->getVar('mobile');
            // Check if the combination of mobile and country code exists in the database
            $user = $model->where(['mobile' => $mobile, 'country_code' => $countryCode])->first();
            if ($user) {
                $result['message'] = 'Mobile No with country code exists';
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
            // Define validation rules
            $this->request->getVar('user_name');
            $rules = ['user_name' => 'required|min_length[4]|max_length[255]|is_unique[lab.user_name]', 'email' => 'required|min_length[4]|max_length[255]|valid_email|is_unique[lab.email]', 'mobile' => 'required|min_length[6]|max_length[12]|is_unique[lab.mobile]', 'password' => 'required|min_length[6]|max_length[255]', 'confirm_password' => ['label' => 'confirm password', 'rules' => 'matches[password]'], ];
            if ($this->validate($rules)) {
                // Continue with the rest of your registration logic
                $data = [
                'email' => $this->request->getVar('email'),
                'user_name' => $this->request->getVar('user_name'), 
                'company_name' => $this->request->getVar('company_name'),
                'mobile' => $this->request->getVar('mobile'), 
                'country_code' => $this->request->getVar('country_code'),
                'gender' => $this->request->getVar('gender'),
                'dob' => $this->request->getVar('dob'), 
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT), ];
              $insert =  $model->save($data);
                
                 if ($insert) {
                    $idd = $model->insertID();
                    // echo $idd;
                    $userDataq = $model->find($idd);
                } 
                
                $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);


                  $email =  $userDataq['email'];
                  

        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            
        ];

        $token = JWT::encode($payload, $key, 'HS256');


        $response = [
            'message' => 'Registered Successful',
         //   'token' => $token,
            'token' => '',
            'user_data' => $userDataq,
            'status' => '1',
            'user_type' => $type
        ];

        return $this->respond($response, 200); die;
        

                // return $this->respond(['message' => 'Registered Successfully','user_data' => $userDataq, 'status' => '1'], 200);
            } else {
                $errors = array_values($this->validator->getErrors());
                $result['message'] = $errors[0];
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
        }
        
        if ($type == "lab") {
            $model = new LabModel();
            $countryCode = $this->request->getVar('country_code');
            $mobile = $this->request->getVar('mobile');
            // Check if the combination of mobile and country code exists in the database
            $user = $model->where(['mobile' => $mobile, 'country_code' => $countryCode])->first();
            if ($user) {
                $result['message'] = 'Mobile No with country code exists';
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
            // Define validation rules
            $this->request->getVar('user_name');
            $rules = ['user_name' => 'required|min_length[4]|max_length[255]|is_unique[lab.user_name]', 'email' => 'required|min_length[4]|max_length[255]|valid_email|is_unique[lab.email]', 'mobile' => 'required|min_length[6]|max_length[12]|is_unique[lab.mobile]', 'password' => 'required|min_length[6]|max_length[255]', 'confirm_password' => ['label' => 'confirm password', 'rules' => 'matches[password]'], ];
            if ($this->validate($rules)) {
                // Continue with the rest of your registration logic
                $data = ['email' => $this->request->getVar('email'), 
                'user_name' => $this->request->getVar('user_name'),
                'company_name' => $this->request->getVar('company_name'), 
                'mobile' => $this->request->getVar('mobile'), 
                'country_code' => $this->request->getVar('country_code'), 
                'gender' => $this->request->getVar('gender'), 
                'dob' => $this->request->getVar('dob'), 
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT), ];
              $insert=  $model->save($data);
                
                 if ($insert) {
                    $idd = $model->insertID();
                    // echo $idd;
                    $userDataq = $model->find($idd);
                } 
                
                $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);


                  $email =  $userDataq['email'];
                  

        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            
        ];

        $token = JWT::encode($payload, $key, 'HS256');


        $response = [
            'message' => 'Registered Successful',
         //   'token' => $token,
            'token' => '',
            'user_data' => $userDataq,
            'status' => '1',
            'user_type' => $type
        ];

        return $this->respond($response, 200);
        

                // return $this->respond(['message' => 'Registered Successfully','user_data' => $userDataq, 'status' => '1'], 200);
            } else {
                $errors = array_values($this->validator->getErrors());
                $result['message'] = $errors[0];
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
        }
        
        if ($type == "doctor") {
            $model = new DoctorModel();
            $countryCode = $this->request->getVar('country_code');
            $mobile = $this->request->getVar('mobile');
            // Check if the combination of mobile and country code exists in the database
            $user = $model->where(['mobile' => $mobile, 'country_code' => $countryCode])->first();
            if ($user) {
                $result['message'] = 'Mobile No with country code exists';
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
            // Define validation rules
            $this->request->getVar('user_name');
            $rules = ['user_name' => 'required|min_length[4]|max_length[255]|is_unique[doctors.user_name]', 'email' => 'required|min_length[4]|max_length[255]|valid_email|is_unique[doctors.email]', 'mobile' => 'required|min_length[6]|max_length[12]|is_unique[doctors.mobile]', 'password' => 'required|min_length[6]|max_length[255]', 'confirm_password' => ['label' => 'confirm password', 'rules' => 'matches[password]'], ];
            if ($this->validate($rules)) {
                // Continue with the rest of your registration logic
                $data = ['email' => $this->request->getVar('email'), 
                'user_name' => $this->request->getVar('user_name'), 
                'company_name' => $this->request->getVar('company_name'), 
                'mobile' => $this->request->getVar('mobile'), 
                'country_code' => $this->request->getVar('country_code'), 
                'gender' => $this->request->getVar('gender'), 
                'dob' => $this->request->getVar('dob'),
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT), ];
              $insert=  $model->save($data);
                
                 if ($insert) {
                    $idd = $model->insertID();
                    // echo $idd;
                    $userDataq = $model->find($idd);
                } 
                
                $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);


                  $email =  $userDataq['email'];
                  

        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            
        ];

        $token = JWT::encode($payload, $key, 'HS256');


        $response = [
            'message' => 'Registered Successful',
         //   'token' => $token,
            'token' => '',
            'user_data' => $userDataq,
            'status' => '1',
            'user_type' => $type
        ];

        return $this->respond($response, 200);
        

                // return $this->respond(['message' => 'Registered Successfully','user_data' => $userDataq, 'status' => '1'], 200);
            } else {
                $errors = array_values($this->validator->getErrors());
                $result['message'] = $errors[0];
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
        }
        
        if ($type == "user") {
            $model = new UserModel();
            $countryCode = $this->request->getVar('country_code');
            $mobile = $this->request->getVar('mobile');
            // Check if the combination of mobile and country code exists in the database
            $user = $model->where(['mobile' => $mobile, 'country_code' => $countryCode])->first();
            if ($user) {
                $result['message'] = 'Mobile No with country code exists';
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
            // Define validation rules
            $rules = ['user_name' => 'required|min_length[4]|max_length[255]|is_unique[users.user_name]', 'email' => 'required|min_length[4]|max_length[255]|valid_email|is_unique[users.email]', 'mobile' => 'required|min_length[6]|max_length[12]|is_unique[users.mobile]', 'password' => 'required|min_length[6]|max_length[255]', 'confirm_password' => ['label' => 'confirm password', 'rules' => 'matches[password]'], ];
            if ($this->validate($rules)) {
                // Continue with the rest of your registration logic
                $data = [
                'email' => $this->request->getVar('email'), 
                'user_name' => $this->request->getVar('user_name'),
                // 'company_name' => $this->request->getVar('company_name'), 
                'mobile' => $this->request->getVar('mobile'),
                'country_code' => $this->request->getVar('country_code'),
                'gender' => $this->request->getVar('gender'),
                'dob' => $this->request->getVar('dob'), 
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT), ];
              //  $model->save($data);
                 $insert=  $model->save($data);
                 
                 if ($insert) {
                    $idd = $model->insertID();
                    // echo $idd;
                    $userDataq = $model->find($idd);
                } 
                 
              $key = getenv('JWT_SECRET');
        $iat = time(); // current timestamp value
        $exp = strtotime('+1 year', $iat);


                  $email =  $userDataq['email'];
                  

        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            
        ];

        $token = JWT::encode($payload, $key, 'HS256');


        $response = [
            'message' => 'Registered Successful',
            'token' => $token,
            'user_data' => $userDataq,
            'status' => '1',
            'user_type' => $type
        ];

        return $this->respond($response, 200);
            } else {
                $errors = array_values($this->validator->getErrors());
                $result['message'] = $errors[0];
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
        }
        
    }
     
    
     public function register() {
       
         $model = new UserModel();
         
         
       //  $otp = rand(1000, 9999);
        
         $otp = 'xxxx';
            
            $email = $this->request->getVar('email');
            $password = $this->request->getVar('password');
            $user_name = $this->request->getVar('user_name');
            
            
            $user = $model->where('email', $email)->where('account_status', 'verify')->first();
          
              $rules = [ 'email' => 'required' ];
            
                if ($this->validate($rules)) {
                    
                    
                     if ($user) {
                $result['message'] = 'Email Already exists';
                $result['status'] = false;
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
            
              $checkuser = $model->where('email', $email)->where('account_status', 'unverify')->first();
          
                if ($checkuser)
                {
                    $response = [
                'message' => 'Registered Successful',
               // 'token' => $token,
                'user_data' => $checkuser,
                'status' => true,
               // 'user_type' => 'User'
              ];
    
            return $this->respond($response, 200);
                    die;
              
                }
            
            
            
                $data = [ 
                    'user_name' => $user_name,
                    'email' => $email,
                    'password' => password_hash($password, PASSWORD_DEFAULT),
                    'type' => 'User',
                
                'otp' =>$otp  ];
            
                 $insert=  $model->save($data);
                 
                 if ($insert) {
                    $idd = $model->insertID();
                    // echo $idd;
                    $userDataq = $model->find($idd);
                } 
                 
               $key = getenv('JWT_SECRET');
                $iat = time(); // current timestamp value
                $exp = strtotime('+1 year', $iat);


                 // $email =  $userDataq['email'];
                  

        $payload = [
            'iss' => 'Issuer of the JWT',
            'aud' => 'Audience that the JWT',
            'sub' => 'Subject of the JWT',
            'iat' => $iat, // Time the JWT issued at
            'exp' => $exp, // Expiration time of token
            'email' => $email,
            
        ];

        $token = JWT::encode($payload, $key, 'HS256');


        $response = [
            'message' => 'Registered Successful',
           // 'token' => $token,
            'user_data' => $userDataq,
            'status' => true,
            'user_type' => 'Provider'
        ];

        return $this->respond($response, 200);
           
        
                    
                    
                }
                else
                {
                
                $errors = array_values($this->validator->getErrors());
                                $result['message'] = $errors[0];
                                $result['status'] = false;
                                $json = $result;
                                header('Content-type: application/json');
                                echo json_encode($json);
                                die;
                
                }

          
           
        
    }
    
    
    
    public function send_Email_Otp() {
       
          $model = new UserModel();
         
         // $otp = rand(1000, 9999);
        
          $otp = '9999';
            
            $email = $this->request->getVar('email');
            
            $gotopin = $model->where('email', $email)->where('account_status', 'verify')->first();
            
                if ($gotopin) {
            
             $model->where('email', $email)->set('otp', $otp)->update();        
                    
                $result['user_id'] = $gotopin['id']; 
                $result['message'] = 'Thank you sent otp';
                $result['status'] = true;
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
            else
            {
                $result['message'] = 'Email ID Not Valid';
                $result['status'] = false;
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
           
              
        
    }
    
    public function forgot_password() {
       
         $model = new UserModel();
         
          $otp = rand(1000, 9999);
        
         // $otp = '9999';
            
            $countryCode = $this->request->getVar('country_code');
            $mobile = $this->request->getVar('mobile');
            
            $gotopi = $model->where('mobile', $mobile)->where('country_code', $countryCode)->where('type', 'User')->where('account_status', 'unverify')->first();
            
                if ($gotopi) {
                $result['message'] = 'Your Account is Not Verify Please verify your Mobile Number';
                $result['status'] = '0';
                $json = $result;
                header('Content-type: application/json');
                echo json_encode($json);
                die;
            }
            
             $user = $model->where('id', $id)->where('country_code', $countryCode)->where('type', 'User')->where('account_status', 'verify')->first();
            
           
            
            if ($checkuser) {
                $response = [
            'message' => 'Registered Successful',
           // 'token' => $token,
            'user_data' => $checkuser,
            'status' => '1',
            'user_type' => 'User'
        ];

        return $this->respond($response, 200);
                die;
            }
            
          
         
                // Continue with the rest of your registration logic
                $data = [
               
                'mobile' => $mobile,
                //'email' => $this->request->getVar('mobile'),
                'country_code' =>$countryCode,
                'otp' =>$otp 
                ];
            
          
        
    }
    
}
