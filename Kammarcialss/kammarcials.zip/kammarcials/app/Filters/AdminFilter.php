<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AdminFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
{
    $session = \Config\Services::session();

    // Check if the user is logged in
    if (!$session->get('user.logged_in')) {
        // User is not logged in, redirect to login page
        return redirect()->to(base_url('admin/login'));
    }

    // User is logged in, allow the request to proceed
    return $request;
}
    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Any logic you want to perform after the response is sent
        return $response;
    }
}
