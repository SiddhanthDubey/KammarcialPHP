<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class SubcriptionModel extends Model
{
    protected $table = 'subcription'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = [ 'amount', 'day','status','date_time'];
    
}