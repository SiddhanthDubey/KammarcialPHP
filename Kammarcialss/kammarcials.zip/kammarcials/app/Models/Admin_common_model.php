<?php namespace App\Models;


use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;
class Admin_common_model  extends Model {
  protected $db;
   public function __construct(ConnectionInterface &$db)
    {
        $this->db =& $db;
    }
  // function for all record start
  public function fetch_record($tbname)
  {
    $builder = $this->db->table($table);
         $data = $builder->get()->getResultArray();
      if ($data) {
        return $data;
      }else{
        return FALSE;
      }
  }
  // function for all record end

  // function for single record start
  public function fetch_recordbyid($tbname,$data)
  {
    $builder = $this->db->table($table);
            $builder->where($where);
         $data = $builder->get()->getResultArray();

      if($data){
        return $data;
      }else{
        return FALSE;
      }
  }
  // function for single record end

  // function for insert record start
  public function insert_data($table,$data)
  {
    $db = db_connect('default'); 
  $builder = $db->table($table);
    $builder->insert($data);
    return $db->insertID();
  }
  // function for insert record end

  // function for single record start
  

  public function get_all($table) {
         $builder = $this->db->table($table);
         $data = $builder->get()->getResultArray();
      if ($data) {
        return $data;
      }else{
        return FALSE;
      }
   }
  
  public function get_where($table,$where){
          $builder = $this->db->table($table);
            $builder->where($where);
         $data = $builder->get()->getResultArray();

      if($data){
        return $data;
      }else{
        return FALSE;
      }
}
  
  
    public function update_data($table,$data,$where) {
           $query =  $this->db
                        ->table($table)
                        ->where($where)
                        ->set($data)
                        ->update();
        if ($query)
      {
        return TRUE;
      }
        else
      {
        return FALSE;
      }
     
  }
  
  public function delete_data($table,$where) {
    $query = $this->db
                        ->table($table)
                        ->where($where)
                        ->delete();
    if ($query)
      {
        return TRUE;
      }
        else
      {
        return FALSE;
      }
  }
  
  
  

    function distance($lat1, $lng1, $lat2, $lng2, $miles = false)
          {
        $pi80 = M_PI / 180;
        $lat1*= $pi80;
        $lng1*= $pi80;
        $lat2*= $pi80;
        $lng2*= $pi80;
        $r = 6372.797; // mean radius of Earth in km
        $dlat = $lat2 - $lat1;
        $dlng = $lng2 - $lng1;
        $a = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlng / 2) * sin($dlng / 2);
        $c = 2 * atan2(sqrt($a) , sqrt(1 - $a));
        $km = $r * $c;
        return ($miles ? ($km * 0.621371192) : $km);
          }


           

public function humanTiming($time)
    {
      $time = time() - $time; // to get the time since that moment
      $time = ($time < 1) ? 1 : $time;
      $tokens = array(
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute',
        1 => 'second'
      );
      foreach($tokens as $unit => $text)
      {
        if ($time < $unit) continue;
        $numberOfUnits = floor($time / $unit);
        return $numberOfUnits . ' ' . $text . (($numberOfUnits > 1) ? 's' : '');
      }
    }


      function ios_user_notification($site_url,$message, $ios_id,$sender_id)
      {

        /*************** notification ****************/
                          
                          $message['alert'] = $message['key'];
                          $message['content-available'] = 1;
                          $message['badge'] = 1;
                          $message['sender_id'] = $sender_id;
                          $message['sound'] = 'default';
                          $message['ios_id'] = $ios_id;
                          $message['pem_file_name'] = 'CertificatesUser.pem';
                          
                          $fields_string = (http_build_query($message));
                          
                          $url = $site_url.'ios_apk_noti.php';
                                                  
                          $fields_string = urldecode($fields_string);

                          $ch = curl_init();

                          curl_setopt($ch,CURLOPT_URL, $url);
                          curl_setopt($ch,CURLOPT_POST, count($message));
                          curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

                          $exc = curl_exec($ch);
                        //   echo $ch;
                          curl_close($ch); 

      }

              function ios_driver_notification($site_url,$message, $ios_id,$sender_id)
      {
                     
          
                          $message['alert'] = $message['key'];
                          $message['content-available'] = 1;
                          $message['badge'] = 1;
                          $message['sender_id'] = $sender_id;
                          $message['sound'] = 'default';
                          $message['ios_id'] = $ios_id;
                          $message['pem_file_name'] = 'CertificatesProvider.pem';
                        
                          $fields_string = (http_build_query($message));
                          
                          $url = $site_url.'ios_apk_noti.php';
                                               
                          $fields_string = urldecode($fields_string);
    
                          $ch = curl_init();

             curl_setopt($ch,CURLOPT_URL, $url);
                         curl_setopt($ch,CURLOPT_POST, count($message));
                        curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

                          $exc = curl_exec($ch);
         
                          curl_close($ch);                          


      }


}  