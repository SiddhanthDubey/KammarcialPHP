<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class AboutPrivacyModel extends Model
{
    protected $table = 'about_us_privacy_policy'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['description', 'name'];
    
}

