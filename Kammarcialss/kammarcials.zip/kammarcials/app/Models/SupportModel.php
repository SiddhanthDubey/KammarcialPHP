<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class SupportModel extends Model
{
    protected $table = 'support'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id','message'];
    
}

