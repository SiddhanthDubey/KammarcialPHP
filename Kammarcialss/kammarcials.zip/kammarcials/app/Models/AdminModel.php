<?php
  
namespace App\Models;
  
use CodeIgniter\Model;
  
class AdminModel extends Model
{
    protected $DBGroup              = 'default';
    protected $table                = 'admins';
    protected $primaryKey           = 'admin_id';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDeletes       = false;
    protected $protectFields        = true;
    protected $allowedFields        = ['admin_email', 'admin_password', 'admin_created_at', 'admin_updated_at'];
  
    // Dates
    protected $useTimestamps        = true;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'admin_created_at';
    protected $updatedField         = 'admin_updated_at';
    protected $deletedField         = 'admin_deleted_at';
  
    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;
  
    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
}