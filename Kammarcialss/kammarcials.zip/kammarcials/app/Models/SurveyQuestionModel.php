<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class SurveyQuestionModel extends Model
{
    protected $table = 'survey_question'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['survey_id','question','answer','option1','option2','option3','option4','rewardPoint','user_id'];
    
}

