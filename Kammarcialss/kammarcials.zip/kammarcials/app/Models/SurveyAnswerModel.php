<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class SurveyAnswerModel extends Model
{
    protected $table = 'survey_answer'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['survey_ques_id','survey_id','answer','user_id'];
    
}

