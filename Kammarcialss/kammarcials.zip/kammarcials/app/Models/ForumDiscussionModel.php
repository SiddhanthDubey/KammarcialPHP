<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class ForumDiscussionModel extends Model
{
    protected $table = 'forum_discussion'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = [ 'topic_id','user_id','title','description','status' , 'date_time'];
    
    
}