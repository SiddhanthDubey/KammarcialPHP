<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class ServicesModel extends Model
{
    protected $table = 'services'; // sleep_video_list_discover folder
    protected $primaryKey = 'ser_id';
    protected $allowedFields = [ 'service_name', 'ser_image'];
    
}