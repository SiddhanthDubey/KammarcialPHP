<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class UserAttendenceHourModel extends Model
{
    protected $table = 'user_attendence_time';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'type', 'check_type' , 'attendence_id', 'time' , 'end_time' ,'date' ];
}
