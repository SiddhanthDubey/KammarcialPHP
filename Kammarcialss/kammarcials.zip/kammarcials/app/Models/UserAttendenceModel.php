<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class UserAttendenceModel extends Model
{
    protected $table = 'user_attendence';
    protected $primaryKey = 'u_id';
    protected $allowedFields = ['user_id', 'type', 'check_out_time' ,'tea_break_in_time','tea_break_out_time','lunch_in_time','lunch_out_time', 'type_status' , 'description', 'check_in_time', 'user_date_time', 'lat', 'lon' ];
}
