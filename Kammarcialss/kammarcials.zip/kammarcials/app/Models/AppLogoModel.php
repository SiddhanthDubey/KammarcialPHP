<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class AppLogoModel extends Model
{
    protected $table = 'app_logo'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['image', 'title','status'];
    
}

