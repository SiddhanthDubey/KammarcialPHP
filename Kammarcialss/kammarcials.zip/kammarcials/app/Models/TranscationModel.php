<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class TranscationModel extends Model
{
    protected $table = 'transcation'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id','type','amount','status','wallet_balance'];
    
}

