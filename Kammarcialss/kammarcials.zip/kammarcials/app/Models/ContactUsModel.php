<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class ContactUsModel extends Model
{
    protected $table = 'contact_us'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id','name','email','message'];
    
}

