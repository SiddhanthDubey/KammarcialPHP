<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class ForumTopicModel extends Model
{
    protected $table = 'forum_topic'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = [ 'name', 'status' , 'date_time'];
    
    
}