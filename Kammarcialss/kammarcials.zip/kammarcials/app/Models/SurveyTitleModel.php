<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class SurveyTitleModel extends Model
{
    protected $table = 'survey_title'; // sleep_video_list_discover folder
    protected $primaryKey = 'id';
    protected $allowedFields = ['title'];
    
}

