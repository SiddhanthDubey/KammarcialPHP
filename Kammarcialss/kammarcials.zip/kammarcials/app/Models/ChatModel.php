<?php namespace App\Models;
  
use CodeIgniter\Model;
  
class ChatModel extends Model
{
    protected $table = 'chats';
    protected $primaryKey = 'chat_id';
    protected $allowedFields = ['chat_sender_id', 'chat_receiver_id', 'chat_message', 'chat_created_at' ];
    
    
}