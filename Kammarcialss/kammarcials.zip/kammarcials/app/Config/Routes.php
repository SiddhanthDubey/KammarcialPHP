<?php use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

  //  $routes->post('admin/login', 'Admin\Admin::login');



$routes->get("rejected", "Home::rejected");
$routes->get("return", "Home::return");
$routes->get("callback", "Home::callback");
$routes->get("accepted", "Home::accepted");



$routes->group("admin", function ($routes) {
    $routes->get('/', 'Admin\Admin::index');
    $routes->get('login', 'Admin\Admin::index');
    $routes->post('login', 'Admin\Admin::login');
    $routes->get('admin_logout', 'Admin\Admin::admin_logout');
    $routes->get('register', 'Admin\Admin::register');
    $routes->post('post-register', 'Admin\Admin::postRegister');
    
     $routes->get('app_logo', 'Admin\Admin::app_logo');
    $routes->get('app_logo/add_app_logo', 'Admin\Admin::addapp_logo');
    $routes->post('app_logo/save', 'Admin\Admin::saveapp_logo');
    $routes->get('app_logo/edit/(:num)', 'Admin\Admin::editapp_logo/$1');
    $routes->post('app_logo/update/(:num)', 'Admin\Admin::updateapp_logo/$1');
    $routes->get('app_logo/delete/(:num)', 'Admin\Admin::deleteapp_logo/$1');
    
    
     $routes->get('privacy_policy', 'Admin\Admin::privacy_policy');
    $routes->get('privacy_policy/add_privacy_policy', 'Admin\Admin::addprivacy_policy');
    $routes->post('privacy_policy/save', 'Admin\Admin::saveprivacy_policy');
    $routes->get('privacy_policy/edit/(:num)', 'Admin\Admin::editprivacy_policy/$1');
    $routes->post('privacy_policy/update/(:num)', 'Admin\Admin::updateprivacy_policy/$1');
    $routes->get('privacy_policy/delete/(:num)', 'Admin\Admin::deleteprivacy_policy/$1');
    
    $routes->get('about_us', 'Admin\Admin::about_us');
    $routes->get('about_us/add_privacy_policy', 'Admin\Admin::addprivacy_policy');
    $routes->post('about_us/save', 'Admin\Admin::saveprivacy_policy');
    $routes->get('about_us/edit/(:num)', 'Admin\Admin::editabout_us/$1');
    $routes->post('about_us/update/(:num)', 'Admin\Admin::updateabout_us/$1');
    $routes->get('about_us/delete/(:num)', 'Admin\Admin::deleteprivacy_policy/$1');
    
     $routes->get('withdraw_requests', 'Admin\Admin::withdraw_requests');
     $routes->get('withdraw_history', 'Admin\Admin::withdraw_history');
     $routes->get('withdraw_requests_payment_admin/(:num)', 'Admin\Admin::add_withdraw_requests_payment_admin/$1');
     
     $routes->post('withdraw_requests/update/(:num)', 'Admin\Admin::updatewithdraw_requests/$1');
    
    
      $routes->get('survey_question', 'Admin\Admin::survey_question'); 
    $routes->get('survey_question/add_survey_question', 'Admin\Admin::addsurvey_question');
    $routes->post('survey_question/save', 'Admin\Admin::savesurvey_question');
    $routes->get('survey_question/edit/(:num)', 'Admin\Admin::editsurvey_question/$1');
    $routes->post('survey_question/update/(:num)', 'Admin\Admin::updatesurvey_question/$1');
    $routes->get('survey_question/delete/(:num)', 'Admin\Admin::deletesurvey_question/$1'); //
    
    
    
    $routes->get('survey_title', 'Admin\Admin::survey_title');
    $routes->get('survey_title/add_survey_title', 'Admin\Admin::addsurvey_title');
    $routes->post('survey_title/save', 'Admin\Admin::savesurvey_title');
    $routes->get('survey_title/edit/(:num)', 'Admin\Admin::editsurvey_title/$1');
    $routes->post('survey_title/update/(:num)', 'Admin\Admin::updatesurvey_title/$1');
    $routes->get('survey_title/delete/(:num)', 'Admin\Admin::deletesurvey_title/$1'); //
    
    
    
    $routes->get('banner', 'Admin\Admin::banner');
    $routes->get('banner/add_banner', 'Admin\Admin::addbanner');
    $routes->post('banner/save', 'Admin\Admin::savebanner');
    $routes->get('banner/edit/(:num)', 'Admin\Admin::editbanner/$1');
    $routes->post('banner/update/(:num)', 'Admin\Admin::updatebanner/$1');
    $routes->get('banner/delete/(:num)', 'Admin\Admin::deletebanner/$1');
    
      $routes->get('services', 'Admin\Admin::services');
    $routes->get('services/add_services', 'Admin\Admin::addservices');
    $routes->post('services/save', 'Admin\Admin::saveservices');
    $routes->get('services/edit/(:num)', 'Admin\Admin::editservices/$1');
    $routes->post('services/update/(:num)', 'Admin\Admin::updateservices/$1');
    $routes->get('services/delete/(:num)', 'Admin\Admin::deleteservices/$1');
    
    
    $routes->get('subcription', 'Admin\Admin::subcription');
    $routes->get('subcription/add_subcription', 'Admin\Admin::addsubcription');
    $routes->post('subcription/save', 'Admin\Admin::savesubcription');
    $routes->get('subcription/edit/(:num)', 'Admin\Admin::editsubcription/$1');
    $routes->post('subcription/update/(:num)', 'Admin\Admin::updatesubcription/$1');
    $routes->get('subcription/delete/(:num)', 'Admin\Admin::deletesubcription/$1');
    
    
      $routes->get('faq', 'Admin\Admin::faq');
    $routes->get('faq/add_faq', 'Admin\Admin::addfaq');
    $routes->post('faq/save', 'Admin\Admin::savefaq');
    $routes->get('faq/edit/(:num)', 'Admin\Admin::editfaq/$1');
    $routes->post('faq/update/(:num)', 'Admin\Admin::updatefaq/$1');
    $routes->get('faq/delete/(:num)', 'Admin\Admin::deletefaq/$1');
    
    $routes->get('visual_dashboard', 'Admin\Admin::visual_dashboard');
    $routes->get('user_dashboard', 'Admin\Admin::user_dashboard');
    
    $routes->get('users', 'Admin\Admin::users');
    $routes->get('users/add_user', 'Admin\Admin::addUser');
    $routes->post('users/save', 'Admin\Admin::saveUser');
    $routes->get('users/edit/(:num)', 'Admin\Admin::editUser/$1');
    $routes->post('users/update/(:num)', 'Admin\Admin::updateUser/$1');
    $routes->get('users/view/(:num)', 'Admin\Admin::viewUser/$1');
    $routes->get('users/delete/(:num)', 'Admin\Admin::deleteUser/$1');
    
    
     $routes->get('professional', 'Admin\Admin::professional');
    $routes->get('professional/add_professional', 'Admin\Admin::addprofessional');
    $routes->post('professional/save', 'Admin\Admin::saveprofessional');
    $routes->get('professional/edit/(:num)', 'Admin\Admin::editprofessional/$1');
    $routes->post('professional/update/(:num)', 'Admin\Admin::updateprofessional/$1');
    $routes->get('professional/view/(:num)', 'Admin\Admin::viewprofessional/$1');
    $routes->get('professional/delete/(:num)', 'Admin\Admin::deleteprofessional/$1');
    
    
    $routes->get('company', 'Admin\Admin::company');
    $routes->get('company/add_company', 'Admin\Admin::addcompany');
    $routes->post('company/save', 'Admin\Admin::savecompany');
    $routes->get('company/edit/(:num)', 'Admin\Admin::editcompany/$1');
    $routes->post('company/update/(:num)', 'Admin\Admin::updatecompany/$1');
    $routes->get('company/view/(:num)', 'Admin\Admin::viewcompany/$1');
    $routes->get('company/delete/(:num)', 'Admin\Admin::deletecompany/$1');
    
    
    
     $routes->post('update-profile', 'Admin\Admin::updateAdminProfile');
    $routes->get('profile', 'Admin\Admin::updateProfile');
    $routes->post('update-profile-password', 'Admin\Admin::updateAdminProfilePassword');
    
    
  
    
    $routes->get('sub-category', 'Home::index');
    $routes->get('main-category', 'Home::index');
    $routes->get('clinics', 'Home::index');
    $routes->get('clinic-tests', 'Home::index');
    $routes->get('available-tests', 'Home::index');
   // $routes->get('banner', 'Home::index');
    $routes->get('body-parts', 'Home::index');
    $routes->get('carts', 'Home::index');
    $routes->get('chats', 'Home::index');
    $routes->get('cycle-tracking_option', 'Home::index');
    $routes->get('cycle-tracking_sub_option', 'Home::index');
    $routes->get('employees', 'Home::index');
    $routes->get('health-record', 'Home::index');
    $routes->get('insights', 'Home::index');
    $routes->get('posts', 'Home::index');
    $routes->get('products', 'Home::index');
    $routes->get('questions', 'Home::index');
    $routes->get('questions-options', 'Home::index');
    $routes->get('sonography-ultrasounds', 'Home::index');
    $routes->get('users', 'Home::index');
    $routes->get('workout-types', 'Home::index');
});

$routes->group("admin", ['filter' => 'adminFilter'], function ($routes) {
    $routes->get('dashboard', 'Admin\Admin::dashboard');
    $routes->get('category', 'Admin\Admin::category');
    $routes->get('category/add_category', 'Admin\Admin::addCategory');
    $routes->post('category/save', 'Admin\Admin::saveCategory');
    $routes->get('category/edit/(:num)', 'Admin\Admin::editCategory/$1');
    $routes->post('category/update/(:num)', 'Admin\Admin::updateCategory/$1');
    $routes->get('category/delete/(:num)', 'Admin\Admin::deleteCategory/$1');
    $routes->get('doctors', 'Admin\Admin::doctors');
    $routes->get('doctors/add_doctor', 'Admin\Admin::addDoctor');
    $routes->post('doctors/save', 'Admin\Admin::saveDoctor');
    $routes->get('doctors/edit/(:num)', 'Admin\Admin::editDoctor/$1');
    $routes->post('doctors/update/(:num)', 'Admin\Admin::updateDoctor/$1');
    $routes->get('doctors/delete/(:num)', 'Admin\Admin::deleteDoctor/$1');
    $routes->get('available-clinics', 'Admin\Admin::availableClinic');
    $routes->get('available-clinics/add_available_clinics', 'Admin\Admin::addAvailableclinic');
    $routes->post('available-clinics/save', 'Admin\Admin::saveAvailableclinic');
    $routes->get('available-clinics/edit/(:num)', 'Admin\Admin::editAvailableclinic/$1');
    $routes->post('available-clinics/update/(:num)', 'Admin\Admin::updateAvailableclinic/$1');
    $routes->get('available-clinics/delete/(:num)', 'Admin\Admin::deleteAvailableclinic/$1');
    $routes->get('guide', 'Admin\Admin::guide');
    $routes->get('guide/add-guide', 'Admin\Admin::addGuide');
    $routes->post('guide/save', 'Admin\Admin::saveGuide');
    $routes->get('guide/edit-guide/(:num)', 'Admin\Admin::editGuide/$1');
    $routes->post('guide/update/(:num)', 'Admin\Admin::updateGuide/$1');
    $routes->get('guide/delete/(:num)', 'Admin\Admin::deleteGuide/$1');
    
  
    
    
    $routes->get('sub_category', 'Admin\Admin::sub_category'); 
    $routes->get('sub_category/add_sub_category', 'Admin\Admin::addSubcategory');
    $routes->post('sub_category/save', 'Admin\Admin::saveSubCategory');
    $routes->get('sub_category/edit/(:num)', 'Admin\Admin::editSubCategory/$1');
    $routes->post('sub_category/update/(:num)', 'Admin\Admin::updateSubCategory/$1');
    $routes->get('sub_category/delete/(:num)', 'Admin\Admin::deleteSubCategory/$1');
    
    $routes->get('forum_topic', 'Admin\Admin::forum_topic'); 
    $routes->get('forum_topic/add_forum_topic', 'Admin\Admin::add_forum_topic');
    $routes->post('forum_topic/save', 'Admin\Admin::save_forum_topic');
    $routes->get('forum_topic/edit/(:num)', 'Admin\Admin::edit_forum_topic/$1');
    $routes->post('forum_topic/update/(:num)', 'Admin\Admin::update_forum_topic/$1');
    $routes->get('forum_topic/delete/(:num)', 'Admin\Admin::delete_forum_topic/$1');
    
    $routes->get('forum_topic_discussion', 'Admin\Admin::forum_topic_discussion'); 
    $routes->get('forum_topic_discussion/add_forum_topic_discussion', 'Admin\Admin::add_forum_topic_discussion');
    $routes->post('forum_topic_discussion/save', 'Admin\Admin::save_forum_topic_discussion');
    $routes->get('forum_topic_discussion/edit/(:num)', 'Admin\Admin::edit_forum_topic_discussion/$1');
    $routes->post('forum_topic_discussion/update/(:num)', 'Admin\Admin::update_forum_topic_discussion/$1');
    $routes->get('forum_topic_discussion/delete/(:num)', 'Admin\Admin::delete_forum_topic_discussion/$1');
    
    
    
    
    $routes->get('forum_categories', 'Admin\Admindata::forum_categories'); 
    $routes->get('forum_categories/add_forum_categories', 'Admin\Admindata::add_forum_categories');
    $routes->post('forum_categories/save', 'Admin\Admindata::save_forum_categories');
    $routes->get('forum_categories/edit/(:num)', 'Admin\Admindata::edit_forum_categories/$1');
    $routes->post('forum_categories/update/(:num)', 'Admin\Admindata::update_forum_categories/$1');
    $routes->get('forum_categories/delete/(:num)', 'Admin\Admindata::delete_forum_categories/$1');
    
    
    $routes->get('dashboard_one', 'Admin\Admin::dashboard_one');
    
    $routes->get('contact_us', 'Admin\Admin::contact_us');
    
    $routes->get('complain_list', 'Admin\Admin::complain_list');
    
   
    
    
    
    $routes->get('company_dashboard', 'Admin\Admin::company_dashboard');
    

     
    
    
});

$routes->group("api", function ($routes) {
    
    $routes->post("register", "Register::register");
    
    $routes->post("login", "Login::index");
    
    $routes->post("password_reset", "Register::send_Email_Otp");
    
    $routes->post("check_otp", "User::check_otp");
    
    $routes->get("get_country", "User::get_country");
    
     $routes->post("add_withdraw_request", "User::add_withdraw_request");
    
     $routes->post("update_user_bank_detail", "User::update_user_bank_detail");
     
        $routes->get("get_bank_detail", "Login::get_bank_detail");
    
     //====================== start api=======================================
     
     
     
      $routes->post("get_token_data", "Login::get_token_data");
    
    $routes->post("sendUserOtp", "Register::sendUserOtp");
    $routes->post("user_number_verification", "User::user_number_verification");
    $routes->post("create_new_password", "User::create_new_password");
    
    
     $routes->get('get_logo', "Api\Categories::get_logo");
     
      $routes->get('get_privacy_policy', "Api\Categories::get_privacy_policy");
      
       $routes->get('get_about_us', "Api\Categories::get_about_us");
       
       $routes->get('get_terms_conditions', "Api\Categories::get_terms_conditions");
       
       $routes->post('add_contact_us', "Api\ContactUs::add_contact_us");
       
       $routes->get('get_contact_us', "Api\ContactUs::get_contact_us");
       
       $routes->get('get_user_email', "Api\Support::get_user_email");
       
       $routes->post('add_support', "Api\Support::add_support");
       
       $routes->post('add_survey', "Api\Survey::add_survey");
       
       $routes->get('get_survey', "Api\Survey::get_survey");
       $routes->get('add_survey_answer', "Api\Survey::add_survey_answer");
       $routes->post('insert_survey_answer_history', "Api\Survey::insert_survey_answer_history");
       
        $routes->get('get_user_survey_history', "Api\Survey::get_user_survey_history");
        
        $routes->get('scratch_survey_by_user', "Api\Survey::scratch_survey_by_user");
       
       
       $routes->post('add_transcation', "Api\Transcation::add_transcation");
       
       $routes->get('get_transcation', "Api\Transcation::get_transcation");
       
       
       $routes->get('get_faq', "Api\Categories::get_faq"); 
    
    $routes->get('get-banner', "Api\Categories::get_banner");
    
     $routes->get('get-services', "Api\Categories::get_services");
     
     $routes->post("user_register", "User::user_register");
     
      $routes->post("add_user_view", "User::add_user_view");
      
        
     $routes->get('get-langauge', "Api\Categories::get_langauge");
     
     $routes->post("add-contact-us", "User::add_contact_us");
     
      $routes->post("add_complain", "User::add_complain");
      
       $routes->get("juuuu", "User::juuuu");
       
       $routes->post("add_rates", "User::add_rates");
       $routes->post("get_user_rating", "User::get_user_rating");
     
    
     $routes->post("sendProviderOtp", "Register::sendProviderOtp");
     $routes->post("provider_number_verification", "User::provider_number_verification");
     $routes->post("register_professional_provider", "User::register_professional_provider");
      $routes->post("register_company_provider", "User::register_company_provider");
        $routes->post("get_professional_profile", "Login::get_professional_profile");
       $routes->post("get_company_profile", "Login::get_company_profile");
       
       
       
      
     $routes->post("update-langauage", "Login::update_langauage");
     $routes->post("update-notiification", "Login::update_notiification");
     
       $routes->post("get_provider_detail", "Login::get_provider_detail");
       
       $routes->post("add_gallery_professional_provider", "User::add_gallery_professional_provider");
       
       $routes->post("delete_gallery_professional", "User::delete_gallery_professional");
       
       $routes->post("delete_company_license", "User::delete_company_license");
       
        $routes->post('provider-list', "Api\Categories::provider_list");
        
        $routes->post("forget_password", "User::forget_password");
        
         $routes->post("get_nearest_provider", "User::get_nearest_provider");
         
          $routes->post("calculateDistance", "User::calculateDistance");
    
    
    //====================== end api=======================================
    
   
    $routes->get("users", "User::index", ['filter' => 'authFilter']);

   
    
    
    $routes->get("get_health_record", "User::get_health_record");
    $routes->post("get_notification", "User::get_notification");
    $routes->post("change_password", "User::change_password");
    
 
    
    $routes->post('doctors/delete-account', "Api\Doctors::delete_account");
    
    
});

// $routes->get("male_fertility", "Home::male_fertility");

$routes->group("api", ['filter' => 'authFilter'], function ($routes) {
    
    //  =============== start Api ====================
     $routes->post("update_profile", "User::update_profile");
     
     $routes->post("update_user_survay", "User::update_user_survay");
   
      $routes->post("log_out", "User::log_out");
      
      $routes->get("get_profile", "Login::get_profile"); 
    
     
       //  =============== End Api ====================
    
    
  
    /**************************************************************/
    $routes->resource('products', ['controller' => 'Api\Products']);
    $routes->get('products-by-category-id', "Api\Products::products_by_category_id");
    $routes->get('products-by-id', "Api\Products::products_by_id");
    /**************************************************************/
    $routes->resource('address', ['controller' => 'Api\Address']);
    $routes->post("upadte-address", "Api\Address::upadte_address");
    $routes->get('address-by-user-id', "Api\Address::address_by_user_id");
    $routes->get('address-by-id', "Api\Address::address_by_id");
    /**************************************************************/
    $routes->resource('categories', ['controller' => 'Api\Categories']);
    $routes->resource('main-categories', ['controller' => 'Api\MainCategories']);
    
    
    $routes->get('sub-categories-by-category-id', "Api\Categories::sub_categories_by_category_id");
    


    /**************************************************************/
    $routes->resource('posts', ['controller' => 'Api\Posts']);
    /**************************************************************/
    /**************************************************************/
    $routes->resource('chats', ['controller' => 'Api\Chats']);
    $routes->post('chats/chat-between-user', "Api\Chats::chat_between_user");
    
    /**************************************************************/
   
    
  
    $routes->post('bookingAppointment/update-booking-appointment', "Api\BookingAppointment::update_booking_appointment");
    $routes->post('payex/get-payment-token', "Api\Payex::get_payment_token");
    $routes->post('payex/payex-payment', "Api\Payex::payex_payment");
    
     
   //  $routes->get('DoctorAvailability/add-doctor-availability', "Api\DoctorAvailability::add_doctor_availability");
   //  $routes->get('DoctorAvailability/get-doctor-availability', "Api\DoctorAvailability::get_doctor_availability");
    $routes->resource('doctors', ['controller' => 'Api\Doctors']);
    
    $routes->get('tvsscan/get-scan-clinic-List', "Api\TvsScan::get_scan_clinic_List");
    $routes->get('tvsscan/get-scan-clinic-detail-by-id', "Api\TvsScan::get_scan_clinic_detail");
    $routes->get('tvsscan/get-trainer-type-list', "Api\TvsScan::get_trainer_type_list");

   
    $routes->resource('available-tests', ['controller' => 'Api\AvailableTests']);
    $routes->post('available-tests/get-available-tests-by-id', "Api\AvailableTests::get_available_tests_by_id");
    /**************************************************************/
    /**************************************************************/
    $routes->resource('available-clinics', ['controller' => 'Api\AvailableClinics']);
    $routes->post('available-clinics/get-available-clinics-by-id', "Api\AvailableClinics::get_available_clinics_by_id");
    $routes->post('available-clinics/get-available-clinics-by-test-id', "Api\AvailableClinics::get_available_clinics_by_test_id");
    
    $routes->post('available-clinics/get-clinic-detail-by-id', "Api\AvailableClinics::get_clinic_detail_by_id");
 //   $routes->post('available-clinics/get-clinic-notification', "Api\AvailableClinics::get_clinic_notification");
    
    $routes->get('ClinicNotification/get-clinic-notification', "Api\ClinicNotification::get_clinic_notification");
    $routes->get('ClinicNotification/get-clinic-notification-details', "Api\ClinicNotification::get_clinic_notification_details");
    /**************************************************************/
    /**************************************************************/
    $routes->resource('questions', ['controller' => 'Api\Questions']);
    /**************************************************************/
    /**************************************************************/
    $routes->post('guides/get-guid-by-sub-categorie-id', "Api\Guides::get_guid_by_sub_categorie_id");
    $routes->post('guides/upload-menu-by-guide-id', "Api\Guides::upload_menu_by_guide_id");
    $routes->post('guides/get-menu-by-guide-id', "Api\Guides::get_menu_by_guide_id");
    /**************************************************************/
    /**************************************************************/
    $routes->get('nutritional-guidance/get-nutritional-guidance-blog-by-sub-categorie-id', "Api\NutritionalGuidanceBlogs::get_nutritional_guidance_blog_by_sub_categorie_id");
    /**************************************************************/
    
    
    $routes->get('sleep-management/get-sleep-management-categories', "Api\SleepManagement::get_sleep_management_categories");
    $routes->get('sleep-management/get-discover-filters', "Api\SleepManagement::get_discover_filters");
     
    $routes->get('sleep-management/get-sleep-management-sound-tracks', "Api\SleepManagement::get_sleep_management_sound_tracks");
    $routes->get('sleep-management/get-sleep-management-sound-tracks-by-id', "Api\SleepManagement::get_sleep_management_sound_tracks_by_id");
    $routes->get('sleep-management/get-soundtrack-categories', "Api\SleepManagement::get_sleep_management_sound_tracks_categories");
    $routes->get('sleep-management/get-recommended-soundtracks', "Api\SleepManagement::get_sleep_management_sound_tracks_recommended");
    
    $routes->get('sleep-management/get-next-video-list-discover', "Api\SleepManagementVideo::get_next_video_list_discover");
    
     $routes->get('sleep-management/get-single-video', "Api\SleepManagementVideo::get_single_video");
     
      $routes->get('sleep-management/get-forum-topic', "Api\SleepManagementVideo::get_forum_topic");
      $routes->get('sleep-management/get-forum-discussion', "Api\SleepManagementVideo::get_forum_discussion");
     
     $routes->get('sleep-management/get-forum-category', "Api\SleepManagementVideo::get_forum_category");
     $routes->post('sleep-management/contact-forum', "Api\SleepManagementVideo::add_contact_forum");

    
    $routes->get('sleep-management/favorites/get-sleep-management-sound-track-favourites', "Api\SleepManagement::get_sleep_management_sound_track_favourites");
    $routes->get('sleep-management/favorites/sleep-management-sound-track-delete-favourites', "Api\SleepManagement::sleep_management_sound_track_delete_favourites");
    $routes->get('sleep-management/favorites/sleep-management-sound-track-add-favourites', "Api\SleepManagement::sleep_management_sound_track_add_favourites");

    $routes->get('sleep-management/intimacy-management/get-intimacy-management-categories', "Api\SleepManagement::get_intimacy_management_categories");
    $routes->get('sleep-management/intimacy-management/get-intimacy-management-categories-blogs', "Api\SleepManagement::get_intimacy_management_categories_blogs");
    $routes->get('sleep-management/intimacy-management/get-recommendation-blogs', "Api\SleepManagement::get_recommendation_blogs");
    $routes->get('sleep-management/intimacy-management/save-intimacy-management-blogs', "Api\SleepManagement::save_intimacy_management_blogs");
    $routes->get('sleep-management/intimacy-management/get-save-intimacy-management-blogs', "Api\SleepManagement::get_save_intimacy_management_blogs");
   
    $routes->get('sleep-management/zen-book/get-zen-book-providers-by-id', "Api\SleepManagement::get_zen_book_providers_by_id");
    $routes->get('sleep-management/zen-book/get-zen-book-providers', "Api\SleepManagement::get_zen_book_providers");
    $routes->get('sleep-management/zen-book/get-zen-book-nearest-providers', "Api\SleepManagement::get_zen_book_nearest_providers");
    
    $routes->get('sleep-management/zen-book/get-zen-book-packages', "Api\SleepManagement::get_zen_book_packages");
    $routes->get('sleep-management/zen-book/get-zen-book-bookings', "Api\SleepManagement::get_zen_book_bookings");
    $routes->get('sleep-management/zen-book/get-zen-book-add-bookings', "Api\SleepManagement::get_zen_book_add_bookings");
    $routes->get('sleep-management/zen-book/get-zen-book-update-bookings', "Api\SleepManagement::get_zen_book_update_bookings");
    $routes->get('sleep-management/zen-book/get-zen-book-soft-delete-bookings', "Api\SleepManagement::get_zen_book_soft_delete_bookings");



    $routes->get('ZenbooklocationCategory/get-zenbook-locationcategory', "Api\ZenbooklocationCategory::get_zenbook_locationcategory");
    /**************************************************************/
    
    $routes->get('expert-consultation/get-expert-consultation-categories', "Api\ExpertConsultations::get_expert_consultation_categories");
    $routes->get('expert-consultation/get-expert-consultation-doctors-by-categories', "Api\ExpertConsultations::get_expert_consultation_doctors_by_categories");
    $routes->get('expert-consultation/get-find-coach', "Api\ExpertConsultations::get_find_coach");
    $routes->get('expert-consultation/get-find-coach-category', "Api\ExpertConsultations::get_find_coach_category");
    $routes->get('expert-consultation/get-expert-consultation-doctors-details', "Api\ExpertConsultations::get_expert_consultation_doctors_details");

    /**************************************************************/
    

    $routes->get('personal-trainer/get-trainer-category', "Api\PersonalTrainers::get_trainer_category");
    $routes->get('personal-trainer/get-personal-trainer', "Api\PersonalTrainers::get_personal_trainer");
    $routes->get('personal-trainer/get-personal-trainer-details', "Api\PersonalTrainers::get_personal_trainer_details");
    $routes->get('personal-trainer/get-personal-trainer-category', "Api\PersonalTrainers::get_personal_trainer_category");

    /**************************************************************/
    
    $routes->get('fertility-educations/get-fertility-educations-category', "Api\FertilityEducations::get_fertility_educations_category");
    $routes->get('fertility-educations/get-fertility-educations-blogs-by-category', "Api\FertilityEducations::get_fertility_educations_blog_by_category");
    $routes->get('fertility-educations/get-fertility-educations-blogs-details', "Api\FertilityEducations::get_fertility_educations_blog_details");
    
    $routes->get('fertility-educations/get-fertility-test-kit', "Api\FertilityEducations::get_fertility_test_kit");
    
    $routes->post("fertility-educations/add-fertility-report", "Api\FertilityEducations::add_fertility_report::");
    $routes->post("fertility-educations/get-fertility-report", "Api\FertilityEducations::get_fertility_report::");
    $routes->get('fertility-educations/get-banner-fertility', "Api\FertilityEducations::get_banner_fertility");
    $routes->get('fertility-educations/get-sperm-assessment', "Api\FertilityEducations::get_sperm_assessment");


    $routes->get('fertility-educations/get-fertility-educations-popular-blog', "Api\FertilityEducations::get_fertility_educations_popular_blog");
    $routes->get('fertility-educations/get-fertility-educations-featured-blog', "Api\FertilityEducations::get_fertility_educations_featured_blog");
    $routes->get('fertility-educations/get-fertility-educations-saved-blog', "Api\FertilityEducations::get_fertility_educations_saved_blog");

    $routes->get('fertility-educations/get-fertility-educations-home', "Api\FertilityEducations::get_fertility_educations_home");


    $routes->get('fertility-educations/get-fertility-webinars-blogs-by-category', "Api\FertilityEducations::get_fertility_webinars_blogs_by_category");
    $routes->get('fertility-educations/get-fertility-webinars-details', "Api\FertilityEducations::get_fertility_webinars_details");
    
    $routes->get('fertility-educations/get-fertility-webinars-banner', "Api\FertilityEducations::get_fertility_webinars_banner");
    /**************************************************************/


});
