<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Add Main Category</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
<!--        <p class="breadcrumb-item"><a href="<?= base_url('admin/main-category'); ?>" class="btn btn-primary">Back</a></p>-->
<!--    </div>-->
<!--    </div>-->

  <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add Main Category</h3>
                   
    <p class="breadcrumb-item"><a href="<?= base_url('admin/main-category'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
    
    
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <!--<section class="section">-->
    <!--    <div class="row">-->
    <!--        <div class="col-lg-12">-->
    <!--            <div class="card">-->
    <!--                <div class="card-body">-->
                        <h5 class="card-title">Add Main Category</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/main-category/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="image" class="form-label">Image:</label>
                                <input type="file" class="form-control" id="image" name="image" style="height:11%">
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status:</label>
                                <select class="form-control" name="status" id="status">
                                      <option value="" disabled selected>Select Status</option>
                                    <option value="active">Active</option>
                                    <option value="deactive">Deactive</option>
                                </select>
                            </div>
                           
                            <div class="mb-3">
                           <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                           <label for="description" class="form-label">Description:</label>
                           <textarea id="editor" name="description"></textarea>
                            <script>
                              CKEDITOR.replace('editor');
                            </script>
                            </div>
                            <div class="mb-3">
                                <label for="banner_image" class="form-label">Banner Image:</label>
                                <input type="file" class="form-control" id="banner_image" name="banner_image" style="height:11%">
                            </div>
                            <div class="mb-3">
                                <label for="banner_video" class="form-label">Banner Video:</label>
                                <input type="file" class="form-control" id="banner_video" name="banner_video" accept="video/*" style="height:11%">
                            </div>
                            <button type="submit" class="btn btn-primary" style="width:11%">Add Main Category</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
