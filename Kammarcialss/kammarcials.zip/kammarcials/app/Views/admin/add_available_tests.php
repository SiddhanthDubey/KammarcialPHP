<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Add Test</h1>
    </div>
    <div class="col-md-6 text-end">
        <p class="breadcrumb-item"><a href="<?= base_url('admin/available-tests'); ?>" class="btn btn-primary">Back</a></p>
    </div>
    </div>
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Tests</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/available-tests/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="test_name" class="form-label">Test Name:</label>
                                <input type="text" class="form-control" name="test_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="test_image" class="form-label">Test Image:</label>
                                <input type="file" class="form-control" id="test_image" name="test_image" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="test_status" class="form-label">Test Status:</label>
                                <select class="form-control" name="test_status">
                                    <option value="active">ACTIVE</option>
                                    <option value="deactive">DEACTIVE</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="test_tags" class="form-label">Test Tags:</label>
                                <input type="text" class="form-control" name="test_tags" required>
                            </div>

                          
                            <button type="submit" class="btn btn-primary">Add Test</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>
