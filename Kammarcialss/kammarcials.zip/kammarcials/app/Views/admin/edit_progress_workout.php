<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Progress Workout</h3>
                    
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Edit Progress Workout</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
        <p class="breadcrumb-item"><a href="<?= base_url('admin/progress_workout'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit progress Workout</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/progress_workout/update/' . $doctor['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$doctor['id'];?>">
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Description:</label>
                                <input type="text" class="form-control" name="description" value="<?= $doctor['description']; ?>">
                            </div>
                            
                            
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($doctor['image']) && file_exists(ROOTPATH . 'public/uploads/workout/' . $doctor['image'])): ?>
                                    <img src="<?= base_url('public/uploads/workout/' . $doctor['image']); ?>" alt="Doctor Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="image" class="form-label">New  Image:</label>
                                <input type="file" class="form-control" id="image" name="image" style=" height: 11%;">
                            </div>
                            
                            
                            
                            <button type="submit" class="btn btn-primary" style=" width: 14%;">Update Progress Workout</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

