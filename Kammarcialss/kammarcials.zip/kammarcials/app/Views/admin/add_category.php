<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Add Category</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add Category</h3>
        <p class="breadcrumb-item"><a href="<?= base_url('admin/category'); ?>" class="btn btn-primary">Back</a></p>
    <!--</div>-->
    </div>
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Category</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/category/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="category_name" class="form-label">Category Name:</label>
                                <input type="text" class="form-control" name="category_name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label>Main Category:</label>
                                <select class="form-control " name="main_category_id" id="main_category_id">
                                  <option value="" disabled selected>Select Main Category</option>
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('main_categories');
                                    $query = $builder->select('id, name')->get();
                                    $results = $query->getResultArray();
                                  
                                   
                                        foreach ($results as $result) { ?>
                                            <option value="<?= $result['id']; ?>"><?= $result['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            
                            <?php /*
                            <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('main_categories');
                                    $query = $builder->select('id, name')->get();
                                    $main_categories = $query->getResultArray();
                                    ?>
                                    
                            <div class="form-group">
                                <label for="main_category_id">Main Category:</label>
                                <select class="form-control" name="main_category_id" placeholder="Select Main Category" required>
                                      <?php foreach ($main_categories as $main_category) { ?>
                                      <option><?php echo $main_category->name; ?></option>
                                 <?php } ?>
                              </select>
                             </div>
                             */ ?>
                            <div class="mb-3">
                                <label for="category_image" class="form-label">Category Image:</label>
                                <input type="file" class="form-control" id="category_image" name="category_image" style="height:10%">
                            </div>
                            <div class="mb-3">
                                <label for="type" class="form-label">Type:</label>
                                <select class="form-control" name="type" id="type">
                                      <option value="" disabled selected>Select Type</option>
                                    <option value="SIMPLE">SIMPLE</option>
                                    <option value="PROGRESS_BAR">PROGRESS_BAR</option>
                                </select>
                            </div>
                            <!-- <div class="mb-3">-->
                            <!--    <label for="description" class="form-label">Description:</label>-->
                            <!--    <textarea class="form-control" id="description" name="description"></textarea>-->
                            <!--</div>-->
                            <div class="mb-3">
                           <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                           <label for="description" class="form-label">Description:</label>
                           <textarea id="editor" name="description"></textarea>
                            <script>
                              CKEDITOR.replace('editor');
                            </script>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Category</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
