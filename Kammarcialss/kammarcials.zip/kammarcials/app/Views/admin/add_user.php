<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Add User</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
 <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add User</h3>
        <p class="breadcrumb-item"><a href="<?= base_url('admin/users'); ?>" class="btn btn-primary">Back</a></p>
    </div>
    <!--</div>-->
    <!-- End Page Title -->
    <!--<section class="section">-->
    <!--    <div class="row">-->
    <!--        <div class="col-lg-12">-->
    <!--            <div class="card">-->
    <!--                <div class="card-body">-->
                        <h5 class="card-title">Add User</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/users/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="user_name" class="form-label">User Name:</label>
                                <input type="text" class="form-control" name="user_name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Password:</label>
                                <input type="password" class="form-control" name="password" required>
                            </div>
                            
                            <!--<div class="mb-3">-->
                            <!--    <label for="company_name" class="form-label">Age:</label>-->
                            <!--    <input type="text" class="form-control" name="age" required>-->
                            <!--</div>-->

                            <!-- Additional fields based on UserModel -->
                            <div class="mb-3">
                                <label for="mobile" class="form-label">Mobile:</label>
                                <input type="text" class="form-control" name="mobile">
                            </div>

                      <div class="mb-3">
                                <label>Country:</label>
                                <select class="form-control " name="country_id" id="country_id">
                                  <option value="" disabled selected>Select Country </option>
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('country');
                                    $query = $builder->select('id, name')->get();
                                    $results = $query->getResultArray();
                                  
                                   
                                        foreach ($results as $result) { ?>
                                            <option value="<?= $result['id']; ?>"><?= $result['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                                                </div>
                        

                            <!-- End of additional fields -->

                            <!--<div class="mb-3">-->
                            <!--    <label for="image" class="form-label">Profile Image:</label>-->
                            <!--    <input type="file" class="form-control" id="image" name="image" required style="height:10%;">-->
                            <!--</div>-->
                            
                            <button type="submit" class="btn btn-primary">Add User</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
