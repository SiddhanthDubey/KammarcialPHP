<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Edit Trainer</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Trainer</h3> 
        <p class="breadcrumb-item"><a href="<?= base_url('admin/trainer'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit Trainer</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/trainer/update/' . $doctor['personal_trainer_id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$doctor['personal_trainer_id'];?>">
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Trainer Name:</label>
                                <input type="text" class="form-control" name="personal_trainer_user_name" value="<?= $doctor['personal_trainer_user_name']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="post" class="form-label">Email:</label>
                                <input type="text" class="form-control" name="personal_trainer_email" value="<?= $doctor['personal_trainer_email']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="professional_profile" class="form-label">Trainer Company:</label>
                                <input type="text" class="form-control" name="personal_trainer_company_name" value="<?= $doctor['personal_trainer_company_name']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($doctor['personal_trainer_image']) && file_exists(ROOTPATH . 'public/uploads/personal_trainers/' . $doctor['personal_trainer_image'])): ?>
                                    <img src="<?= base_url('public/uploads/personal_trainers/' . $doctor['personal_trainer_image']); ?>" alt="Doctor Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="image" class="form-label">New Trainer Image:</label>
                                <input type="file" class="form-control" id="image" name="personal_trainer_image" style="height:10%;">
                            </div>
                            
                             <div class="mb-3">
                                <label for="consult_fee" class="form-label">Mobile:</label>
                                <input type="text" class="form-control" name="personal_trainer_mobile" value="<?= $doctor['personal_trainer_mobile']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label >Gender:</label>
                                <select class="form-control " name="personal_trainer_gender">
                  <option value = 'Male' <?php if($doctor['personal_trainer_gender'] == 'Male'){echo "selected";}?>>Male</option>
                  <option value = 'Female' <?php if($doctor['personal_trainer_gender'] == 'Female'){echo "selected";}?>>Female</option>

                                </select>
                            </div>
                            
                            
                            <div class="mb-3">
                                <label for="clinic" class="form-label">Date of Birth:</label>
                                <input type="date" class="form-control" name="personal_trainer_dob" value="<?= $doctor['personal_trainer_dob'];?>">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Trainer</button>
                        </form>
                  <!--/-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

