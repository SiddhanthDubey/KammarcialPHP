<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Edit Doctor</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Doctor</h3>
        <p class="breadcrumb-item"><a href="<?= base_url('admin/doctors'); ?>" class="btn btn-primary">Back</a></p>
    </div>
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit User</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/doctors/update/' . $doctor['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$doctor['id'];?>">
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Doctor Name:</label>
                                <input type="text" class="form-control" name="name" value="<?= $doctor['name']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="post" class="form-label">Post:</label>
                                <input type="text" class="form-control" name="post" value="<?= $doctor['post']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="professional_profile" class="form-label">Professional Profile:</label>
                                <input type="text" class="form-control" name="professional_profile" value="<?= $doctor['professional_profile']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($doctor['image']) && file_exists(ROOTPATH . 'public/uploads/doctors/' . $doctor['image'])): ?>
                                    <img src="<?= base_url('public/uploads/doctors/' . $doctor['image']); ?>" alt="Doctor Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="image" class="form-label">New Doctor Image:</label>
                                <input type="file" class="form-control" id="image" name="image" style="height:10%">
                            </div>
                            
                             <div class="mb-3">
                                <label for="consult_fee" class="form-label">Consult Fee:</label>
                                <input type="text" class="form-control" name="consult_fee" value="<?= $doctor['consult_fee']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="clinic" class="form-label">Clinic:</label>
                                <input type="text" class="form-control" name="clinic" value="<?= $doctor['clinic']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="year_of_experience" class="form-label">Year Of Experience:</label>
                                <input type="number" class="form-control" name="year_of_experience" value="<?= $doctor['year_of_experience']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="languages" class="form-label">Languages:</label>
                                <input type="text" class="form-control" name="languages" value="<?= $doctor['languages']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="education" class="form-label">Education:</label>
                                <input type="text" class="form-control" name="education" value="<?= $doctor['education']; ?>">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Doctor</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

