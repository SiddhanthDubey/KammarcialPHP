<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit forum Topic</h3>
                   
        <p class="breadcrumb-item"><a href="<?= base_url('admin/forum_topic'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Update forum_topic</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/forum_topic/update/' . $sonography_ultrasounds['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                           <input type="hidden"  class="form-control" name="su_id" value="<?=$sonography_ultrasounds['id'];?>">
                           
                           
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">forum Topic Name:</label>
                                <input type="text" class="form-control" name="name" value="<?= $sonography_ultrasounds['name']; ?>">
                            </div>
                            
                            
                            <button type="submit" class="btn btn-primary" style="width:180px;">Update forum Topic</button>
                        </form>

<?php include('include/newadmin-footer.php'); ?>
