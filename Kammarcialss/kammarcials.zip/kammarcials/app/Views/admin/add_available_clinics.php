<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Add Clinic</h1>
    </div>
    <div class="col-md-6 text-end">
        <p class="breadcrumb-item"><a href="<?= base_url('admin/available-clinics'); ?>" class="btn btn-primary">Back</a></p>
    </div>
    </div>
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Clinics</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/available-clinics/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="clinic_name" class="form-label">Clinic Name:</label>
                                <input type="text" class="form-control" name="clinic_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_image" class="form-label">Clinic Image:</label>
                                <input type="file" class="form-control" id="clinic_image" name="clinic_image" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_address" class="form-label">Clinic Address:</label>
                                <input type="text" class="form-control" name="clinic_address" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="clinic_monday" class="form-label">Clinic Monday:</label>
                                <input type="text" class="form-control" name="clinic_monday" required>
                            </div>

                            <!-- Additional fields based on UserModel -->
                            <div class="mb-3">
                                <label for="clinic_tuesday" class="form-label">Clinic Tuesday:</label>
                                <input type="text" class="form-control" name="clinic_tuesday">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_wednesday" class="form-label">Clinic Wednesday:</label>
                                <input type="text" class="form-control" name="clinic_wednesday">
                            </div>
                           

                            <!-- End of additional fields -->

                            
                            <div class="mb-3">
                                <label for="clinic_thursday" class="form-label">Clinic Thursday:</label>
                                <input type="text" class="form-control" name="clinic_thursday">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_friday" class="form-label">Clinic Friday:</label>
                                <input type="text" class="form-control" name="clinic_friday">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_saturday" class="form-label">Clinic Saturday:</label>
                                <input type="text" class="form-control" name="clinic_saturday">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_sunday" class="form-label">Clinic Sunday:</label>
                                <input type="text" class="form-control" name="clinic_sunday">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Add Clinic</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>
