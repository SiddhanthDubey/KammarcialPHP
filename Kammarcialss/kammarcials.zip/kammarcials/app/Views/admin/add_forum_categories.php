<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add Forum Discription Database</h3>
                   
<p class="breadcrumb-item"><a href="<?= base_url('admin/forum_categories'); ?>" class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Add forum Discription</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/forum_categories/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            
                            
                             <div class="mb-3">
                                <label>Forum Discussion Topic:</label>
                                <select class="form-control " name="forum_discussion_id" id="forum_discussion_id">
                                  <option value="" disabled selected>Select forum topic Discussion </option>
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('forum_discussion');
                                    $query = $builder->select('id, title')->get();
                                    $results = $query->getResultArray();
                                  
                                   
                                        foreach ($results as $result) { ?>
                                            <option value="<?= $result['id']; ?>"><?= $result['title']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label>Type:</label>
                                <select class="form-control " name="type" id="type"> 
                                  <option value="" disabled selected>Select Type </option>
                                   
                                  <option value="find">Find</option>
                                  <option value="setting">Setting</option>
                                       
                                     ?>
                                </select>
                            </div>
                             <div class="mb-3">
                                <label for="title" class="form-label">Image:</label>
                                <input type="file" class="form-control" name="image" style="height:10%;">
                            </div>
                            
                            <div class="mb-3">
                                <label for="title" class="form-label">Title:</label>
                                <input type="text" class="form-control" name="title" required>
                            </div>
                            <div class="mb-3">
                                <label for="title" class="form-label">Description:</label>
                                <input type="text" class="form-control" name="description" required>
                            </div>
                           
                           <!-- <div class="mb-3">-->
                           <!--<label for="description" class="form-label">Description:</label>-->
                           <!--<textarea id="editor" name="description"></textarea>-->
                           <!-- <script>-->
                           <!--   CKEDITOR.replace('editor');-->
                           <!-- </script>-->
                           <!-- </div>-->
                            
                            <button type="submit" class="btn btn-primary" style="width:180px;">Add Forum Discription</button>
                        </form>
<?php include('include/newadmin-footer.php'); ?>
