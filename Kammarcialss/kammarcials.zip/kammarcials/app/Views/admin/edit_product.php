<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Edit Product</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Product</h3>
        <p class="breadcrumb-item"><a href="<?= base_url('admin/products'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
    <!--</div>-->
    <!--<section class="section">-->
    <!--    <div class="row">-->
    <!--        <div class="col-lg-12">-->
    <!--            <div class="card">-->
    <!--                <div class="card-body">-->
                        <h5 class="card-title">Edit Product</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/products/update/' . $product['product_id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="product_id" value="<?=$product['product_id'];?>">
                            
                            <div class="mb-3">
                                <label for="product_name" class="form-label">Product Name:</label>
                                <input type="text" class="form-control" name="product_name" value="<?= $product['product_name']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="product_price" class="form-label">Product Price:</label>
                                <input type="number" class="form-control" name="product_price" value="<?= $product['product_price']; ?>">
                            </div>
                            <div class="mb3">
                                <label>Select Product Category <span class="red">*</span></label>
                                <select class="form-control " name="product_category_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('categories');
                                    $query = $builder->select('category_id, category_name')->get();
                                    $product_categories = $query->getResultArray();
                                    echo '<option value="" disabled>Select Product Category</option>';
                                   
                                        foreach ($product_categories as $product_category) { ?>
                                            <option value="<?= $product_category['category_id']; ?>" <?php if ($product_category['category_id'] == $product['product_category_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $product_category['category_name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($product['product_image']) && file_exists(ROOTPATH . 'public/uploads/products/' . $product['product_image'])): ?>
                                    <img src="<?= base_url('public/uploads/products/' . $product['product_image']); ?>" alt="Product Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="product_image" class="form-label">New Product Image:</label>
                                <input type="file" class="form-control" id="product_image" name="product_image" style="height:10%">
                            </div>
                             <div class="mb-3">
                                <label for="product_unit" class="form-label">Product Unit:</label>
                                <input type="number" class="form-control" name="product_unit" value="<?= $product['product_unit']; ?>">
                            </div>
                            <div class="mb-3">
                               <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                               <label for="product_description" class="form-label">Product Description:</label>
                               <textarea id="editor" name="product_description"><?=$product['product_description'];?></textarea>
                                <script>
                              CKEDITOR.replace('editor');
                            </script>
                                </div>
                                <div class="mb-3">
                                  <label>Product Unit Measure <span class="red">*</span></label>
                                    <select class="form-control "  name="product_unit_measure" id="product_unit_measure" >
                                        <?php if($product['product_unit_measure']== null){ ?>
                                          <option >Select Product Unit Measure</option>
                                       <?php } ?>
                                      <option value = 'ML' <?php if($product['product_unit_measure'] == 'ML'){echo "selected";}?>>ML</option>
                                      <option value = 'KG' <?php if($product['product_unit_measure'] == 'KG'){echo "selected";}?>>KG</option>
                                      
                                    </select>
                                </div>
                            
                            <button type="submit" class="btn btn-primary">Update Product</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
