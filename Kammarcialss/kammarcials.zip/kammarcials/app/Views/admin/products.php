<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>

<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Products Tables</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Products Database</h3>
                    <ul>
                      
                        <li>Products</li>
        <p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/products/add_product'); ?>" class="btn btn-primary">Add Product</a></p>
    </div>
    <!-- <nav>-->
    <!--    <ol class="breadcrumb">-->
    <!--        <li class="breadcrumb-item"><a href="/">Home</a></li>-->
    <!--        <li class="breadcrumb-item">Tables</li>-->
    <!--        <li class="breadcrumb-item active">General</li>-->
    <!--    </ol>-->
    <!--</nav>-->
    <!--</div>-->
  
   <!-- End Page Title -->
   <!--<section class="section">-->
   <!--   <div class="row">-->
   <!--      <div class="col-lg-12">-->
   <!--         <div class="card">-->
   <!--            <div class="card-body">-->
                  <h5 class="card-title">Product Table</h5>
                  <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                        
                  <!-- Default Table -->
                  <!-- Display user data in a DataTable -->
        
        <table id="userTable" class="table">
            <thead>
                <tr>
                    <th style="width:5%;" scope="col">#</th>
                    <th style="width:15%;" scope="col">Product Name</th>
                    <th style="width:15%;" scope="col">Product Price</th>
                    <th style="width:15%;" scope="col">Product Image</th>
                    <th style="width:15%;" scope="col">Product Category</th>
                    <th style="width:10%;" scope="col">Product Unit</th>
                    <th style="width:10%;" scope="col">Product Unit Measure</th>
                    <th style="width:15%;" scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td scope="row"><?= $product['product_id']; ?></td>
                        <td><?= $product['product_name']; ?></td>
                        <td><?= $product['product_price']; ?></td>
                        <td>
                            <?php if (!empty($product['product_image'])): ?>
                                <img src="<?= base_url('public/uploads/products/' . $product['product_image']); ?>" alt="Product Image" class="user-image" width="50" height="50">
                                <?php else: ?>
                <img src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image" class="user-image" width="50" height="50">
                              <?php endif; ?>
                       </td>
                        <?php
                        $db = \Config\Database::connect();
                        $builder = $db->table('categories');
                        $query = $builder->select('category_id, category_name')->where('category_id', $product['product_category_id'])->get();
                        $product_category = $query->getRowArray();
                        ?>
                        <td><?= !empty($product_category) ? $product_category['category_name'] : 'N/A'; ?></td>
                        <td><?= $product['product_unit']; ?></td>
                        <td><?= $product['product_unit_measure']; ?></td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <a href="<?= base_url('admin/products/edit_product/' . $product['product_id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                        <?php /* <a href="<?= base_url('admin/category/delete/' . $product['category_id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this entry?');">Delete</a> */ ?>
                        <a href="#" class="btn btn-sm btn-danger delete-product" data-product-id="<?= $product['product_id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                  <!-- End Default Table Example -->
               </div>
            </div>
         </div>
<!--      </div>-->
<!--   </section>-->
   
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>

<!-- Add this in your HTML file to include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    // Use SweetAlert for category deletion confirmation
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.delete-product').forEach(function (deleteButton) {
            deleteButton.addEventListener('click', function (event) {
                event.preventDefault();

                // Get the category ID from the data attribute
                var productId = this.getAttribute('data-product-id');

                // Show the confirmation popup
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You won\'t be able to revert this!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // If confirmed, redirect to the delete URL
                        window.location.href = '<?= base_url('admin/products/delete/'); ?>' + productId;
                    }
                });
            });
        });
    });
</script>
