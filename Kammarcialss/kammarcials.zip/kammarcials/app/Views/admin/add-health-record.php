<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Add Health Record</h1>
    </div>
    <div class="col-md-6 text-end">
        <p class="breadcrumb-item"><a href="<?= base_url('admin/health-record'); ?>" class="btn btn-primary">Back</a></p>
    </div>
    </div>
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Health Record</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/health-record/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                             <div class="mb-3">
                                <label>Select User:</label>
                                <select class="form-control " name="user_id" id="user_id">
                                  <option value="" disabled selected>Select User</option>
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('users');
                                    $query = $builder->select('id, user_name')->get();
                                    $users = $query->getResultArray();
                                        foreach ($users as $user) { ?>
                                            <option value="<?= $user['id']; ?>"><?= $user['user_name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="blood_name" class="form-label">Blood Name:</label>
                                <input type="text" class="form-control" name="blood_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="report_date" class="form-label">Report Date:</label>
                                <input type="date" class="form-control" name="report_date" required>
                            </div>
                            <div class="mb-3">
                                <label for="document" class="form-label">Document:</label>
                                <input type="file" class="form-control" id="document" name="document">
                            </div>
                           
                             <div class="mb-3">
                                <label for="blood" class="form-label">Blood:</label>
                                <input type="text" class="form-control" name="blood" required>
                            </div>
                            <div class="mb-3">
                                <label for="date_time" class="form-label">Date Time:</label>
                                <input type="datetime-local" class="form-control" name="date_time" required>
                            </div>
                            <div class="mb-3">
                                <label for="type" class="form-label">Type:</label>
                                <select class="form-control" name="type" id="type">
                                      <option value="" disabled selected>Select Type</option>
                                    <option value="Blood">Blood</option>
                                    <option value="Document">Document</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Health Record</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>
