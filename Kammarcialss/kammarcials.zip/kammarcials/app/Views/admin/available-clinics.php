<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>
<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Available Clinics Tables</h1>
    </div>
    <div class="col-md-6 text-end">
        <p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/available-clinics/add_available_clinics'); ?>" class="btn btn-primary">Add Clinic</a></p>
    </div>
     <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Tables</li>
            <li class="breadcrumb-item active">General</li>
        </ol>
    </nav>
    </div>
    

   <!-- End Page Title -->
   <section class="section">
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">Clinic Table</h5>
                  <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                        
                  <!-- Default Table -->
                  <!-- Display user data in a DataTable -->
        <table id="userTable" class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Clinic Name</th>
                    <th scope="col">Clinic Image</th>
                    <th scope="col">Clinic Address</th>
                    <th scope="col">Clinic Monday</th>
                    <th scope="col">Clinic Tuesday</th>
                    <th scope="col">Clinic Wednesday</th>
                    <th scope="col">Clinic Thursday</th>
                    <th scope="col">Clinic Friday</th>
                    <th scope="col">Clinic Saturday</th>
                    <th scope="col">Clinic Sunday</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

                <?php foreach ($available_clinics as $availableclinic): ?>
                    <tr>
                        <th scope="row"><?= $availableclinic['clinic_id']; ?></th>
                        <td><?= $availableclinic['clinic_name']; ?></td>
                        <td>
                            <?php if (!empty($availableclinic['clinic_image'])): ?>
                                <img src="<?= base_url('public/uploads/available_clinics/' . $availableclinic['clinic_image']); ?>" alt="Clinic Image" class="user-image" width="50" height="50">
                                <?php else: ?>
                <img src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image" class="user-image" width="50" height="50">
                              <?php endif; ?>
                        </td>
                        <td><?= $availableclinic['clinic_address']; ?></td>
                        <td><?= $availableclinic['clinic_monday']; ?></td>
                        <td><?= $availableclinic['clinic_tuesday']; ?></td>
                        <td><?= $availableclinic['clinic_wednesday']; ?></td>
                        <td><?= $availableclinic['clinic_thursday']; ?></td>
                        <td><?= $availableclinic['clinic_friday']; ?></td>
                        <td><?= $availableclinic['clinic_saturday']; ?></td>
                        <td><?= $availableclinic['clinic_sunday']; ?></td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <a href="<?= base_url('admin/available-clinics/edit/' . $availableclinic['clinic_id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <a href="<?= base_url('admin/available-clinics/delete/' . $availableclinic['clinic_id']); ?>" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                  <!-- End Default Table Example -->
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>