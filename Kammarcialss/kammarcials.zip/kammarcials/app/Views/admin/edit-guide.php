<!-- edit_user.php -->
<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Edit Guide</h1>
    </div>
    <div class="col-md-6 text-end">
        <p class="breadcrumb-item"><a href="<?= base_url('admin/guide'); ?>" class="btn btn-primary">Back</a></p>
    </div>
</div>
    <!-- End Page Title -->
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Edit Guide</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/guide/update/' . $guide['guide_id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="guide_id" value="<?=$guide['guide_id'];?>">
                            
                            <div class="mb-3">
                                <label for="guide_question" class="form-label">Guide Question:</label>
                                <input type="text" class="form-control" name="guide_question" value="<?= $guide['guide_question']; ?>">
                            </div>
                            <div class="mb3">
                                <label>Select Guide Sub Category <span class="red">*</span></label>
                                <select class="form-control " name="guide_sub_category_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('sub_categories');
                                    $query = $builder->select('id, name')->get();
                                    $guide_sub_categories = $query->getResultArray();
                                    echo '<option value="" disabled>Select Guide Sub Category</option>';
                                   
                                        foreach ($guide_sub_categories as $guide_sub_category) { ?>
                                            <option value="<?= $guide_sub_category['id']; ?>" <?php if ($guide_sub_category['id'] == $guide['guide_sub_category_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $guide_sub_category['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($guide['guide_image']) && file_exists(ROOTPATH . 'public/uploads/guide/' . $guide['guide_image'])): ?>
                                    <img src="<?= base_url('public/uploads/guide/' . $guide['guide_image']); ?>" alt="Guide Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="guide_image" class="form-label">New Guide Image:</label>
                                <input type="file" class="form-control" id="guide_image" name="guide_image">
                            </div>
                             
                            <div class="mb-3">
                               <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                               <label for="guide_answer" class="form-label">Guide Answer:</label>
                               <textarea id="editor" name="guide_answer"><?=$guide['guide_answer'];?></textarea>
                                <script>
                              CKEDITOR.replace('editor');
                            </script>
                                </div>
                            <button type="submit" class="btn btn-primary">Update Guide</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>

