<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
 
<style>
.mycards{
    background:transparent;
    padding:15px 30px 0px;
}
    .grad1{
        background:linear-gradient(to right, #CDDC39, rgb(131 133 44));
    }
    .grad11{
        background:linear-gradient(to right, rgb(246 160 149), rgb(245 114 34))
    }
    .grad2{
        background:linear-gradient(to right, rgb(235, 51, 73), rgb(244, 92, 67));
    }
    .grad3{
        background:linear-gradient(to right, rgb(8, 80, 120), rgb(133, 216, 206));
    }
    .grad4{
        background:linear-gradient(to right, rgb(19, 78, 94), rgb(113, 178, 128));
    }
</style> 
  
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
               
                <!-- Breadcubs Area End Here -->
                <!-- Dashboard summery Start Here -->
              
                    <div class="card mt-5">
                    <div class="card-body">
                    <div class="col-xl-12 col-sm-6 col-12 mt-3 ">
                      <div class="row">
                          <div class="col-lg-10">
                            <h4 class="mb-0">Welcome To Dashboard</h4>
                            <p><?php echo $date = date('m/d/Y h:i:s a', time()); ?></p>
                          </div>
                          <!--<div class="col-lg-2 text-right">-->
                          <!--  <a href=""> <img src="<?php echo base_url(); ?>public/newadmin/img/iconsms.png" style="width:32px; margin-top:15px;"/></a>-->
                          <!--  <a href=""> <img src="<?php echo base_url(); ?>public/newadmin/img/icontimes.png"  style="width:32px; margin-top:15px;"/></a>-->
                          <!--</div>-->
                      </div>
                    </div>
                   </div>
                </div>
                
               
                <!-- Dashboard summery End Here -->
                <div class="card mt-5">
                    <div class="card-body">
                <div class="row mb-4">
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad2">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Users</h5>
                            <h2 class="mb-4 text-white font-weight-bold">550</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad11">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Earning</h5>
                            <h2 class="mb-4 text-white font-weight-bold">$56,00</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3  col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad3">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">All Services Users</h5>
                            <h2 class="mb-4 text-white font-weight-bold">210</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad4">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Services</h5>
                            <h2 class="mb-4 text-white font-weight-bold">10</h2>
                            
                          </div>
                        </div>
                      </div>
                    </div> 
                <div class="row">
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad3">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Users</h5>
                            <h2 class="mb-4 text-white font-weight-bold">932</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad1">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Transaction</h5>
                            <h2 class="mb-4 text-white font-weight-bold">$756,00</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3  col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad4">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">All Services Users</h5>
                            <h2 class="mb-4 text-white font-weight-bold">210</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad2">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Services</h5>
                            <h2 class="mb-4 text-white font-weight-bold">10</h2>
                            
                          </div>
                        </div>
                      </div>
                    </div>    
                
                 </div>
                </div>
<?php include('include/newadmin-footer.php'); ?>                