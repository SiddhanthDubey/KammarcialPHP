<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>

<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>User's Database</h3>
                    <ul>
                        <li>
                            <a>Users</a>
                        </li>
               <p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/users/add_user'); ?>" class="btn btn-primary">Add User</a></p>                        

                    </ul>
                </div>
                
                <!-- Breadcubs Area End Here -->
                <!-- Student Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>List Name of User</h3>
                            </div>
                           
                        </div>
                        <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                        <div class="table-responsive">
                            <table id="userTable" class="table display data-table text-nowrap">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Country</th>
                                         <th>Wallet</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <th scope="row"><?= $user['id']; ?></th>
                        <td><?= $user['user_name']; ?></td>
                        <td><?= $user['email']; ?></td>
                        <td><?= $user['mobile']; ?></td>
                        <!--<td>-->
                        <!--    <?php if (!empty($user['image'])): ?>-->
                        <!--        <img style="width:32px;" src="<?= base_url('public/uploads/users/' . $user['image']); ?>" alt="User Image">-->
                        <!--        <?php else: ?>-->
                        <!--        <img style="width:32px;" src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image">-->
                        <!--      <?php endif; ?>-->
                        <!--</td>-->
                        <td><?php 
                        $cid = $user['country_id'];
                        $db  = \Config\Database::connect();
                        $builder = $db->table('country');
                        $datac = $builder->where('id', $cid)->get()->getResultArray();
                        if($datac)
                        {
                           echo $datac[0]['name'];   
                        }
                        else
                        {
                           echo 'N/A';   
                        }
                       
                        ?></td>
                        <td><?= $user['wallet']; ?></td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <!--<a href="<?= base_url('admin/users/view/' . $user['id']); ?>" class="btn btn-primary">View</a>-->
                            <a href="<?= base_url('admin/users/edit/' . $user['id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                           <a href="<?= base_url('admin/users/delete/' . $user['id']); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
                               
                            </table>
                        </div>
                    </div>
                </div>
                
            
<?php include('include/newadmin-footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>

<?php /*
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>
<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Users Tables</h1>
    </div>
    <div class="col-md-6 text-end">
        <p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/users/add_user'); ?>" class="btn btn-primary">Add User</a></p>
    </div>
     <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Tables</li>
            <li class="breadcrumb-item active">General</li>
        </ol>
    </nav>
    </div>
    

   <!-- End Page Title -->
   <section class="section">
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">User Table</h5>
                  <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                        
                  <!-- Default Table -->
                  <!-- Display user data in a DataTable -->
        <table id="userTable" class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Company Name</th>
                    <th scope="col">Image</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <th scope="row"><?= $user['id']; ?></th>
                        <td><?= $user['user_name']; ?></td>
                        <td><?= $user['email']; ?></td>
                        <td><?= $user['company_name']; ?></td>
                        <td>
                            <?php if (!empty($user['image'])): ?>
                                <img src="<?= base_url('public/uploads/users/' . $user['image']); ?>" alt="User Image" class="user-image" width="50" height="50">
                                <?php else: ?>
                <img src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image" class="user-image" width="50" height="50">
                              <?php endif; ?>
                        </td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <a href="<?= base_url('admin/users/view/' . $user['id']); ?>" class="btn btn-sm btn-primary">View</a>
                        <?php /*    <a href="<?= base_url('admin/users/edit/' . $user['id']); ?>" class="btn btn-sm btn-primary">Edit</a> */ ?>
                       <?php /*     <a href="<?= base_url('admin/users/delete/' . $user['id']); ?>" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                  <!-- End Default Table Example -->
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script> */ ?>