<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit TVS Scan</h3>
                    
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Edit Progress Workout</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
        <p class="breadcrumb-item"><a href="<?= base_url('admin/tvs_scan'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit TVS Scan</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/tvs_scan/update/' . $tvs_scan_clinic['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$tvs_scan_clinic['id'];?>">
                            
                            <div class="mb-3">
                                <label for="clinic_name" class="form-label">Clinic Name:</label>
                                <input type="text" class="form-control" name="clinic_name" value="<?= $tvs_scan_clinic['clinic_name']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="service_address" class="form-label">Service Address:</label>
                                <input type="text" class="form-control" name="service_address" value="<?= $tvs_scan_clinic['service_address']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="clinic_monday" class="form-label">Clinic Monday:</label>
                                <input type="text" class="form-control" name="clinic_monday" value="<?= $tvs_scan_clinic['clinic_monday']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_tuesday" class="form-label">Clinic Tuesday:</label>
                                <input type="text" class="form-control" name="clinic_tuesday" value="<?= $tvs_scan_clinic['clinic_tuesday']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_wednesday" class="form-label">Clinic Wednesday:</label>
                                <input type="text" class="form-control" name="clinic_wednesday" value="<?= $tvs_scan_clinic['clinic_wednesday']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_thursday" class="form-label">Clinic Thursday:</label>
                                <input type="text" class="form-control" name="clinic_thursday" value="<?= $tvs_scan_clinic['clinic_thursday']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_friday" class="form-label">Clinic Friday:</label>
                                <input type="text" class="form-control" name="clinic_friday" value="<?= $tvs_scan_clinic['clinic_friday']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_saturday" class="form-label">Clinic Saturday:</label>
                                <input type="text" class="form-control" name="clinic_saturday" value="<?= $tvs_scan_clinic['clinic_saturday']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="clinic_sunday" class="form-label">Clinic Sunday:</label>
                                <input type="text" class="form-control" name="clinic_sunday" value="<?= $tvs_scan_clinic['clinic_sunday']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($tvs_scan_clinic['clinic_image']) && file_exists(ROOTPATH . 'public/uploads/tvs_scan/' . $tvs_scan_clinic['clinic_image'])): ?>
                                    <img src="<?= base_url('public/uploads/tvs_scan/' . $tvs_scan_clinic['clinic_image']); ?>" alt="Doctor Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="clinic_image" class="form-label">New  Image:</label>
                                <input type="file" class="form-control" id="clinic_image" name="clinic_image" style=" height: 11%;">
                            </div>
                            
                            
                            
                            <button type="submit" class="btn btn-primary" style=" width: 14%;">Update TVS Scan</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

