<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Health Record Database</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Health Record</li>
<p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/health-record/add-health-record'); ?>" class="btn btn-primary">Add Health Record</a></p>
       
                    </ul>
                </div>
                
                <!-- Breadcubs Area End Here -->
                <!-- Student Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>List Name of  Health Record</h3>
                            </div>
                           
                        </div>
                        <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                        <div class="table-responsive">
                            <table id="userTable" class="table display data-table text-nowrap">
                                 <thead>
                <tr>
                    <th>#</th>
                    <th>User Name</th>
                    <th>Blood Name</th>
                    <th>Report Date</th>
                    <th>Blood</th>
                    <th>Type</th>
                    <th>document</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($health_record as $health_record_in): ?>
                    <tr>
                        <td scope="row"><?= $health_record_in['id']; ?></td>
                        <?php
                        $db = \Config\Database::connect();
                        $builder = $db->table('users');
                        $query = $builder->select('id, user_name')->where('id', $health_record_in['user_id'])->get();
                        $health_record_user = $query->getRowArray();
                        ?>
                        <td><?= !empty($health_record_user) ? $health_record_user['user_name'] : 'N/A'; ?></td>
                        <td><?= $health_record_in['blood_name']; ?></td>
                        <td><?= $health_record_in['blood']; ?></td>
                        <td><?= $health_record_in['date_time']; ?></td>
                        <td><?= $health_record_in['type']; ?></td>
                        <td>
                            <?php if (!empty($health_record_in['document'])): ?>
                        <a target="_blank" href="<?= base_url('public/uploads/health_report/' . $health_record_in['document']); ?>"><?= $health_record_in['document']; ?></a>
                        <?php else: ?>
                <img src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image" class="user-image" width="50" height="50">
                              <?php endif; ?>
                        </td>
                        
                        
                        <td>
                           
                            <a href="<?= base_url('admin/health-record/edit-health-record/' . $health_record_in['id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                     <a href="<?= base_url('admin/health-record/delete/' . $health_record_in['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this entry?');">Delete</a> 
                    <?php /*    <a href="#" class="btn btn-sm btn-danger delete-health-record" data-id="<?= $health_record_in['id']; ?>">Delete</a> */ ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
                               
                            </table>
                        </div>
                    </div>
                </div>

<?php include('include/newadmin-footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>

<!-- Add this in your HTML file to include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    // Use SweetAlert for category deletion confirmation
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.delete-health-record').forEach(function (deleteButton) {
            deleteButton.addEventListener('click', function (event) {
                event.preventDefault();

                // Get the category ID from the data attribute
                var healthrecordId = this.getAttribute('data-health-record-id');

                // Show the confirmation popup
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You won\'t be able to revert this!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // If confirmed, redirect to the delete URL
                        window.location.href = '<?= base_url('admin/health-record/delete/'); ?>' + healthrecordId;
                    }
                });
            });
        });
    });
</script>






