<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit User</h3> 
        <p class="breadcrumb-item"><a href="<?= base_url('admin/users'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit User</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/users/update/' . $user['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$user['id'];?>">
                            
                            <div class="mb-3">
                                <label for="user_name" class="form-label">User Name:</label>
                                <input type="text" class="form-control" name="user_name" value="<?= $user['user_name']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" name="email" value="<?= $user['email']; ?>">
                            </div>
                            
                             
                            <div class="mb-3">
                                <label for="email" class="form-label">Mobile:</label>
                                <input type="text" class="form-control" name="mobile" value="<?= $user['mobile']; ?>">
                            </div>
                            
                            <div class="mb3">
                                <label>Country: <span class="red">*</span></label>
                                <select class="form-control " name="country_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('country');
                                    $query = $builder->select('id, name')->get();
                                    $results = $query->getResultArray();
                                    echo '<option value="" disabled>Select country</option>';
                                   
                                        foreach ($results as $user23) { ?>
                                            <option value="<?= $user23['id']; ?>" <?php if ($user23['id'] == $user['country_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $user23['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            
                            <!-- <div class="mb-3">-->
                            <!--    <label for="email" class="form-label">Password:</label>-->
                            <!--    <input type="password" class="form-control" name="password" value="<?= $user['password']; ?>">-->
                            <!--</div>-->
                            
                            <!--<div class="mb-3">-->
                            <!--    <label for="company_name" class="form-label">Age:</label>-->
                            <!--    <input type="text" class="form-control" name="age" value="<?= $user['age']; ?>">-->
                            <!--</div>-->
                            
                            <!--<div class="mb-3">-->
                            <!--    <label for="existing_image" class="form-label">Existing Image:</label>-->
                            <!--    <?php if (!empty($user['image']) && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])): ?>-->
                            <!--        <img src="<?= base_url('public/uploads/users/' . $user['image']); ?>" alt="User Image" width="150" height="150">-->
                            <!--    <?php else: ?>-->
                            <!--        <p>No existing image</p>-->
                            <!--    <?php endif; ?>-->
                            <!--</div>-->

                            <!--<div class="mb-3">-->
                            <!--    <label for="image" class="form-label">New Profile Image:</label>-->
                            <!--    <input type="file" class="form-control" id="image" name="image" style="height:10%;">-->
                            <!--</div>-->
                            <br>
                            <button type="submit" class="btn btn-primary">Update User</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

