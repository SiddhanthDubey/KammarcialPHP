<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
   

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
            <div class="dashboard-content-one">
                
                 <div class="row">
                      <!-- Breadcubs Area End Here -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-sx-12 ">
                        <div class="card mt-5"><h4>User Dashboard</h4></div>
                        </div>
                        <!-- Breadcubs Area Start Here -->
                         <!-- Dashboard Content Start Here -->
                        <div class="col-lg-6 col-md-6 col-sm-6 col-sx-6 ">
                             
                    <div class="card">
                        
                        <div class="card-header bg-white"> <h4 class="mb-0">Number Of Users </h4></div>
                    <div class="card-body">
                        
                     

                    
                      
                       <canvas id="canvas" style="width:100%;max-width:100%"></canvas>
                       
                      </div>
                
                   </div>
                   </div>
                    <div class="col-lg-6 col-md-6">
                             
                    <div class="card">
                        
                        <div class="card-header bg-white"> <h4 class="mb-0">User Growth Rate</h4></div>
                    <div class="card-body">
                        
                     <canvas id="myChart1" style="width:100%;max-width:100%"></canvas>

                       
                      </div>
                
                   </div>
                   </div>
                   
                   <div class="col-lg-12 col-md-12">
                             
                    <div class="card">
                        
                                       <p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/users/add_user'); ?>" class="btn btn-primary">Add User</a></p>                        

                        
                        <div class="card-header bg-white"> <h4 class="mb-0">User List</h4></div>
                    <div class="card-body">
                        
                                                <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                        <table id="myTable" class="table table-bordered">
                            <thead>
                                <tr>
                                        <th>No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Country</th>
                                         <th>Wallet</th>
                                        <th>Action</th>
                                        
                                </tr>
                                <tbody>
                                    
                                     
                                   <?php foreach ($users as $user): ?>
                    <tr>
                        <th scope="row"><?= $user['id']; ?></th>
                        <td><?= $user['user_name']; ?></td>
                        <td><?= $user['email']; ?></td>
                        <td><?= $user['mobile']; ?></td>
                        <!--<td>-->
                        <!--    <?php if (!empty($user['image'])): ?>-->
                        <!--        <img style="width:32px;" src="<?= base_url('public/uploads/users/' . $user['image']); ?>" alt="User Image">-->
                        <!--        <?php else: ?>-->
                        <!--        <img style="width:32px;" src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image">-->
                        <!--      <?php endif; ?>-->
                        <!--</td>-->
                        <td><?php 
                        $cid = $user['country_id'];
                        $db  = \Config\Database::connect();
                        $builder = $db->table('country');
                        $datac = $builder->where('id', $cid)->get()->getResultArray();
                        if($datac)
                        {
                           echo $datac[0]['name'];   
                        }
                        else
                        {
                           echo 'N/A';   
                        }
                       
                        ?></td>
                        <td><?= $user['wallet']; ?></td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <!--<a href="<?= base_url('admin/users/view/' . $user['id']); ?>" class="btn btn-primary">View</a>-->
                            <a href="<?= base_url('admin/users/edit/' . $user['id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                           <a href="<?= base_url('admin/users/delete/' . $user['id']); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                                </tbody>
                            </thead>
                        </table>
                     
                       
                      </div>
                
                   </div>
                   </div>
                   
                   <!-- Dashboard Content End Here -->
                   
                   </div>
                
            
              <?php 
              
       $db = \Config\Database::connect();
       $currentYear = date("Y");
       $monthDates = array();

       for ($month = 1; $month <= 12; $month++) {
        // Generate the first day of the month
        $startDate = date("Y-m-01", strtotime("$currentYear-$month-01"));
        
        // Generate the last day of the month
        $endDate = date("Y-m-t", strtotime("$currentYear-$month-01"));
        
         $result = $db->query("SELECT  id FROM users WHERE `created_at` BETWEEN '$startDate' AND  '$endDate' ")->getResultArray();
    
    
        // Add the start and end dates to the array
        $monthDates[] = array("start_date" => $startDate, "end_date" => $endDate, "count" =>  count($result));
    }

       $countString = '"' . implode('", "', array_column($monthDates, 'count')) . '"';

// Print the comma-separated count string
//echo $countString;

              ?>  
  <script>
var barChartData = {
  labels: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  
  datasets: [
    {
      label: "Users",
      backgroundColor: "#b27bff",
      borderColor: "blue",
      borderWidth: 1,
    //   data: [30, 50, 60, 70, 32, 40, 41, 44, 35, 55, 42, 30]
    data: [<?=$countString?>]
    }
    
    
    
  ]
};

var chartOptions = {
  responsive: true,
  legend: {
    position: "top"
  },
  title: {
    display: true,
    text: "Chart.js Bar Chart"
  },
  scales: {
      yAxes: [{ticks: {min: 0, max:100}}],
    }
  
}

window.onload = function() {
  var ctx = document.getElementById("canvas").getContext("2d");
  window.myBar = new Chart(ctx, {
    type: "bar",
    data: barChartData,
    options: chartOptions
  });
};

</script>

<script>
const xValues1 = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
// const yValues1 = [20,50,30,70,55,70,60,89,70,80,50,73];
const yValues1 = [<?=$countString?>];

new Chart("myChart1", {
  type: "line",
  data: {
    labels: xValues1,
    datasets: [{
      fill: false,
      lineTension: 0,
      backgroundColor: "blue",
      borderColor: "#b27bff",
      data: yValues1
    }]
  },
  options: {
    legend: {display: false},
    scales: {
      yAxes: [{ticks: {min: 0, max:100}}],
    }
  }
});
</script>

           
<?php include('include/newadmin-footer.php'); ?>            
