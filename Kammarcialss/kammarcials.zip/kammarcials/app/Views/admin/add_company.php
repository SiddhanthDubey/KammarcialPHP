<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />

<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBQDSvBppnW59UJ0ALOlGV5aMiJl6bgk70&callback=initMap&sensor=false&libraries=places"></script>

    <script>


  function initialize() {
        var address = (document.getElementById('pac-input'));
        var autocomplete = new google.maps.places.Autocomplete(address);
        autocomplete.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete, 'place_changed', function() {
            var place = autocomplete.getPlace();
            if (!place.geometry) {
                return;
            }

        var address = '';
        if (place.address_components) {
            address = [
                (place.address_components[0] && place.address_components[0].short_name || ''),
                (place.address_components[1] && place.address_components[1].short_name || ''),
                (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude').value = place.geometry.location.lat();
        document.getElementById('longnitude').value = place.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize);
   
   function initialize1() {
        var address1 = (document.getElementById('pac-input1'));
        var autocomplete1 = new google.maps.places.Autocomplete(address1);
        autocomplete1.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete1, 'place_changed', function() {
            var place1 = autocomplete1.getPlace();
            if (!place1.geometry) {
                return;
            }

        var address1 = '';
        if (place1.address_components) {
            address1 = [
                (place1.address_components[0] && place1.address_components[0].short_name || ''),
                (place1.address_components[1] && place1.address_components[1].short_name || ''),
                (place1.address_components[2] && place1.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude1').value = place1.geometry.location.lat();
        document.getElementById('longnitude1').value = place1.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize1);
   
   function initialize2() {
        var address2 = (document.getElementById('pac-input2'));
        var autocomplete2 = new google.maps.places.Autocomplete(address2);
        autocomplete2.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete2, 'place_changed', function() {
            var place2 = autocomplete2.getPlace();
            if (!place2.geometry) {
                return;
            }

        var address2 = '';
        if (place2.address_components) {
            address2 = [
                (place2.address_components[0] && place2.address_components[0].short_name || ''),
                (place2.address_components[1] && place2.address_components[1].short_name || ''),
                (place2.address_components[2] && place2.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude2').value = place2.geometry.location.lat();
        document.getElementById('longnitude2').value = place2.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize2);
   
   function initialize3() {
        var address3 = (document.getElementById('pac-input3'));
        var autocomplete3 = new google.maps.places.Autocomplete(address3);
        autocomplete3.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete3, 'place_changed', function() {
            var place3 = autocomplete3.getPlace();
            if (!place3.geometry) {
                return;
            }

        var address3 = '';
        if (place3.address_components) {
            address3 = [
                (place3.address_components[0] && place3.address_components[0].short_name || ''),
                (place3.address_components[1] && place3.address_components[1].short_name || ''),
                (place3.address_components[2] && place3.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude3').value = place3.geometry.location.lat();
        document.getElementById('longnitude3').value = place3.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize3);
    </script>



<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Add User</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
 <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add Company <span class="breadcrumb-item" style="float:right"><a href="<?= base_url('admin/company'); ?>" class="btn btn-primary">Back</a></span></h3>
        
    </div>
    <!--</div>-->
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
      <div class="col-lg-12">
       <div class="card">
                <div class="card-body">
                        <h5 class="card-title">Add Company</h5>
                        
                        
                        
               <?php 
        //  $company_name = $this->request->getVar('company_name');
       // $company_code = $this->request->getVar('company_code');
       // $company_mail = $this->request->getVar('company_mail');
       // $expertise_service_id = $this->request->getVar('expertise_service_id'); 
       // $company_number = $this->request->getVar('company_number'); 
       // $language = $this->request->getVar('language'); 
      //  $bio = $this->request->getVar('bio'); 
        
       // $company_address_1 = $this->request->getVar('company_address_1');
       // $company_address_1_lat = $this->request->getVar('company_address_1_lat');
       // $company_address_1_lon = $this->request->getVar('company_address_1_lon');
        
       // $company_address_2 = $this->request->getVar('company_address_2');
       // $company_address_2_lat = $this->request->getVar('company_address_2_lat');
       // $company_address_2_lon = $this->request->getVar('company_address_2_lon');
        
        
      //  $company_address_3 = $this->request->getVar('company_address_3');
      //  $company_address_3_lat = $this->request->getVar('company_address_3_lat');
      //  $company_address_3_lon = $this->request->getVar('company_address_3_lon');
        ?>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/company/save'); ?>" enctype="multipart/form-data">
                            <div class="row">
                            <!-- Add your form fields for new user data -->
                            <div class="col-md-6 mb-3">
                                <label for="company_name" class="form-label">Company Name:</label>
                                <input type="text" class="form-control" name="company_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="company_code" class="form-label">Company Code:</label>
                                <input type="text" class="form-control" name="company_code" required>
                            </div>
                             <div class="col-md-6 mb-3">
                                <label for="company_number" class="form-label">Company Number:</label>
                                <input type="text" class="form-control" name="company_number" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Company Email:</label>
                                <input type="email" class="form-control" name="company_mail" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="language" class="form-label">Year of Expertise:</label>
                                <input type="text" class="form-control" name="year_of_expertise" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">expertise_service_id:</label>
                                <!--<input type="text" class="form-control" name="expertise_service_id" required>-->
                                
                                <select class="form-control basic-multiple" name="expertise_service_id[]" multiple="multiple" >
                                     <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('services');
                                    $query = $builder->select('ser_id, service_name')->get();
                                    $results = $query->getResultArray();
                                  
                                   
                                      foreach ($results as $result) { ?>
                                            <option value="<?= $result['ser_id']; ?>"><?= $result['service_name']; ?></option>
                                        <?php } ?>
                            </select>

                            </div>
                            
                             <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Mobile:</label>
                                <input type="mobile" class="form-control" name="mobile" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="password" class="form-label">Pin:</label>
                                <input type="password" class="form-control" name="password" required>
                            </div>
                            
                            
                            <div class="col-md-6 mb-3">
                                <label for="language" class="form-label">Language:</label>
                                <input type="text" class="form-control" name="language" required>
                            </div>
                            
                            
                          <!--   <div class="col-md-6 mb-3">-->
                          <!--      <label for="mobile" class="form-label">Address</label>-->
                          <!--       <input id="pac-input"  name="address" required="" class="form-control" placeholder="" type="text" >-->
                          <!--<input name="lat1" id="latitude" required="" class="form-control" placeholder="" type="hidden" value="">-->
                          <!--<input name="lon1" id="longnitude" required="" class="form-control" placeholder="" type="hidden" > -->
                          <!--  </div>-->
                          
                            
                            <!-- Additional fields based on UserModel -->
                            <div class="col-md-6 mb-3">
                                <label for="mobile" class="form-label">Company_address_1:</label>
                                 <input id="pac-input1"  name="company_address_1" required="" class="form-control" placeholder="" type="text" >
                          <input name="company_address_1_lat" id="latitude1" required="" class="form-control" placeholder="" type="hidden" value="">
                          <input name="company_address_1_lon" id="longnitude1" required="" class="form-control" placeholder="" type="hidden" > 
                            </div>
                            
                             <div class="col-md-6 mb-3">
                                <label for="mobile" class="form-label">Company_address_2:</label>
                                  <input id="pac-input2" name="company_address_2" required="" class="form-control" placeholder="" type="text">
                          <input name="company_address_2_lat" id="latitude2"  required="" class="form-control" placeholder="" type="hidden">
                          <input name="company_address_2_lon" id="longnitude2" required="" class="form-control" placeholder="" type="hidden">
                               
                            </div>
                            
                             <div class="col-md-6 mb-3">
                                <label for="mobile" class="form-label">Company_address_3:</label>
                                   <input id="pac-input3" name="company_address_3" required="" class="form-control" placeholder="" type="text">
                          <input name="company_address_3_lat" id="latitude3"  required="" class="form-control" placeholder="" type="hidden">
                          <input name="company_address_3_lon" id="longnitude3" required="" class="form-control" placeholder="" type="hidden">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="bio" class="form-label">Bio:</label>
                                <textarea type="text" class="form-control" name="bio"></textarea>
                            </div>

                            

                            <!-- End of additional fields -->

                            <div class="col-md-6 mb-3">
                                <label for="image" class="form-label">Profile Image:</label>
                                <input type="file" class="form-control" id="image" name="image" required>
                            </div>
                            
                             <div class="col-md-6 mb-3">
                                <label for="image" class="form-label">Upload Company Licence:</label>
                                <input type="file" class="form-control" id="image" name="upload_company_document" required>
                            </div>
                            
                            <div class="col-md-12 mb-3">
                            <button type="submit" onclick="getSelectedIDs()" class="btn btn-primary">Add Company</button>
                            </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>$(document).ready(function() {
    $('.basic-multiple').select2();
});
</script>
