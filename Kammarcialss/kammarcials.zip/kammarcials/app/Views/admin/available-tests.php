<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>
<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Available Tests Tables</h1>
    </div>
    <div class="col-md-6 text-end">
        <p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/available-tests/add_available_tests'); ?>" class="btn btn-primary">Add Test</a></p>
    </div>
     <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Tables</li>
            <li class="breadcrumb-item active">General</li>
        </ol>
    </nav>
    </div>
    

   <!-- End Page Title -->
   <section class="section">
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">Tests Table</h5>
                  <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                        
                  <!-- Default Table -->
                  <!-- Display user data in a DataTable -->
        <table id="userTable" class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Test Name</th>
                    <th scope="col">Test Image</th>
                    <th scope="col">Test Status</th>
                    <th scope="col">Test Tags</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

                <?php foreach ($available_tests as $available_test): ?>
                    <tr>
                        <th scope="row"><?= $available_test['test_id']; ?></th>
                        <td><?= $available_test['test_name']; ?></td>
                        <td>
                            <?php if (!empty($available_test['test_image'])): ?>
                                <img src="<?= base_url('public/uploads/available_test/' . $available_test['test_image']); ?>" alt="Test Image" class="user-image" width="50" height="50">
                                <?php else: ?>
                <img src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image" class="user-image" width="50" height="50">
                              <?php endif; ?>
                        </td>
                        <td><?= $available_test['test_status']; ?></td>
                        <td><?= $available_test['test_tags']; ?></td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <a href="<?= base_url('admin/available-tests/edit/' . $available_test['test_id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <a href="<?= base_url('admin/available-tests/delete/' . $available_test['test_id']); ?>" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                  <!-- End Default Table Example -->
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>