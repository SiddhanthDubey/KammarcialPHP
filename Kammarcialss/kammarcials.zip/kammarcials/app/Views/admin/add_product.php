<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Add Product</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add Product</h3>
        <p class="breadcrumb-item"><a href="<?= base_url('admin/products'); ?>" class="btn btn-primary">Back</a></p>
    </div>
    <!--</div>-->
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Product</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/products/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="product_name" class="form-label">Product Name:</label>
                                <input type="text" class="form-control" name="product_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="product_price" class="form-label">Product Price:</label>
                                <input type="text" class="form-control" name="product_price" required>
                            </div>
                            <div class="mb-3">
                                <label for="product_image" class="form-label">Product Image:</label>
                                <input type="file" class="form-control" id="product_image" name="product_image" style="height:10%">
                            </div>
                            <div class="mb-3">
                                <label>Product Category:</label>
                                <select class="form-control " name="product_category_id" id="product_category_id">
                                  <option value="" disabled selected>Select Product Category</option>
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('categories');
                                    $query = $builder->select('category_id, category_name')->get();
                                    $products = $query->getResultArray();
                                        foreach ($products as $product) { ?>
                                            <option value="<?= $product['category_id']; ?>"><?= $product['category_name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            
                            <?php /*
                            <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('main_categories');
                                    $query = $builder->select('id, name')->get();
                                    $main_categories = $query->getResultArray();
                                    ?>
                                    
                            <div class="form-group">
                                <label for="main_category_id">Main Category:</label>
                                <select class="form-control" name="main_category_id" placeholder="Select Main Category" required>
                                      <?php foreach ($main_categories as $main_category) { ?>
                                      <option><?php echo $main_category->name; ?></option>
                                 <?php } ?>
                              </select>
                             </div>
                             */ ?>
                             <div class="mb-3">
                                <label for="product_unit" class="form-label">Product Unit:</label>
                                <input type="text" class="form-control" name="product_unit" required>
                            </div>
                            <div class="mb-3">
                                <label for="product_unit_measure" class="form-label">Product Unit Measure:</label>
                                <select class="form-control" name="product_unit_measure" id="product_unit_measure">
                                      <option value="" disabled selected>Select Product Unit Measure</option>
                                    <option value="ML">ML</option>
                                    <option value="KG">KG</option>
                                </select>
                            </div>
                            <!-- <div class="mb-3">-->
                            <!--    <label for="description" class="form-label">Description:</label>-->
                            <!--    <textarea class="form-control" id="description" name="description"></textarea>-->
                            <!--</div>-->
                            <div class="mb-3">
                           <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                           <label for="product_description" class="form-label">Product Description:</label>
                           <textarea id="editor" name="product_description"></textarea>
                            <script>
                              CKEDITOR.replace('editor');
                            </script>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Product</button>
<!--                        </form>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>