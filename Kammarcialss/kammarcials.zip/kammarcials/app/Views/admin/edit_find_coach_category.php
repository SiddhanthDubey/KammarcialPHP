<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Find Category Coach</h3>
                   
        <p class="breadcrumb-item"><a href="<?= base_url('admin/find_coach_category'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Update Find Category Coach</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/find_coach_category/update/' . $sonography_ultrasounds['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                           <input type="hidden"  class="form-control" name="id" value="<?=$sonography_ultrasounds['id'];?>">
                           
                           
                           
                          
                           
                            <div class="mb-3">
                                <label for="title" class="form-label">Title:</label>
                                <input type="text" class="form-control" name="name" value="<?= $sonography_ultrasounds['name']; ?>">
                            </div>
                            
                           
                            
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($sonography_ultrasounds['image']) && file_exists(ROOTPATH . 'public/uploads/expert_consultations/' . $sonography_ultrasounds['image'])): ?>
                                    <img src="<?= base_url('public/uploads/expert_consultations/' . $sonography_ultrasounds['image']); ?>" alt="Product Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="product_image" class="form-label">New Image:</label>
                                <input type="file" class="form-control" id="image" name="image" style="height:10%">
                            </div>
                            
                            
                            
                            <button type="submit" class="btn btn-primary" style="width:180px;">Update Find Category Coach</button>
                        </form>

<?php include('include/newadmin-footer.php'); ?>
