<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>

 <script type="text/javascript" src="https://cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>



<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Add User</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
 <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Complain List</h3>
        
    </div>
    <!--</div>-->
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
      <div class="col-lg-12">
       <div class="card">
                <div class="card-body">
                        <h5 class="card-title">Complain List</h5>
                        <div class="table-responsive">
                       <table id="userTable" class="table">
                           <thead>
                               <tr>
                                   <th>Sr No.</th> 
                                   <th>User Name</th>
                                   <th>Email</th>
                                   <th>Mobile</th>
                                   <th>Complain Message</th>
                                   <th>DateTime</th>
                               </tr>
                           </thead> 
                           <tbody>
                              <?php 
                              $db = \Config\Database::connect();
                              $categoryList = $db->query("select * from complain ")->getResultArray();
            
                                  $i=1;
                                 foreach ($categoryList as $val) {
                                     $uid = $val['user_id'];
                                     $udetail = $db->query("SELECT * FROM `users` WHERE `id` = '$uid' ")->getResultArray();
                                     $uname = $udetail[0]['user_name'];
                                     $email = $udetail[0]['email'];
                                     $mobile = $udetail[0]['mobile'];
                
                              ?>
                              
                               <tr>
                                   
                                   <td><?=$i++;?></td>
                                   <td><?=$uname;?></td>
                                   <td><?=$email;?></td>
                                   <td><?=$mobile;?></td>
                                   <td><?=$val['message']?></td>
                                   <td><?=$val['date_time']?></td>
                               </tr>
                               <?php } ?>
                           </tbody>
                       </table>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>
