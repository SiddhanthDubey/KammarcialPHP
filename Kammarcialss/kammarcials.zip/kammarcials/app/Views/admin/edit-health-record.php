<!-- edit_user.php -->
<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Edit Health Record</h1>
    </div>
    <div class="col-md-6 text-end">
        <p class="breadcrumb-item"><a href="<?= base_url('admin/health-record'); ?>" class="btn btn-primary">Back</a></p>
    </div>
</div>
    <!-- End Page Title -->
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Edit Health Record</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/health-record/update/' . $health_record['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$health_record['id'];?>">
                            <div class="mb3">
                                <label>Select User <span class="red">*</span></label>
                                <select class="form-control " name="user_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('users');
                                    $query = $builder->select('id, name')->get();
                                    $health_record_users = $query->getResultArray();
                                    echo '<option value="" disabled>Select User</option>';
                                   
                                        foreach ($health_record_users as $health_record_user) { ?>
                                            <option value="<?= $health_record_user['id']; ?>" <?php if ($health_record_user['id'] == $health_record['user_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $health_record_user['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="blood_name" class="form-label">Blood Name:</label>
                                <input type="text" class="form-control" name="blood_name" value="<?= $health_record['blood_name']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="report_date" class="form-label">Report Date:</label>
                                <input type="date" class="form-control" name="report_date" value="<?= $health_record['report_date']; ?>">
                            </div>
                             <div class="mb-3">
                                <label for="blood" class="form-label">Blood:</label>
                                <input type="text" class="form-control" name="blood" value="<?= $health_record['blood']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="date_time" class="form-label">Date Time:</label>
                                <input type="datetime-local" class="form-control" name="date_time" value="<?= $health_record['date_time']; ?>">
                            </div>
                                <div class="mb-3">
                                  <label>Type <span class="red">*</span></label>
                                    <select class="form-control "  name="type" id="type" >
                                        <?php if($health_record['type']== null){ ?>
                                          <option >Select Type</option>
                                       <?php } ?>
                                      <option value = 'Blood' <?php if($health_record['type'] == 'Blood'){echo "selected";}?>>Blood</option>
                                      <option value = 'Document' <?php if($health_record['type'] == 'Document'){echo "selected";}?>>Document</option>
                                      
                                    </select>
                                </div>
                                 <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($health_record['document']) && file_exists(ROOTPATH . 'public/uploads/health_report/' . $health_record['document'])): ?>
                                    <img src="<?= base_url('public/uploads/health_report/' . $health_record['document']); ?>" alt="Document" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing Document</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="document" class="form-label">New Document:</label>
                                <input type="file" class="form-control" id="document" name="document">
                            </div>
                            <button type="submit" class="btn btn-primary">Update Health Record</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>

