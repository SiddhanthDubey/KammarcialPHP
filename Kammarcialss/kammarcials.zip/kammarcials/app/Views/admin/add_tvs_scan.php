<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add TVS Scan</h3>
                   
    <p class="breadcrumb-item"><a href="<?= base_url('admin/tvs_scan'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Add TVS Scan</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/tvs_scan/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="clinic_name" class="form-label">Clinic Name:</label>
                                <input type="text" class="form-control" name="clinic_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="service_address" class="form-label">Service Address:</label>
                                <input type="text" class="form-control" name="service_address" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_monday" class="form-label">Clinic Monday:</label>
                                <input type="text" class="form-control" name="clinic_monday" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_tuesday" class="form-label">Clinic Tuesday:</label>
                                <input type="text" class="form-control" name="clinic_tuesday" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_wednesday" class="form-label">Clinic Wednesday:</label>
                                <input type="text" class="form-control" name="clinic_wednesday" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_thursday" class="form-label">Clinic Thursday:</label>
                                <input type="text" class="form-control" name="clinic_thursday" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_friday" class="form-label">clinic Friday:</label>
                                <input type="text" class="form-control" name="clinic_friday" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_saturday" class="form-label">Clinic Saturday:</label>
                                <input type="text" class="form-control" name="clinic_saturday" required>
                            </div>
                            <div class="mb-3">
                                <label for="clinic_sunday" class="form-label">Clinic Sunday:</label>
                                <input type="text" class="form-control" name="clinic_sunday" required>
                            </div>
                            <div class="mb-3">
                                <label for="consultan_fees" class="form-label">consultan_fees:</label>
                                <input type="text" class="form-control" name="consultan_fees" required>
                            </div>
                             <div class="mb-3">
                                <label for="clinic_image" class="form-label">Clinic Image:</label>
                                <input type="file" class="form-control" id="clinic_image" name="clinic_image" required style="    height: 10%;">
                            </div>
                            
                            
                            
                            <button type="submit" style="width: 12%;" class="btn btn-primary">Add TVS Scan</button>
                        </form>


<?php include('include/newadmin-footer.php'); ?>



