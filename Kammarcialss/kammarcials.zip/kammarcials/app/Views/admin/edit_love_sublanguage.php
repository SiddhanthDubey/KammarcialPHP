<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Love Sub Language</h3>
                    
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Edit Progress Workout</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
        <p class="breadcrumb-item"><a href="<?= base_url('admin/love_sublanguage'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit Love Sub Language</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/love_sublanguage/update/' . $love_sublanguage['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$love_sublanguage['id'];?>">
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" class="form-control" name="name" value="<?= $love_sublanguage['name']; ?>">
                            </div>
                             <div class="mb3">
                                <label>Select Love Language <span class="red">*</span></label>
                                <select class="form-control " name="love_language_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('love_language');
                                    $query = $builder->select('id, name')->get();
                                    $love_language = $query->getResultArray();
                                    echo '<option value="" disabled>Select Love Language</option>';
                                   
                                        foreach ($love_language as $love_language_in) { ?>
                                            <option value="<?= $love_language_in['id']; ?>" <?php if ($love_language_in['id'] == $love_sublanguage['love_language_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $love_language_in['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="test_status" class="form-label">Status:</label>
                                <select class="form-control" name="status">
                                    <option value="Active" <?= ($love_sublanguage['status'] == 'Active') ? 'selected' : ''; ?>>Active</option>
                                    <option value="Deactive" <?= ($love_sublanguage['status'] == 'Deactive') ? 'selected' : ''; ?>>Deactive</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($love_sublanguage['image']) && file_exists(ROOTPATH . 'public/uploads/love_language/' . $love_sublanguage['image'])): ?>
                                    <img src="<?= base_url('public/uploads/love_language/' . $love_sublanguage['image']); ?>" alt="Doctor Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="image" class="form-label">New  Image:</label>
                                <input type="file" class="form-control" id="image" name="image" style=" height: 11%;">
                            </div>
                             <div class="mb-3">
                               <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                               <label for="description" class="form-label">Description:</label>
                               <textarea id="editor" name="description"><?=$love_sublanguage['description'];?></textarea>
                                <script>
                              CKEDITOR.replace('editor');
                            </script>
                            
                            <button type="submit" class="btn btn-primary" style=" width: 16%;">Update Love Sub Language</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

