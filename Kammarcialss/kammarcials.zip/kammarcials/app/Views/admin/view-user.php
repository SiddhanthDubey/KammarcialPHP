<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>View User</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>View User</h3>
                    <!--<ul>-->
                    <!--    <li>-->
                    <!--        <a href="index.html">Home</a>-->
                    <!--    </li>-->
                    <!--    <li>Lab</li>-->
                        
        <p class="breadcrumb-item"><a href="<?= base_url('admin/users'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">View User</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form>
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$user['id'];?>">
                            
                            <div class="mb-3">
                                <label  class="form-label">User Name:</label>
                                <?php echo $user['user_name']; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email:</label>
                                <?php echo $user['email']; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="company_name" class="form-label">Mobile:</label>
                                <?php echo $user['mobile']; ?>
                            </div>
                            
                            
                            
                        </form>
                    </div>
                </div>
            </div>
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

