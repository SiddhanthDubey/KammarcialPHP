<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Add Guide</h1>
    </div>
    <div class="col-md-6 text-end">
        <p class="breadcrumb-item"><a href="<?= base_url('admin/guide'); ?>" class="btn btn-primary">Back</a></p>
    </div>
    </div>
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Guide</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/guide/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="guide_question" class="form-label">Guide Question:</label>
                                <input type="text" class="form-control" name="guide_question" required>
                            </div>
                            <div class="mb-3">
                                <label for="guide_image" class="form-label">Guide Image:</label>
                                <input type="file" class="form-control" id="guide_image" name="guide_image">
                            </div>
                            <div class="mb-3">
                                <label>Guide Sub Category:</label>
                                <select class="form-control " name="guide_sub_category_id" id="guide_sub_category_id">
                                  <option value="" disabled selected>Select Guide Sub Category</option>
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('sub_categories');
                                    $query = $builder->select('id, name')->get();
                                    $guides = $query->getResultArray();
                                        foreach ($guides as $guide) { ?>
                                            <option value="<?= $guide['id']; ?>"><?= $guide['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                          <div class="mb-3">
                           <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                           <label for="guide_answer" class="form-label">Guide Answer:</label>
                           <textarea id="editor" name="guide_answer"></textarea>
                            <script>
                              CKEDITOR.replace('editor');
                            </script>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Guide</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>
