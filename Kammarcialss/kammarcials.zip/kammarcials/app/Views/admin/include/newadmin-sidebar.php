<!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <div id="wrapper" class="wrapper bg-ash">
       <!-- Header Menu Area Start Here -->
        <div class="navbar navbar-expand-md header-menu-one">
            <div class="nav-bar-header-one">
                <div class="header-logo">
                    <a href="<?php echo base_url('admin/dashboard'); ?>">
                        <img src="<?php echo base_url(); ?>public/newadmin/img/imagelologo.png" alt="logo" style="width:70px !important">
                    </a>
                </div>
                 <div class="toggle-button sidebar-toggle">
                    <button type="button" class="item-link">
                        <span class="btn-icon-wrap">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="d-md-none mobile-nav-bar">
               <button class="navbar-toggler pulse-animation" type="button" data-toggle="collapse" data-target="#mobile-navbar" aria-expanded="false">
                    <i class="far fa-arrow-alt-circle-down"></i>
                </button>
                <button type="button" class="navbar-toggler sidebar-toggle-mobile">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="header-main-menu collapse navbar-collapse" id="mobile-navbar">
                <ul class="navbar-nav">
                    <li class="navbar-item header-search-bar">
                        <!--<div class="input-group stylish-input-group">-->
                            
                        <!--    <input type="text" class="form-control" placeholder="Search">-->
                        <!--</div>-->
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="navbar-item dropdown header-admin">
                        <a class="navbar-nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                            aria-expanded="false">
                            <div class="admin-title">
                                <h5 class="item-title">
                                    
                                    <?php 
                                    $session = session();
                                    $adminEmail = $session->get('user')['user_name'];
                                    echo $adminEmail;
                                    ?>
                                </h5>
                                <span>Admin</span>
                            </div>
                            <div class="admin-img">
                                <img src="<?php echo base_url(); ?>public/newadmin/img/figure/admin.jpg" alt="Admin">
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            
                            <div class="item-content">
                                <ul class="settings-list">
                                    
                                   
                                    <li><a href="<?php echo base_url(); ?>admin/profile"><i class="flaticon-gear-loading"></i>Account details</a></li>
                                    <li><a href="<?= base_url('admin/admin_logout') ?>"><i class="flaticon-turn-off"></i>Log Out</a></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    
                </ul>
            </div>
        </div>
        <!-- Header Menu Area End Here -->
        <!-- Page Area Start Here -->
        <div class="dashboard-page-one">
            <!-- Sidebar Area Start Here -->
            <div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
               <div class="mobile-sidebar-header d-md-none">
                    <div class="header-logo">
                        <a href="<?php echo base_url('admin/dashboard'); ?>"><img src="<?php echo base_url(); ?>public/newadmin/img/logo1.png" alt="logo"></a>
                    </div>
               </div>
                <div class="sidebar-menu-content">
                    <ul class="nav nav-sidebar-menu sidebar-toggle-view">
                        <li class="nav-item sidebar-nav-item">
                            <a href="<?php echo base_url('admin/visual_dashboard'); ?>" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/dash.png" style="width:20px;"/><span> Dashboard</span></a>
                       
                        </li>
                        
                         <!--<li class="nav-item sidebar-nav-item">-->
                         <!--   <a href="<?php echo base_url(); ?>admin/app_logo" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/test.png" style="width:20px;"/> <span>App Logo</span></a>-->
                         <!--    </li>-->
                        
                       
                       
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/person.png" style="width:20px;"/><span> Users <i class="fa fa-caret-down"></i></span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="<?php echo base_url(); ?>admin/user_dashboard" class="nav-link"><i class="fa fa-ellipsis-h"></i>Users</a></li>
                               
                            </ul>
                        </li>
                        
                       <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/person.png" style="width:20px;"/><span> Survey Title <i class="fa fa-caret-down"></i></span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="<?php echo base_url(); ?>admin/survey_title" class="nav-link"><i class="fa fa-ellipsis-h"></i> Title</a></li>
                               
                            </ul>
                        </li>
                        
                         <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/person.png" style="width:20px;"/><span> Survey Question <i class="fa fa-caret-down"></i></span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="<?php echo base_url(); ?>admin/survey_question" class="nav-link"><i class="fa fa-ellipsis-h"></i> Question</a></li>
                               
                            </ul>
                        </li>
                        
                         <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/person.png" style="width:20px;"/><span> Withdraw <i class="fa fa-caret-down"></i></span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="<?php echo base_url(); ?>admin/withdraw_requests" class="nav-link"><i class="fa fa-ellipsis-h"></i> Withdraw Request</a></li>
                                    
                                     <li class="nav-item">
                                    <a href="<?php echo base_url(); ?>admin/withdraw_history" class="nav-link"><i class="fa fa-ellipsis-h"></i> Withdraw History</a></li>
                               
                            </ul>
                        </li>
                        
                       
                         <!--<li class="nav-item sidebar-nav-item">-->
                         <!--   <a href="<?php echo base_url(); ?>admin/banner" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/test.png" style="width:20px;"/> <span>Banner</span></a>-->
                         <!--</li>-->
                           
                          <li class="nav-item sidebar-nav-item">
                            <a href="<?php echo base_url(); ?>admin/about_us/edit/2" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/test.png" style="width:20px;"/> <span>About Us</span></a>
                         </li>
                          <li class="nav-item sidebar-nav-item">
                            <a href="<?php echo base_url(); ?>admin/privacy_policy/edit/1" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/test.png" style="width:20px;"/> <span>Privacy Policy</span></a>
                         </li>
                         
                             
                           
                             
                        <!-- <li class="nav-item sidebar-nav-item">-->
                        <!--    <a href="#" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/person.png" style="width:20px;"/><span> Other <i class="fa fa-caret-down"></i></span></a>-->
                        <!--    <ul class="nav sub-group-menu">-->
                        <!--        <li class="nav-item">-->
                        <!--            <a href="<?php echo base_url(); ?>admin/about_us/edit/2" class="nav-link"><i class="fa fa-ellipsis-h"></i>About Us</a>-->
                        <!--        </li>-->
                        <!--        <li class="nav-item">-->
                        <!--            <a href="<?php echo base_url(); ?>admin/privacy_policy/edit/1" class="nav-link"><i class="fa fa-ellipsis-h"></i>Privacy Policy</a>-->
                        <!--        </li>-->
                                
                                <!--<li class="nav-item">-->
                                <!--    <a href="<?php echo base_url(); ?>admin/faq" class="nav-link"><i class="fa fa-ellipsis-h"></i>Faq</a>-->
                                <!--</li>-->
                               
                        <!--    </ul>-->
                        <!--</li>   -->
                        
                         <!--<li class="nav-item sidebar-nav-item">-->
                         <!--   <a href="<?php echo base_url(); ?>admin/contact_us" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/test.png" style="width:20px;"/> <span>Contact US</span></a>-->
                         <!--    </li>-->
                             
                            <!--  <li class="nav-item sidebar-nav-item">-->
                            <!--<a href="<?php echo base_url(); ?>admin/complain_list" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/test.png" style="width:20px;"/> <span>Complain List</span></a>-->
                            <!-- </li>-->
                       
                        

                        <li class="nav-item sidebar-nav-item">
                            <a href="<?= base_url('admin/admin_logout') ?>" class="nav-link"><img src="<?php echo base_url(); ?>public/newadmin/img/logout.png" style="width:20px;"/> <span>Log out</span></a>
                           
                        </li>
                       
                    </ul>
                </div>
            </div>
            <!-- Sidebar Area End Here -->
            
            
            









<?php
/*
<!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
   <div class="d-flex align-items-center justify-content-between">
      <a href="<?php echo base_url(); ?>admin" class="logo d-flex align-items-center">
      <img src="<?php echo base_url(); ?>admin-html/nice-admin/assets/img/logo.png" alt="">
      <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
   </div>
   <!-- End Logo -->
   <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
         <input type="text" name="query" placeholder="Search" title="Enter search keyword">
         <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
   </div>
   <!-- End Search Bar -->
   <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">
         <li class="nav-item d-block d-lg-none">
            <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
            </a>
         </li>
         <!-- End Search Icon-->
        <?php /*
         <li class="nav-item dropdown">
            <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
            </a><!-- End Notification Icon -->
            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
               <li class="dropdown-header">
                  You have 4 new notifications
                  <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="notification-item">
                  <i class="bi bi-exclamation-circle text-warning"></i>
                  <div>
                     <h4>Lorem Ipsum</h4>
                     <p>Quae dolorem earum veritatis oditseno</p>
                     <p>30 min. ago</p>
                  </div>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="notification-item">
                  <i class="bi bi-x-circle text-danger"></i>
                  <div>
                     <h4>Atque rerum nesciunt</h4>
                     <p>Quae dolorem earum veritatis oditseno</p>
                     <p>1 hr. ago</p>
                  </div>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="notification-item">
                  <i class="bi bi-check-circle text-success"></i>
                  <div>
                     <h4>Sit rerum fuga</h4>
                     <p>Quae dolorem earum veritatis oditseno</p>
                     <p>2 hrs. ago</p>
                  </div>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="notification-item">
                  <i class="bi bi-info-circle text-primary"></i>
                  <div>
                     <h4>Dicta reprehenderit</h4>
                     <p>Quae dolorem earum veritatis oditseno</p>
                     <p>4 hrs. ago</p>
                  </div>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="dropdown-footer">
                  <a href="#">Show all notifications</a>
               </li>
            </ul>
             End Notification Dropdown Items 
         </li>
         <!-- End Notification Nav -->
         <li class="nav-item dropdown">
            <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
            </a><!-- End Messages Icon -->
            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
               <li class="dropdown-header">
                  You have 3 new messages
                  <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="message-item">
                  <a href="#">
                     <img src="<?php echo base_url(); ?>admin-html/nice-admin/assets/img/messages-1.jpg" alt="" class="rounded-circle">
                     <div>
                        <h4>Maria Hudson</h4>
                        <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                        <p>4 hrs. ago</p>
                     </div>
                  </a>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="message-item">
                  <a href="#">
                     <img src="<?php echo base_url(); ?>admin-html/nice-admin/assets/img/messages-2.jpg" alt="" class="rounded-circle">
                     <div>
                        <h4>Anna Nelson</h4>
                        <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                        <p>6 hrs. ago</p>
                     </div>
                  </a>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="message-item">
                  <a href="#">
                     <img src="<?php echo base_url(); ?>admin-html/nice-admin/assets/img/messages-3.jpg" alt="" class="rounded-circle">
                     <div>
                        <h4>David Muldon</h4>
                        <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                        <p>8 hrs. ago</p>
                     </div>
                  </a>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li class="dropdown-footer">
                  <a href="#">Show all messages</a>
               </li>
            </ul>
             End Messages Dropdown Items 
         </li>
         */ ?>
         <?php /*
         <!-- End Messages Nav -->
         <li class="nav-item dropdown pe-3">
            <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="<?php echo base_url(); ?>public/admin-html/nice-admin/assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">K. Anderson</span>
            </a><!-- End Profile Iamge Icon -->
            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
               <li class="dropdown-header">
                  <h6>Kevin Anderson</h6>
                  <span>Web Designer</span>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <li>
                  <a class="dropdown-item d-flex align-items-center" href="<?php echo base_url(); ?>admin">
                  <i class="bi bi-person"></i>
                  <span>My Profile</span>
                  </a>
               </li>
               <li>
                  <hr class="dropdown-divider">
               </li>
               <!--<li>-->
               <!--   <a class="dropdown-item d-flex align-items-center" href="<?php echo base_url(); ?>admin">-->
               <!--   <i class="bi bi-gear"></i>-->
               <!--   <span>Account Settings</span>-->
               <!--   </a>-->
               <!--</li>-->
               <!--<li>-->
               <!--   <hr class="dropdown-divider">-->
               <!--</li>-->
               <!--<li>-->
               <!--   <a class="dropdown-item d-flex align-items-center" href="<?php echo base_url(); ?>admin">-->
               <!--   <i class="bi bi-question-circle"></i>-->
               <!--   <span>Need Help?</span>-->
               <!--   </a>-->
               <!--</li>-->
               <!--<li>-->
                  <hr class="dropdown-divider">
               </li>
               <li>
                  <a class="dropdown-item d-flex align-items-center" href="<?= base_url('admin/admin_logout') ?>">
                  <i class="bi bi-box-arrow-right"></i>
                  <span>Sign Out</span>
                  </a>
               </li>
            </ul>
            <!-- End Profile Dropdown Items -->
         </li>
         <!-- End Profile Nav -->
      </ul>
   </nav>
   <!-- End Icons Navigation -->
</header>
<!-- End Header -->
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
   <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
         <a class="nav-link " href="<?php echo base_url(); ?>admin">
         <i class="bi bi-grid"></i>
         <span>Dashboard</span>
         </a>
      </li>
      <!-- End Dashboard Nav -->
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin">
         <i class="bi bi-menu-button-wide"></i><span>Components</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin">
               <i class="bi bi-circle"></i><span>Alerts</span>
               </a>
            </li>
            
         </ul>
      </li>
      
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#users-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/users">
         <i class="bi bi-menu-button-wide"></i><span>User</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="users-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/users">
               <i class="bi bi-circle"></i><span>Users</span>
               </a>
            </li>
            
         </ul>
      </li>
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#doctors-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/doctors">
         <i class="bi bi-menu-button-wide"></i><span>Doctor</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="doctors-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/doctors">
               <i class="bi bi-circle"></i><span>Doctors</span>
               </a>
            </li>
            
         </ul>
      </li>
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#available-clinics-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/available-clinics">
         <i class="bi bi-menu-button-wide"></i><span>Available Clinic</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="available-clinics-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/available-clinics">
               <i class="bi bi-circle"></i><span>Available Clinics</span>
               </a>
            </li>
            
         </ul>
      </li>
      
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#available-tests-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/available-tests">
         <i class="bi bi-menu-button-wide"></i><span>Available Tests</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="available-tests-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/available-tests">
               <i class="bi bi-circle"></i><span>Available Tests</span>
               </a>
            </li>
            
         </ul>
      </li>
      
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#available-category-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/category">
         <i class="bi bi-menu-button-wide"></i><span>Category</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="available-category-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/main-category">
               <i class="bi bi-circle"></i><span>Main Category</span>
               </a>
            </li>
            <li>
               <a href="<?php echo base_url(); ?>admin/category">
               <i class="bi bi-circle"></i><span>Category</span>
               </a>
            </li>
             <li>
               <a href="<?php echo base_url(); ?>admin/sub-category">
               <i class="bi bi-circle"></i><span>Sub Category</span>
               </a>
            </li>
            
         </ul>
      </li>
      
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#products-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/products">
         <i class="bi bi-menu-button-wide"></i><span>Products</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="products-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/products">
               <i class="bi bi-circle"></i><span>Products</span>
               </a>
            </li>
            
         </ul>
      </li>
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#guide-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/guide">
         <i class="bi bi-menu-button-wide"></i><span>Guide</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="guide-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/guide">
               <i class="bi bi-circle"></i><span>Guide</span>
               </a>
            </li>
            
         </ul>
      </li>
      <li class="nav-item">
         <a class="nav-link collapsed" data-bs-target="#health-record-nav" data-bs-toggle="collapse" href="<?php echo base_url(); ?>admin/health-record">
         <i class="bi bi-menu-button-wide"></i><span>Health Record</span><i class="bi bi-chevron-down ms-auto"></i>
         </a>
         <ul id="health-record-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
             
            <li>
               <a href="<?php echo base_url(); ?>admin/health-record">
               <i class="bi bi-circle"></i><span>Health Record</span>
               </a>
            </li>
            
         </ul>
      </li>

      
      
   </ul>
</aside>
<!-- End Sidebar-->
*/ ?>