<!-- Footer Area Start Here -->
                 <footer class="footer-wrap-layout1">
                    <div class="copyright">© Copyrights <a href="#">Kammarcials</a> 2024. All rights reserved. </div>
                </footer>
                <!-- Footer Area End Here -->
            </div>
        </div>
        <!-- Page Area End Here -->
    </div>
    <!-- jquery-->
    <script src="<?php echo base_url(); ?>public/newadmin/js/jquery-3.3.1.min.js"></script>
    <!-- Plugins js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/plugins.js"></script>
    <!-- Popper js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/bootstrap.min.js"></script>
    <!-- Counterup Js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/jquery.counterup.min.js"></script>
    <!-- Moment Js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/moment.min.js"></script>
    <!-- Waypoints Js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/jquery.waypoints.min.js"></script>
    <!-- Scroll Up Js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/jquery.scrollUp.min.js"></script>
    <!-- Full Calender Js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/fullcalendar.min.js"></script>
    <!-- Chart Js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/Chart.min.js"></script>
    <!-- Custom Js -->
    <script src="<?php echo base_url(); ?>public/newadmin/js/main.js"></script>

</body>


</html>