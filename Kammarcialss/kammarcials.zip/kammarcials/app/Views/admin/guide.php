<?php include('include/header.php'); ?>
<?php include('include/sidebar.php'); ?>
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>

<main id="main" class="main">
    <div class="pagetitle row">
    <div class="col-md-6">
        <h1>Guide Tables</h1>
    </div>
    <div class="col-md-6 text-end">
        <p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/guide/add-guide'); ?>" class="btn btn-primary">Add Guide</a></p>
    </div>
     <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Tables</li>
            <li class="breadcrumb-item active">General</li>
        </ol>
    </nav>
    </div>
  
   <!-- End Page Title -->
   <section class="section">
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
               <div class="card-body">
                  <h5 class="card-title">Guide Table</h5>
                  <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                        
                  <!-- Default Table -->
                  <!-- Display user data in a DataTable -->
        
        <table id="userTable" class="table">
            <thead>
                <tr>
                    <th style="width:5%;" scope="col">#</th>
                    <th style="width:15%;" scope="col">Guide Question</th>
                    <th style="width:15%;" scope="col">Guide Image</th>
                    <th style="width:15%;" scope="col">Guide Answer</th>
                    <th style="width:15%;" scope="col">Guide Sub Category</th>
                    <th style="width:15%;" scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($guide as $guide_in): ?>
                    <tr>
                        <td scope="row"><?= $guide_in['guide_id']; ?></td>
                        <td><?= $guide_in['guide_question']; ?></td>
                        <td>
                            <?php if (!empty($guide_in['guide_image'])): ?>
                                <img src="<?= base_url('public/uploads/guide/' . $guide_in['guide_image']); ?>" alt="Guide Image" class="user-image" width="50" height="50">
                                <?php else: ?>
                <img src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image" class="user-image" width="50" height="50">
                              <?php endif; ?>
                       </td>
                       <td><?= $guide_in['guide_answer']; ?></td>
                        <?php
                        $db = \Config\Database::connect();
                        $builder = $db->table('sub_categories');
                        $query = $builder->select('id, name')->where('id', $guide_in['guide_sub_category_id'])->get();
                        $guide_in_sub_category = $query->getRowArray();
                        ?>
                        <td><?= !empty($guide_in_sub_category) ? $guide_in_sub_category['name'] : 'N/A'; ?></td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <a href="<?= base_url('admin/guide/edit-guide/' . $guide_in['guide_id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                        <?php /* <a href="<?= base_url('admin/category/delete/' . $guide_in['category_id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this entry?');">Delete</a> */ ?>
                        <a href="#" class="btn btn-sm btn-danger delete-guide" data-guide-id="<?= $guide_in['guide_id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                  <!-- End Default Table Example -->
               </div>
            </div>
         </div>
      </div>
   </section>
   
</main>
<!-- End #main -->
<?php include('include/footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>

<!-- Add this in your HTML file to include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    // Use SweetAlert for category deletion confirmation
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.delete-guide').forEach(function (deleteButton) {
            deleteButton.addEventListener('click', function (event) {
                event.preventDefault();

                // Get the category ID from the data attribute
                var guideId = this.getAttribute('data-guide-id');

                // Show the confirmation popup
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You won\'t be able to revert this!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // If confirmed, redirect to the delete URL
                        window.location.href = '<?= base_url('admin/guide/delete/'); ?>' + guideId;
                    }
                });
            });
        });
    });
</script>
