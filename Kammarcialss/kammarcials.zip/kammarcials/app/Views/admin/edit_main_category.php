<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Edit Main Category</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                 
        <h3>Edit Main Category</h3>
        
        <p class="breadcrumb-item"><a href="<?= base_url('admin/main-category'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit Main Category</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/main-category/update/' . $maincategory['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$maincategory['id'];?>">
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" class="form-control" name="name" value="<?= $maincategory['name']; ?>">
                            </div>
                           
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($maincategory['image']) && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['image'])): ?>
                                    <img src="<?= base_url('public/uploads/main_categories/' . $maincategory['image']); ?>" alt="Main Category Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="image" class="form-label">New Category Image:</label>
                                <input type="file" class="form-control" id="image" name="image" style="height:11%">
                            </div>
                            <div class="mb-3">
                               <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                               <label for="description" class="form-label">Description:</label>
                               <textarea id="editor" name="description"><?=$maincategory['description'];?></textarea>
                                <script>
                              CKEDITOR.replace('editor');
                            </script>
                                </div>
                                <div class="mb-3">
                                  <label>Type <span class="red">*</span></label>
                                    <select class="form-control "  name="status" id="status" >
                                        <?php if($maincategory['status']== null){ ?>
                                          <option >Select Status</option>
                                       <?php } ?>
                                      <option value = 'Active' <?php if($maincategory['status'] == 'Active'){echo "selected";}?>>Active</option>
                                      <option value = 'Deactive' <?php if($maincategory['status'] == 'Deactive'){echo "selected";}?>>Deactive</option>
                                      
                                    </select>
                                </div>
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Banner Image:</label>
                                <?php if (!empty($maincategory['banner_image']) && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_image'])): ?>
                                    <img src="<?= base_url('public/uploads/main_categories/' . $maincategory['banner_image']); ?>" alt="Main Category Banner Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="banner_image" class="form-label">New Main Category Banner Image:</label>
                                <input type="file" class="form-control" id="banner_image" name="banner_image" style="height:11%">
                            </div>
                            <div class="mb-3">
                                <label for="existing_video" class="form-label">Existing Banner Video:</label>
                                <?php if (!empty($maincategory['banner_video']) && file_exists(ROOTPATH . 'public/uploads/main_categories/' . $maincategory['banner_video'])): ?>
                                    <video width="100" height="100" controls src="<?= base_url('public/uploads/main_categories/' . $maincategory['banner_video']); ?>"></video>
                                <?php else: ?>
                                    <p>No existing video</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="banner_video" class="form-label">New Main Category Banner Video:</label>
                                <input type="file" class="form-control" id="banner_video" name="banner_video" style="height:11%">
                            </div>
                            
                            <button type="submit" class="btn btn-primary" style="width:11%">Update Main Category</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

