<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>View User</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area mb-3">
                    <h3>View Company <span class="breadcrumb-item" style="float:right;"><a href="<?= base_url('admin/withdraw_requests'); ?>" class="btn btn-primary">Back</a></span></h3>
                  
        
    </div>
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Company</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        <div class="row justify-content-center">
                        <div class="col-lg-8"> 
                        <!-- Form for editing user data -->
                        <form>
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$user['id'];?>">
                            <table class="table table-bordered">
                                <tbody> 
                                    <tr>
                                      <th><label  class="form-label">User Name:</label></th>
                                      <td>   <?php
                                       $db = \Config\Database::connect();
                                      $uid = $user['user_id']; 
                      
                                            $builder = $db->table('users');
                                            $datac = $builder->where('id', $uid)->get()->getResultArray();
                                            echo $datac[0]['user_name'];
                                          ?>
                                      
                                      </td>
                                    </tr>
                                    
                                     <tr>
                                      <th><label class="form-label">User Reward:</label></th>
                                      <td>  <?php echo $datac[0]['wallet'];
                                          ?></td>
                                    </tr>
                                    
                                     <tr>
                                      <th><label class="form-label">Withdraw Request Date Time:</label></th>
                                      <td>  <?=$user['date_time'];?></td>
                                    </tr>
                                    
                                    
                                </tbody>
                            </table>
                            
                              
                        </form>
                        </div>
                        
                      
                        </div>
                        
                        <!--<form method="POST" action="<?= base_url('admin/withdraw_requests/update'); ?>" enctype="multipart/form-data">-->
                        <form method="POST" action="<?= base_url('admin/withdraw_requests/update/' . $user['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-6" style="font-size: 13px; width: 25%;">
                                <label for="user_name" class="form-label">Pay Amount</label>
                                <input type="text" class="form-control" name="amount" required="" style=" font-size: 13px;">
                                <input type="hidden"  class="form-control" name="id" value="<?=$user['id'];?>">
                            </div>
                            
                            <div class="mb-3" style="  width: 25%;">
                                <label for="email" class="form-label">Payment By</label>
                                <input type="text" class="form-control" name="added_by" required="">
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Payment Status</label>
                                <select class="form-control" name="status" style="font-size: 13px;width: 25%;">
                                    <option value="Pending">Pending</option>
                                    <option value="Confirm">Approved</option>
                                    <option value="Reject">Reject</option>
                                </select>
                            </div>
                            
                            
                            <button type="submit" name="payed" class="btn btn-primary">Pay</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

