<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Sub Category Database</h3>
                   
        <p class="breadcrumb-item"><a href="<?= base_url('admin/sub_category'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Update Sub Category</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/sub_category/update/' . $sonography_ultrasounds['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                           <input type="hidden"  class="form-control" name="su_id" value="<?=$sonography_ultrasounds['id'];?>">
                           
                           <div class="mb3">
                                <label>Select  Category Name <span class="red">*</span></label>
                                <select class="form-control " name="category_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('categories');
                                    $query = $builder->select('category_id, category_name')->get();
                                    $results = $query->getResultArray();
                                    echo '<option value="" disabled>Select User Name</option>';
                                   
                                        foreach ($results as $user) { ?>
                                            <option value="<?= $user['category_id']; ?>" <?php if ($user['category_id'] == $sonography_ultrasounds['category_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $user['category_name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Sub Category Name:</label>
                                <input type="text" class="form-control" name="name" value="<?= $sonography_ultrasounds['name']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($sonography_ultrasounds['image']) && file_exists(ROOTPATH . 'public/uploads/sub_categories/' . $sonography_ultrasounds['image'])): ?>
                                    <img src="<?= base_url('public/uploads/sub_categories/' . $sonography_ultrasounds['image']); ?>" alt="Sonography Ultrasound Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="su_image" class="form-label">New Image:</label>
                                <input type="file" class="form-control" id="image" name="image">
                            </div>
                            
                             <div class="mb-3">
                                <label for="screen_type" class="form-label">Screen Type:</label>
                                <input type="text" class="form-control" name="screen_type" value="<?= $sonography_ultrasounds['screen_type']; ?>">
                            </div>
                            
                          
                            
                           <div class="mb-3">
                               <label for="description" class="form-label">Description:</label>
                               <textarea id="editor" name="description"><?=$sonography_ultrasounds['description'];?></textarea>
                                <script>
                                   CKEDITOR.replace('editor');
                                </script>
                            </div>
                            
                            <button type="submit" class="btn btn-primary" style="width:180px;">Update Sub Category</button>
                        </form>

<?php include('include/newadmin-footer.php'); ?>
