<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Withdraw Requests Database</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Withdraw Requests</li>
        <!--<p class="breadcrumb-item"><a href="<?= base_url('admin/survey_question/add_survey_question'); ?>" -->
        <!--class="btn btn-primary" style="width: 180px;margin-top: -50px;">Add Survey Question</a></p>-->
                    </ul>
                </div>
                
                <!-- Breadcubs Area End Here -->
                <!-- Student Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>List Name of Withdraw Requests</h3>
                            </div>
                           
                        </div>
                        <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                        <div class="table-responsive">
                            <table id="userTable" class="table display data-table text-nowrap">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Request By</th>
                                        <th>User Total Wallet Reward </th>
                                        <th>Bank Detail</th>
                                        <th>Status</th>
                                        <th>Date time</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                <?php 
                
                
                
                     $db = \Config\Database::connect();
                        $builder = $db->table('withdraw');
                        $query = $builder->select('*')->where('status','Pending')->get();
                        $suppliment_plan = $query->getResultArray();
                        
                        if($suppliment_plan==null)
                        {
                          $suppliment_plan1 = [];  
                        }
                        else
                        {
                           $suppliment_plan1 = $suppliment_plan;
                        }
                $i=1;
                  foreach ($suppliment_plan1 as $suppliment_plan_in): ?>
                    <tr>
                        <td><?= $i++; ?></td>
                      <td><?php $uid = $suppliment_plan_in['user_id']; 
                      
                        $builder = $db->table('users');
                        $datac = $builder->where('id', $uid)->get()->getResultArray();
                        $f = $datac[0];
                        echo $f['user_name'];
                      ?></td>
                      <td><?php $uid1 = $suppliment_plan_in['user_id']; 
                      
                        $builder = $db->table('users');
                        $datac1 = $builder->where('id', $uid1)->get()->getResultArray();
                        echo $datac1[0]['wallet'];
                      ?></td>
                       
                        <td>
                            <?php
                            if($f['country']=='INDIA')
                            { ?>
                            
                            Bank  Name : <?=$f['bank_name'];?> <br>
                            Account Number : <?=$f['account_number'];?> <br>
                            Bank Ifsc code : <?=$f['ifsc_code'];?> <br>
                     
                           <?php }
                            else
                            { ?>
                            Account Number : <?=$f['account_number'];?> <br>
                            Sort Code : <?=$f['sort_code'];?> <br>
                            
                          <?php  }
                            ?>
                            
                        </td>
                        <td style="color:orange"><?= $suppliment_plan_in['status']; ?></td>
                       <td><?= $suppliment_plan_in['date_time']; ?></td>
                        <td><a href="<?= base_url('admin/withdraw_requests_payment_admin/' . $suppliment_plan_in['id']); ?>" class="btn btn-primary">Pay</a></td>
                        
                      
                    </tr>
                <?php endforeach; ?>
            </tbody>
                               
                            </table>
                        </div>
                    </div>
                </div>

<?php include('include/newadmin-footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>

<!-- Add this in your HTML file to include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    // Use SweetAlert for category deletion confirmation
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.delete-suppliment-plan').forEach(function (deleteButton) {
            deleteButton.addEventListener('click', function (event) {
                event.preventDefault();

                // Get the category ID from the data attribute
                var supplimentplanId = this.getAttribute('data-suppliment-plan-id');

                // Show the confirmation popup
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You won\'t be able to revert this!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // If confirmed, redirect to the delete URL
                        window.location.href = '<?= base_url('admin/survey_question/delete/'); ?>' + supplimentplanId;
                    }
                });
            });
        });
    });
</script>
