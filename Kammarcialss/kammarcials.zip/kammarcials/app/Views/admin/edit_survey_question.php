<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Survey Question Database</h3>
                   
        <p class="breadcrumb-item"><a href="<?= base_url('admin/survey_question'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Update Survey Question</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/survey_question/update/' . $suppliment_plan['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                           <input type="hidden"  class="form-control" name="id" value="<?=$suppliment_plan['id'];?>">
                           
                           <div class="mb3">
                                <label>Select Survey Title <span class="red">*</span></label>
                                <select class="form-control " name="survey_id" id="survey_id">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('survey_title');
                                    $query = $builder->select('id, title')->get();
                                    $sub_categories = $query->getResultArray();
                                    echo '<option value="" disabled>Select Sub Category</option>';
                                   
                                        foreach ($sub_categories as $sub_category) { ?>
                                            <option value="<?= $sub_category['id']; ?>" <?php if ($sub_category['id'] == $suppliment_plan['survey_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $sub_category['title']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                             <div class="mb-3">
                                <label for="name" class="form-label">Question:</label>
                                <input type="text" class="form-control" name="question" value="<?= $suppliment_plan['question']; ?>">
                            </div>
                             <div class="mb-3">
                                <label for="amount" class="form-label">Answer:</label>
                                <input type="text" class="form-control" name="answer" value="<?= $suppliment_plan['answer']; ?>">
                            </div>
                           
                            
                           <div class="mb-3">
                                <label for="title" class="form-label">Option1:</label>
                                <input type="text" class="form-control" name="option1" value="<?= $suppliment_plan['option1']; ?>">
                            </div>
                            
                             <div class="mb-3">
                                <label for="title" class="form-label">Option2:</label>
                                <input type="text" class="form-control" name="option2" value="<?= $suppliment_plan['option2']; ?>">
                            </div>
                            
                             <div class="mb-3">
                                <label for="title" class="form-label">Option3:</label>
                                <input type="text" class="form-control" name="option3" value="<?= $suppliment_plan['option3']; ?>">
                            </div>
                            
                             <div class="mb-3">
                                <label for="title" class="form-label">Option4:</label>
                                <input type="text" class="form-control" name="option4" value="<?= $suppliment_plan['option4']; ?>">
                            </div>
                            
                             <div class="mb-3">
                                <label for="title" class="form-label">Reward Point:</label>
                                <input type="text" class="form-control" name="rewardPoint" value="<?= $suppliment_plan['rewardPoint']; ?>">
                            </div>
                            
                            <button type="submit" class="btn btn-primary" style="width:180px;">Update Survey Question</button>
                        </form>

<?php include('include/newadmin-footer.php'); ?>
