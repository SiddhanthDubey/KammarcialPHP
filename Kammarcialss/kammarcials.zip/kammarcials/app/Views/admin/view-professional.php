<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>View User</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area mb-3">
                    <h3>View Professional <span class="breadcrumb-item" style="float:right"><a href="<?= base_url('admin/professional'); ?>" class="btn btn-primary">Back</a></span></h3>
                   
                        
        
      </div>
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Professional</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="row justify-content-center">
                            <div class="col-lg-3 text-center mb-5">
                                 <?php if (!empty($user['image']) && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])): ?>
                                    <img src="<?= base_url('public/uploads/users/' . $user['image']); ?>" alt="User Image" style="width:150px; height:180px; border: 1px solid #ddd; border-radius:20px">
                                <?php else: ?>
                                  <img src="https://cdn.iconscout.com/icon/free/png-256/free-user-1885-840228.png?f=webp" alt="User Image" width="120" height="200" style="border: 1px solid #ddd; border-radius:20px">
                                    <p>No User image</p>
                                <?php endif; ?>
                             
                                                            </div>
                        </div>
                        <!-- Form for editing user data -->
                        <form>
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$user['id'];?>">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                      <th><label class="form-label">User Name:</label></th>
                                      <td> <?php echo $user['user_name']; ?></td>
                                    </tr>
                                    
                                     <tr>
                                      <th><label class="form-label">Email:</label></th>
                                      <td> <?php echo $user['email']; ?></td>
                                    </tr>
                                    
                                    <tr>
                                      <th><label class="form-label">Mobile:</label></th>
                                      <td><?php echo $user['mobile']; ?></td>
                                    </tr>
                                    
                                     <tr>
                                      <th><label class="form-label">Age:</label></th>
                                      <td> <?php echo $user['age']; ?></td>
                                    </tr>
                                     
                                     <tr>
                                    <th><label class="form-label">Professional Number:</label></th>
                                      <td> <?php echo $user['professional_number']; ?></td>
                                    </tr>
                                    <tr>
                                        
                                    <th><label class="form-label">Expertise Service:</label></th> 
                                      <td> <?php 
                                      
                                      
                                      $expertise_service_id =  $user['expertise_service_id'];
                                      $db = \Config\Database::connect();
                                      $categoryList = $db->query(" SELECT * FROM `services` WHERE `ser_id` IN ($expertise_service_id) ")->getResultArray();
                                      foreach($categoryList as $m)
                                      {
                                          echo $m['service_name'].', ';
                                      }
                      
                                      ?></td>
                                    </tr>
                                    <tr>
                                    <th><label class="form-label">Address:</label></th>
                                      <td> <?php echo $user['address']; ?></td>
                                    </tr>
                                    <tr>
                                    <th><label class="form-label">Year of Expertise:</label></th>
                                      <td> <?php echo $user['year_of_expertise']; ?></td>
                                    </tr>
                                    <tr>
                                    <th><label class="form-label">Bio:</label></th>
                                      <td> <?php echo $user['bio']; ?></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                           
                           
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

