<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<!--        <h1>Add Doctor</h1>-->
<!--    </div>-->
<!--    <div class="col-md-6 text-end">-->

 <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add Doctor</h3>
        <p class="breadcrumb-item"><a href="<?= base_url('admin/doctors'); ?>" class="btn btn-primary">Back</a></p>
    </div>
    <!--</div>-->
    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
    <!-- End Page Title -->
    <!--<section class="section">-->
    <!--    <div class="row">-->
    <!--        <div class="col-lg-12">-->
    <!--            <div class="card">-->
    <!--                <div class="card-body">-->
                        <h5 class="card-title">Add Doctor</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/doctors/save'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                            <div class="mb-3">
                                <label for="name" class="form-label">Doctor Name:</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="post" class="form-label">Post:</label>
                                <input type="text" class="form-control" name="post" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="professional_profile" class="form-label">Professional Profile:</label>
                                <input type="text" class="form-control" name="professional_profile" required>
                            </div>

                            <!-- Additional fields based on UserModel -->
                            <div class="mb-3">
                                <label for="consult_fee" class="form-label">Consult Fee:</label>
                                <input type="text" class="form-control" name="consult_fee">
                            </div>
                            <div class="mb-3">
                                <label for="clinic" class="form-label">Clinic:</label>
                                <input type="text" class="form-control" name="clinic">
                            </div>
                            <div class="mb-3">
                                <label for="year_of_experience" class="form-label">Year Of Experience:</label>
                                <input type="number" class="form-control" name="year_of_experience">
                            </div>

                            <!-- End of additional fields -->

                            <div class="mb-3">
                                <label for="image" class="form-label">Image:</label>
                                <input type="file" class="form-control" id="image" name="image" required style="height:10%">
                            </div>
                            <div class="mb-3">
                                <label for="languages" class="form-label">Languages:</label>
                                <input type="text" class="form-control" name="languages">
                            </div>
                            <div class="mb-3">
                                <label for="education" class="form-label">Education:</label>
                                <input type="text" class="form-control" name="education">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Add Doctor</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
