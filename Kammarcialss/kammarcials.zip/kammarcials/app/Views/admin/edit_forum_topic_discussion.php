<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit forum Topic</h3>
                   
        <p class="breadcrumb-item"><a href="<?= base_url('admin/forum_topic'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Update forum_topic</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/forum_topic_discussion/update/' . $sonography_ultrasounds['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                           <input type="hidden"  class="form-control" name="id" value="<?=$sonography_ultrasounds['id'];?>">
                           
                           
                           
                           <div class="mb3">
                                <label>forum Topic Name: <span class="red">*</span></label>
                                <select class="form-control " name="topic_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('forum_topic');
                                    $query = $builder->select('id, name')->get();
                                    $results = $query->getResultArray();
                                    echo '<option value="" disabled>Select forum topic</option>';
                                   
                                        foreach ($results as $user) { ?>
                                            <option value="<?= $user['id']; ?>" <?php if ($user['id'] == $sonography_ultrasounds['topic_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $user['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            
                           
                            <div class="mb-3">
                                <label for="title" class="form-label">Title:</label>
                                <input type="text" class="form-control" name="title" value="<?= $sonography_ultrasounds['title']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="title" class="form-label">Description:</label>
                                <input type="text" class="form-control" name="description" value="<?= $sonography_ultrasounds['description']; ?>">
                            </div>
                            
                            
                            
                            <button type="submit" class="btn btn-primary" style="width:180px;">Update forum Topic</button>
                        </form>

<?php include('include/newadmin-footer.php'); ?>
