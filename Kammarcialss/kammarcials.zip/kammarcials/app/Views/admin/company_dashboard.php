<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
 
<style>

.mycards{
    background:transparent;
    padding:15px 30px 0px;
}
    .grad1{
        background:linear-gradient(to right, #CDDC39, rgb(131 133 44));
    }
    .grad11{
        background:linear-gradient(to right, rgb(246 160 149), rgb(245 114 34))
    }
    .grad2{
        background:linear-gradient(to right, rgb(235, 51, 73), rgb(244, 92, 67));
    }
    .grad3{
        background:linear-gradient(to right, rgb(8, 80, 120), rgb(133, 216, 206));
    }
    .grad4{
        background:linear-gradient(to right, rgb(19, 78, 94), rgb(113, 178, 128));
    }
</style> 
  
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
               
                <!-- Breadcubs Area End Here -->
                <!-- Dashboard summery Start Here -->
              
                    <div class="card mt-5">
                    <div class="card-body">
                    <div class="col-xl-12 col-sm-6 col-12 mt-3 ">
                      <div class="row">
                          <div class="col-lg-10">
                            <h4 class="mb-0">Welcome To Company Dashboard</h4>
                            <p><?php echo $date = date('m/d/Y h:i:s a', time()); ?></p>
                          </div>
                          <!--<div class="col-lg-2 text-right">-->
                          <!--  <a href=""> <img src="<?php echo base_url(); ?>public/newadmin/img/iconsms.png" style="width:32px; margin-top:15px;"/></a>-->
                          <!--  <a href=""> <img src="<?php echo base_url(); ?>public/newadmin/img/icontimes.png"  style="width:32px; margin-top:15px;"/></a>-->
                          <!--</div>-->
                      </div>
                    </div>
                   </div>
                </div>
                
               
                <!-- Dashboard summery End Here -->
                  <div class="card mt-5 mb-4">
                    <div class="card-body">
                    <div class="row">
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad2">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Users</h5>
                            <h2 class="mb-4 text-white font-weight-bold">932</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad11">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Earning</h5>
                            <h2 class="mb-4 text-white font-weight-bold">$756,00</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3  col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad3">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Employee</h5>
                            <h2 class="mb-4 text-white font-weight-bold">50</h2>
                           
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-xl-3 col-lg-3 col-sm-6 grid-margin stretch-card">
                        <div class="card grad4">
                          <div class="card-body text-center mycards">
                            <h5 class="mb-2 text-white font-weight-bold">Total Services</h5>
                            <h2 class="mb-4 text-white font-weight-bold">10</h2>
                            
                          </div>
                        </div>
                      </div>
                    </div> 
                  </div>
                  
                   <div class="card">
                    <div class="card-body">
                    <div class="row">
                       <div class="heading-layout1">
                            <div class="item-title">
                                <h3>List of Users</h3>
                            </div>
                           
                        </div>
                        <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                        <div class="table-responsive">
                            <table id="userTable" class="table display data-table text-nowrap">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <th scope="row"><?= $user['id']; ?></th>
                        <td><?= $user['user_name']; ?></td>
                        <td><?= $user['email']; ?></td>
                        <td><?= $user['mobile']; ?></td>
                        <td>
                            <?php if (!empty($user['image'])): ?>
                                <img style="width:32px;" src="<?= base_url('public/uploads/users/' . $user['image']); ?>" alt="User Image">
                                <?php else: ?>
                                <img style="width:32px;" src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image">
                              <?php endif; ?>
                        </td>
                        <td>
                            <!-- Add your edit and delete buttons here -->
                            <!-- Example: -->
                            <a href="<?= base_url('admin/users/view/' . $user['id']); ?>" class="btn btn-primary">View</a>
                            <a href="<?= base_url('admin/users/edit/' . $user['id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                           <a href="<?= base_url('admin/users/delete/' . $user['id']); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
                               
                            </table>
                        </div>
                  </div>
                </div>
<?php include('include/newadmin-footer.php'); ?>            
<!-- Initialize DataTable on the userTable -->
<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>