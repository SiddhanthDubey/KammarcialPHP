<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
    
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
               
                <!-- Breadcubs Area End Here -->
                <!-- Dashboard summery Start Here -->
              
                    <div class="card mt-5">
                    <div class="card-body p-0">
                    <div class="col-xl-12 col-sm-6 col-12 mt-3 ">
                      <div class="row">
                          <div class="col-lg-10">
                            <h4 class="mb-0">Welcome To Kammarcials </h4>
                            <p><?php echo $date = date('m/d/Y h:i:s a', time()); ?></p>
                          </div>
                          <!--<div class="col-lg-2 text-right">-->
                          <!--  <a href=""> <img src="<?php echo base_url(); ?>public/newadmin/img/iconsms.png" style="width:32px; margin-top:15px;"/></a>-->
                          <!--  <a href=""> <img src="<?php echo base_url(); ?>public/newadmin/img/icontimes.png"  style="width:32px; margin-top:15px;"/></a>-->
                          <!--</div>-->
                      </div>
                    </div>
                   </div>
                </div>
                
                <?php if (session()->has('success')) : ?>
                    <div class="alert alert-success" role="alert">
                        <?= session('success') ?>
                    </div>
                <?php endif; ?>
                <?php if (session()->has('error')) : ?>
                    <div class="alert alert-danger" role="alert">
                        <?= session('error') ?>
                    </div>
                <?php endif; ?>
                
                <?php 
                
                   $db = \Config\Database::connect(); //
                
                  $fetch = $db->query(" SELECT COUNT(*) as tuser FROM `users` WHERE `type` = 'User' ")->getResultArray();
                  $udata =  $fetch[0]['tuser'];
                  
                  $fetch = $db->query(" SELECT COUNT(*) as tprovider FROM `users` WHERE `type` = 'Provider' ")->getResultArray();
                  $pdata =  $fetch[0]['tprovider'];

                
                
                ?>
                
                <!-- Dashboard summery End Here -->
                <!-- Dashboard Content Start Here -->
                <div class="row gutters-20">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12 ">
            <div class="dd_box1  p-4 text-center" style="background: #483693;border-radius: 0.5rem;box-shadow: 0px 0px 0px #000;">
                            <h2 class="text-white font-weight-bold mb-1">Total Users</h2>
                            <h2 class="text-white"><?=$udata?> </h2>
                        </div>

                    </div>
                    
            <!--        <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12 ">-->
            <!--<div class="dd_box1  p-4 text-center" style="background:#5eb089;border-radius: 0.5rem; box-shadow: 0px 0px 0px #000;">-->
            <!--                <h2 class="text-white font-weight-bold mb-1">Total Provider</h2>-->
            <!--                <h2 class="text-white"><?=$pdata?> </h2>-->
            <!--            </div>-->

            <!--        </div>-->
                    <div class="col-12 col-xl-12 col-6-xxxl lefttable">
                        <div class="card dashboard-card-one pd-b-20">
                            <div class="card-body">
                                <div class="heading-layout1">
                                    <div class="item-title">
                                        <h3> Recently Added User</h3>
                                    </div>
                                   
                                </div>
                                <div class="earning-report">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                 <th>Sr. No.</th>
                                                <th>User Name</th>
                                                <th>Date & Time</th>
                                                <th>Result</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $current_date = date("Y-m-d");
                                            $i = 1;
                                             $fetch = $db->query(" SELECT * FROM `users` WHERE date(`created_at`) = '$current_date' ")->getResultArray();
                                            foreach($fetch as $li)
                                           { ?>
                                            <tr>
                                                <td><?=$i++;?></td>
                                                <td><?=$li['user_name'];?></td>
                                                <td><?=$li['created_at'];?></td>
                                                <td ><a href="<?php echo base_url('admin/users/view'); ?>/<?=$li['id'];?>"><img src="<?php echo base_url(); ?>public/newadmin/img/eye.png" style="width:24px;"/></a></td>
                                            </tr>
                                            <?php }?>
                                            <!-- <tr>-->
                                            <!--    <td>Mental Health Asessement</td>-->
                                            <!--    <td>23/10/2023 4.00 pm</td>-->
                                            <!--    <td align="center"><img src="<?php echo base_url(); ?>public/newadmin/img/eye.png" style="width:24px;"/></td>-->
                                            <!--</tr>-->
                                            <!-- <tr>-->
                                            <!--    <td>Prediabetes Asessment</td>-->
                                            <!--    <td>23/10/2023 4.00 pm</td>-->
                                            <!--    <td align="center"><img src="<?php echo base_url(); ?>public/newadmin/img/eye.png" style="width:24px;"/></td>-->
                                            <!--</tr>-->
                                        </tbody>
                                    </table>
                                </div>
                               
                            </div>
                        </div>
                       
                        
                        
                    </div>
                    <!--<div class="col-12 col-xl-4 col-3-xxxl rightsidee">-->
                        
                    <!--    <div class="card">-->
                    <!--        <div class="card-body">-->
                    <!--            <div class="heading-layout1">-->
                    <!--                <div class="item-title">-->
                    <!--                    <h3 class="font-weight:500;">Activity Status</h3>-->
                    <!--                </div>-->
                                    
                    <!--            </div>-->
                    <!--            <div class="row">-->
                    <!--            <div class="col-3">-->
                    <!--              <img src="<?php echo base_url(); ?>public/newadmin/img/person.png"  style="width:40px;"/>  -->
                    <!--            </div>-->
                    <!--            <div class="col-9">-->
                    <!--                <div class="item-content">-->
                    <!--                    <p>ABCCD choose Atilia Haron for Yoga classes</p>-->
                                       
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--            </div>-->

                    <!--            <div class="row">-->
                    <!--            <div class="col-3">-->
                    <!--              <img src="<?php echo base_url(); ?>public/newadmin/img/person.png"  style="width:40px;"/>  -->
                    <!--            </div>-->
                    <!--            <div class="col-9">-->
                    <!--                <div class="item-content">-->
                    <!--                    <p>ABCCD in progress workout L1 </p>-->
                                       
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--            </div>-->

                    <!--            <div class="row">-->
                    <!--            <div class="col-3">-->
                    <!--              <img src="<?php echo base_url(); ?>public/newadmin/img/person.png"  style="width:40px;"/>  -->
                    <!--            </div>-->
                    <!--            <div class="col-9">-->
                    <!--                <div class="item-content">-->
                    <!--                    <p>ABCCD purchase Feminira 2 days ago!</p>-->
                                       
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                        
                    <!--</div>-->
                  
                </div>
                <!-- Dashboard Content End Here -->
             
<?php include('include/newadmin-footer.php'); ?>                