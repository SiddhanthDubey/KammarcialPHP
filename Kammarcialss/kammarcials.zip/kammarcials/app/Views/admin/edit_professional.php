<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />

<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBQDSvBppnW59UJ0ALOlGV5aMiJl6bgk70&callback=initMap&sensor=false&libraries=places"></script>

    <script>


  function initialize() {
        var address = (document.getElementById('pac-input'));
        var autocomplete = new google.maps.places.Autocomplete(address);
        autocomplete.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete, 'place_changed', function() {
            var place = autocomplete.getPlace();
            if (!place.geometry) {
                return;
            }

        var address = '';
        if (place.address_components) {
            address = [
                (place.address_components[0] && place.address_components[0].short_name || ''),
                (place.address_components[1] && place.address_components[1].short_name || ''),
                (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude').value = place.geometry.location.lat();
        document.getElementById('longnitude').value = place.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize);
   
   function initialize1() {
        var address1 = (document.getElementById('pac-input1'));
        var autocomplete1 = new google.maps.places.Autocomplete(address1);
        autocomplete1.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete1, 'place_changed', function() {
            var place1 = autocomplete1.getPlace();
            if (!place1.geometry) {
                return;
            }

        var address1 = '';
        if (place1.address_components) {
            address1 = [
                (place1.address_components[0] && place1.address_components[0].short_name || ''),
                (place1.address_components[1] && place1.address_components[1].short_name || ''),
                (place1.address_components[2] && place1.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude1').value = place1.geometry.location.lat();
        document.getElementById('longnitude1').value = place1.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize1);
   
   function initialize2() {
        var address2 = (document.getElementById('pac-input2'));
        var autocomplete2 = new google.maps.places.Autocomplete(address2);
        autocomplete2.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete2, 'place_changed', function() {
            var place2 = autocomplete2.getPlace();
            if (!place2.geometry) {
                return;
            }

        var address2 = '';
        if (place2.address_components) {
            address2 = [
                (place2.address_components[0] && place2.address_components[0].short_name || ''),
                (place2.address_components[1] && place2.address_components[1].short_name || ''),
                (place2.address_components[2] && place2.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude2').value = place2.geometry.location.lat();
        document.getElementById('longnitude2').value = place2.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize2);
   
   function initialize3() {
        var address3 = (document.getElementById('pac-input3'));
        var autocomplete3 = new google.maps.places.Autocomplete(address3);
        autocomplete3.setTypes(['geocode']);
        google.maps.event.addListener(autocomplete3, 'place_changed', function() {
            var place3 = autocomplete3.getPlace();
            if (!place3.geometry) {
                return;
            }

        var address3 = '';
        if (place3.address_components) {
            address3 = [
                (place3.address_components[0] && place3.address_components[0].short_name || ''),
                (place3.address_components[1] && place3.address_components[1].short_name || ''),
                (place3.address_components[2] && place3.address_components[2].short_name || '')
                ].join(' ');
        }
        /*********************************************************************/
        /* var address contain your autocomplete address *********************/
        /* place.geometry.location.lat() && place.geometry.location.lat() ****/
        /* will be used for current address latitude and longitude************/
        /*********************************************************************/
      

        document.getElementById('latitude3').value = place3.geometry.location.lat();
        document.getElementById('longnitude3').value = place3.geometry.location.lng();
        });
  }

   google.maps.event.addDomListener(window, 'load', initialize3);
    </script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Professional</h3> 
        <p class="breadcrumb-item"><a href="<?= base_url('admin/professional'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
<!--    </div>-->
<!--    <section class="section">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <div class="card">-->
<!--                    <div class="card-body">-->
                        <h5 class="card-title">Edit professional</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/professional/update/' . $user['id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$user['id'];?>">
                            
                             <div class="col-md-6 mb-3">
                                <label for="company_name" class="form-label">User Name:</label>
                                <input type="text" class="form-control" name="user_name" value="<?= $user['user_name']; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="company_code" class="form-label">Email:</label>
                                <input type="text" class="form-control" name="email" value="<?= $user['email']; ?>">
                            </div>
                             <div class="col-md-6 mb-3">
                                <label for="company_number" class="form-label">Professional Number:</label>
                                <input type="text" class="form-control" name="professional_number" value="<?= $user['professional_number']; ?>">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Age:</label>
                                <input type="text" class="form-control" name="age" value="<?= $user['age']; ?>">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="language" class="form-label">Year of Expertise:</label>
                                <input type="text" class="form-control" name="year_of_expertise" value="<?= $user['year_of_expertise']; ?>">
                            </div>
                            
                           <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">expertise_service_id:</label>
                                <!--<input type="text" class="form-control" name="expertise_service_id" required>-->
                                
                                <select class="form-control basic-multiple" name="expertise_service_id[]" multiple="multiple" >
                                    
                                    
                                    
                                     <?php 
                                     $db  = \Config\Database::connect();
                                     
                                     $memid = $user['expertise_service_id'];
                               
                                      if($memid > 0)
                                                 { 
                                                    $subjects = [];
                                                    
                                                     
              
               
                                                    $value = $db->query("select * from services where ser_id IN ($memid) ")->getResultArray();
              
                                                  foreach($value as $key) 
                                                {
                                        			    $subjects[] .= $key['ser_id'];
                                        			//	$subjects .= ",";
                                        		}
                                                    
                                                 }
                                                 else
                                                 {echo 'no Services'; }
                                              
                                                ?>
                                 
                                     <?php
                                     
                                     $category1 = $db->query("select * from services ")->getResultArray();
                                     foreach($category1 as $val){?>
                                <option value="<?php echo $val['ser_id'];?>" 
                                <?php echo in_array($val['ser_id'], $subjects) ? 'selected':'' ?>
                                >
                                    <?php echo $val['service_name'];?></option>
                                    <?php }?>
                                    
                                  
                            </select>

                            </div>
                            
                            
                             <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Mobile:</label>
                                <input type="mobile" disable class="form-control" name="mobile" value="<?= $user['mobile']; ?>">
                            </div>
                            
                            <!--<div class="col-md-6 mb-3">-->
                            <!--    <label for="password" class="form-label">Pin:</label>-->
                            <!--    <input type="password" class="form-control" name="password" value="<?= $user['password']; ?>">-->
                            <!--</div>-->
                            
                            
                            <div class="col-md-6 mb-3">
                                <label for="language" class="form-label">Language:</label>
                                <input type="text" class="form-control" name="language" value="<?= $user['language']; ?>">
                            </div>
                            
                            
                              <div class="col-md-6 mb-3">
                                <label for="mobile" class="form-label">location:</label>
                                 <input id="pac-input1"  name="address" required="" class="form-control" placeholder="" type="text"  value="<?= $user['address']; ?>">
                          <input name="lat" id="latitude1" required="" class="form-control" placeholder="" type="hidden" value="" value="<?= $user['lat']; ?>">
                          <input name="lon" id="longnitude1" required="" class="form-control" placeholder="" type="hidden" value="<?= $user['lon']; ?>"> 
                            </div>
                            
    
                            
                            <div class="col-md-6 mb-3">
                                <label for="bio" class="form-label">Bio:</label>
                                <textarea type="text" class="form-control" name="bio"><?= $user['bio']; ?></textarea>
                            </div>
                            
                            
                            
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($user['image']) && file_exists(ROOTPATH . 'public/uploads/users/' . $user['image'])): ?>
                                    <img src="<?= base_url('public/uploads/users/' . $user['image']); ?>" alt="User Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="image" class="form-label">New Profile Image:</label>
                                <input type="file" class="form-control" id="image" name="image" style="height:10%;">
                            </div>
                            
                            
                            
                            
                            
                            <button type="submit" class="btn btn-primary" style="width:15%">Update professional</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>$(document).ready(function() {
    $('.basic-multiple').select2();
});
</script>

