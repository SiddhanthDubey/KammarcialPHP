<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<!--<main id="main" class="main">-->
<!--    <div class="pagetitle row">-->
<!--    <div class="col-md-6">-->
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                 
        <h3>Edit Category</h3>
    <!--</div>-->
    <!--<div class="col-md-6 text-end">-->
        <p class="breadcrumb-item"><a href="<?= base_url('admin/category'); ?>" class="btn btn-primary">Back</a></p>
<!--    </div>-->
<!--</div>-->
    <!-- End Page Title -->
    <!--</div>-->
    <!--<section class="section">-->
    <!--    <div class="row">-->
    <!--        <div class="col-lg-12">-->
    <!--            <div class="card">-->
    <!--                <div class="card-body">-->
                        <h5 class="card-title">Edit Category</h5>
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?= session('errors') ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Form for editing user data -->
                        <form method="POST" action="<?= base_url('admin/category/update/' . $category['category_id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="id" value="<?=$category['category_id'];?>">
                            
                            <div class="mb-3">
                                <label for="category_name" class="form-label">Category Name:</label>
                                <input type="text" class="form-control" name="category_name" value="<?= $category['category_name']; ?>">
                            </div>
                            <div class="mb3">
                                <label>Select Main Category <span class="red">*</span></label>
                                <select class="form-control " name="main_category_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('main_categories');
                                    $query = $builder->select('id, name')->get();
                                    $main_categories = $query->getResultArray();
                                    echo '<option value="" disabled>Select Main Category</option>';
                                   
                                        foreach ($main_categories as $main_category) { ?>
                                            <option value="<?= $main_category['id']; ?>" <?php if ($main_category['id'] == $category['main_category_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $main_category['name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($category['category_image']) && file_exists(ROOTPATH . 'public/uploads/categories/' . $category['category_image'])): ?>
                                    <img src="<?= base_url('public/uploads/categories/' . $category['category_image']); ?>" alt="Category Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="category_image" class="form-label">New Category Image:</label>
                                <input type="file" class="form-control" id="category_image" name="category_image" style="height:10%">
                            </div>
                            <!--<div class="mb-3">-->
                            <!--    <label for="description" class="form-label">Description:</label>-->
                            <!--    <textarea id="description" name="description" rows="2" cols="110"><?= $category['description']; ?></textarea>-->
                            <!--</div>-->
                            <div class="mb-3">
                               <!--<textarea class="form-control" id="editor" name="description"></textarea>-->
                               <label for="description" class="form-label">Description:</label>
                               <textarea id="editor" name="description"><?=$category['description'];?></textarea>
                                <script>
                              CKEDITOR.replace('editor');
                            </script>
                                </div>
                                <div class="mb-3">
                                  <label>Type <span class="red">*</span></label>
                                    <select class="form-control "  name="type" id="type" >
                                        <?php if($category['type']== null){ ?>
                                          <option >Select Type</option>
                                       <?php } ?>
                                      <option value = 'SIMPLE' <?php if($category['type'] == 'SIMPLE'){echo "selected";}?>>SIMPLE</option>
                                      <option value = 'PROGRESS_BAR' <?php if($category['type'] == 'PROGRESS_BAR'){echo "selected";}?>>PROGRESS_BAR</option>
                                      
                                    </select>
                                </div>
                            
                            <button type="submit" class="btn btn-primary" style="width:10%">Update Category</button>
                        </form>
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->
<!--</main>-->
<!-- End #main -->
<?php include('include/newadmin-footer.php'); ?>

