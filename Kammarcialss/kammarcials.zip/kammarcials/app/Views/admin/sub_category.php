<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
.breadcrumb-item a {
    float: right;
}
.dataTables_filter {
    float: right;
    margin-top:-25px;
}
</style>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Add Sub Category Database</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Add Sub Category</li>
<p style="margin-left: auto;" class="breadcrumb-item"><a href="<?= base_url('admin/sub_category/add_sub_category'); ?>" class="btn btn-primary" style="width: 12%;">Add Subcategory</a></p>                        
                    </ul>
                </div>
                
                <!-- Breadcubs Area End Here -->
                <!-- Student Table Area Start Here -->
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>List Name of  Sub Category</h3>
                            </div>
                           
                        </div>
                        <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                        <div class="table-responsive">
                            <table id="userTable" class="table display data-table text-nowrap">
                                <thead>
                <tr>
                    <th>#</th>
                    <th>Category Name</th>
                    <th>Sub Category Name</th>
                    <th>Image</th>
                     <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($progress_workout as $doctor): ?>
                    <tr>
                        <td><?= $doctor['id']; ?></td>
                        <td><?php 
                        $cid = $doctor['category_id'];
                       
                        $db  = \Config\Database::connect();
                        
                        $builder = $db->table('categories');
                        
                        $datac = $builder->where('category_id', $cid)->get()->getResultArray();
                        echo $datac[0]['category_name']; 
                        
                        ?></td>
                        <td><?= $doctor['name']; ?></td>
                        
                        <td>
                            <?php if (!empty($doctor['image'])): ?>
                                <img src="<?= base_url('public/uploads/sub_categories/' . $doctor['image']); ?>" alt="Doctor Image" class="user-image" width="50" height="50">
                                <?php else: ?>
                <img src="<?= base_url('public/uploads/users/dummy-profile-pic.jpg'); ?>" alt="Default Image" class="user-image" width="50" height="50">
                              <?php endif; ?>
                        </td>
                        <td><?= $doctor['description']; ?></td>
                        
                       <td>
                            <a href="<?= base_url('admin/sub_category/edit/' . $doctor['id']); ?>" class="btn btn-sm btn-primary">Edit</a>
                        <?php /* <a href="<?= base_url('admin/category/delete/' . $category['category_id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this entry?');">Delete</a> */ ?>
                        <a href="#" class="btn btn-sm btn-danger delete-doctors" data-doctors-id="<?= $doctor['id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
                            </table>
                        </div>
                    </div>
                </div>

<?php include('include/newadmin-footer.php'); ?>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTable on the userTable -->
<script>
    $(document).ready(function () {
        $('#userTable').DataTable();
    });
</script>

<!-- Add this in your HTML file to include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    // Use SweetAlert for category deletion confirmation
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.delete-doctors').forEach(function (deleteButton) {
            deleteButton.addEventListener('click', function (event) {
                event.preventDefault();

                // Get the category ID from the data attribute
                var doctorsId = this.getAttribute('data-doctors-id');

                // Show the confirmation popup
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You won\'t be able to revert this!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // If confirmed, redirect to the delete URL
                        window.location.href = '<?= base_url('admin/sub_category/delete/'); ?>' + doctorsId;
                    }
                });
            });
        });
    });
</script>