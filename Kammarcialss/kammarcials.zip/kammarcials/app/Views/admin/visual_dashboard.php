<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
            <div class="dashboard-content-one">
                
                <?php 
                
                   $db = \Config\Database::connect(); //
                
                  $fetch = $db->query(" SELECT COUNT(*) as tuser FROM `users` WHERE `type` = 'User' ")->getResultArray();
                  $udata =  $fetch[0]['tuser'];
                  
                  $fetch = $db->query("SELECT SUM(`amount`) as tamount FROM `withdraw` WHERE `status` = 'Confirm' ")->getResultArray();
                  $pdata =  $fetch[0]['tamount'];

                
                
                ?>
                
                 <div class="row">
                      <!-- Breadcubs Area End Here -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-sx-12 ">
                        <div class="card mt-5"><h4>Visual Dashboard</h4></div>
                        </div>
                        
                        <!-- Breadcubs Area Start Here -->
                        
                        
                   <div class="col-lg-12 col-md-12 col-sm-12 col-sx-12 mb-5">  
                   <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12 ">
            <div class="dd_box1  p-4 text-center" style="background: #483693;border-radius: 0.5rem;box-shadow: 0px 0px 0px #000;">
                            <h2 class="text-white font-weight-bold mb-1">Total Users</h2>
                            <h2 class="text-white"><?=$udata?></h2>
                        </div>

                    </div>
                    
                    <div class="col-lg-6 col-md-6 col-sm-6 col-sx-12 ">
            <div class="dd_box1  p-4 text-center" style="background: #E91E63;border-radius: 0.5rem;box-shadow: 0px 0px 0px #000;">
                            <h2 class="text-white font-weight-bold mb-1">Total Withdraw Amount</h2>
                            <h2 class="text-white"><?=$pdata?></h2>
                        </div>

                    </div>
                    </div>
               </div>
                
                        
                        
                         <!-- Dashboard Content Start Here -->
                        <div class="col-lg-6 col-md-6 ">
                             
                    <div class="card">
                        
                        <div class="card-header bg-white"> <h4 class="mb-0">Users Vs. Customers Analytics</h4></div>
                         <div class="card-body">
                        
                           <canvas id="canvas" style="width:100%;max-width:100%"></canvas>
                       
                        </div>
                
                   </div>
                   </div>
                    <div class="col-lg-6 col-md-6">
                             
                    <div class="card">
                        
                        <div class="card-header bg-white"> <h4 class="mb-0">Growth in money distributions</h4></div>
                    <div class="card-body">
                        
                     <canvas id="myChart1" style="width:100%;max-width:100%"></canvas>

                       
                      </div>
                
                   </div>
                   </div>
                   
                   <div class="col-12 col-xl-12 col-6-xxxl lefttable">
                        <div class="card dashboard-card-one pd-b-20">
                            <div class="card-body">
                                <div class="heading-layout1">
                                    <div class="item-title">
                                        <h3> Recently Added User</h3>
                                    </div>
                                   
                                </div>
                                <div class="earning-report">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                 <th>Sr. No.</th>
                                                <th>User Name</th>
                                                <th>Date & Time</th>
                                                <th>Result</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                             $db = \Config\Database::connect();
                                            $current_date = date("Y-m-d");
                                            $i = 1;
                                             $fetch = $db->query(" SELECT * FROM `users` WHERE date(`created_at`) = '$current_date' ")->getResultArray();
                                            foreach($fetch as $li)
                                           { ?>
                                            <tr>
                                                <td><?=$i++;?></td>
                                                <td><?=$li['user_name'];?></td>
                                                <td><?=$li['created_at'];?></td>
                                                <td ><a href="<?php echo base_url('admin/users/view'); ?>/<?=$li['id'];?>"><img src="<?php echo base_url(); ?>public/newadmin/img/eye.png" style="width:24px;"/></a></td>
                                            </tr>
                                            <?php }?>
                                            <!-- <tr>-->
                                            <!--    <td>Mental Health Asessement</td>-->
                                            <!--    <td>23/10/2023 4.00 pm</td>-->
                                            <!--    <td align="center"><img src="<?php echo base_url(); ?>public/newadmin/img/eye.png" style="width:24px;"/></td>-->
                                            <!--</tr>-->
                                            <!-- <tr>-->
                                            <!--    <td>Prediabetes Asessment</td>-->
                                            <!--    <td>23/10/2023 4.00 pm</td>-->
                                            <!--    <td align="center"><img src="<?php echo base_url(); ?>public/newadmin/img/eye.png" style="width:24px;"/></td>-->
                                            <!--</tr>-->
                                        </tbody>
                                    </table>
                                </div>
                               
                            </div>
                        </div>
                       
                        
                        
                    </div>
                   
                   <!--<div class="col-lg-6 col-md-6">-->
                             
                   <!-- <div class="card">-->
                        
                   <!--     <div class="card-header bg-white"> <h4 class="mb-0">Market penetration across different regions</h4></div>-->
                   <!-- <div class="card-body">-->
                   <!--     <canvas id="myChart" style="width:100%;max-width:100%"></canvas>-->
                     
                       
                   <!--   </div>-->
                
                   <!--</div>-->
                   <!--</div>-->
                   
                   <!-- Dashboard Content End Here -->
                   
                   </div>
                
            <?php 
              
       $db = \Config\Database::connect();
       $currentYear = date("Y");
       $monthDates = array();

       for ($month = 1; $month <= 12; $month++) {
        // Generate the first day of the month
        $startDate = date("Y-m-01", strtotime("$currentYear-$month-01"));
        
        // Generate the last day of the month
        $endDate = date("Y-m-t", strtotime("$currentYear-$month-01"));
        
         $result = $db->query("SELECT  id FROM users WHERE `created_at` BETWEEN '$startDate' AND  '$endDate' ")->getResultArray();
    
    
        // Add the start and end dates to the array
        $monthDates[] = array("start_date" => $startDate, "end_date" => $endDate, "count" =>  count($result));
    }

    //   $countString = '"' . implode('", "', array_column($monthDates, 'count')) . '"';
       $countString = implode(', ', array_column($monthDates, 'count'));

              ?>
              
               <?php 


              
       $db = \Config\Database::connect();
       $currentYear1 = date("Y");
       $monthDates1 = array();

       for ($month = 1; $month <= 12; $month++) {
        // Generate the first day of the month
        $startDate = date("Y-m-01", strtotime("$currentYear1-$month-01"));
        
        // Generate the last day of the month
        $endDate = date("Y-m-t", strtotime("$currentYear1-$month-01"));
        
         $result1 = $db->query("SELECT * FROM `survey_answer_history` WHERE `date_time` BETWEEN '$startDate' AND  '$endDate' ")->getResultArray();
    
    
        // Add the start and end dates to the array
        $monthDates1[] = array("start_date" => $startDate, "end_date" => $endDate, "count" =>  count($result1));
    }

    //   $countString = '"' . implode('", "', array_column($monthDates, 'count')) . '"';
       $countString123 = implode(', ', array_column($monthDates1, 'count'));

              ?>
              
              
               <?php 
              
     
       $currentYearb = date("Y");
       $monthDatesn = array();

       for ($month = 1; $month <= 12; $month++) {
        // Generate the first day of the month
        $startDate = date("Y-m-01", strtotime("$currentYearb-$month-01"));
        
        // Generate the last day of the month
        $endDate = date("Y-m-t", strtotime("$currentYearb-$month-01"));
        
         $result4 = $db->query("SELECT  COALESCE(SUM(amount), 0) AS sum_amount FROM survey_answer_history_transaction WHERE `date_time` BETWEEN '$startDate' AND  '$endDate' ")->getResultArray();
    
    
        // Add the start and end dates to the array
        $monthDatesn[] =  array("start_date" => $startDate, "end_date" => $endDate, "sum" =>@$result4[0]['sum_amount']);
    }
    
    // echo '<pre>';
    // print_r($monthDatesn);
    // echo '</pre>';

    //   $countString = '"' . implode('", "', array_column($monthDates, 'count')) . '"';
       $countString1234 = implode(', ', array_column($monthDatesn, 'sum'));

              ?>
                
  <script>
var barChartData = {
  labels: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  datasets: [
    {
      label: "Users",
      backgroundColor: "pink",
      borderColor: "red",
      borderWidth: 1,
    //   data: [30, 50, 60, 70, 32, 40, 41, 44, 35, 55, 42, 30]
     data: [<?=$countString?>]
    },
    {
      label: "Customers (Survey User)",
      backgroundColor: "lightblue",
      borderColor: "blue",
      borderWidth: 1,
    //   data: [25, 40, 50, 65, 45, 43, 22, 37, 49, 12, 60, 47]
    data: [<?=$countString123?>]
    }
    
    
  ]
};

var chartOptions = {
  responsive: true,
  legend: {
    position: "top"
  },
  title: {
    display: true,
    text: "Chart.js Bar Chart"
  },
  scales: {
    yAxes: [{
      ticks: {
        beginAtZero: true
      }
    }]
  }
}

window.onload = function() {
  var ctx = document.getElementById("canvas").getContext("2d");
  window.myBar = new Chart(ctx, {
    type: "bar",
    data: barChartData,
    options: chartOptions
  });
};

</script>
<script>
const xValues = ["Italy", "France", "Spain", "USA", "Argentina"];
// const yValues = [55, 49, 44, 24, 15];

const yValues = [<?=$countString1234?>];

const barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145"
];

new Chart("myChart", {
  type: "pie",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Money Distribution in region"
    }
  }
});
</script>
<script>
const xValues1 = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
// const yValues1 = [200,150,266,380,470,590,660,789,570,850,740,888];
const yValues1 = [<?=$countString1234?>];

new Chart("myChart1", {
  type: "line",
  data: {
    labels: xValues1,
    datasets: [{
      fill: false,
      lineTension: 0,
      backgroundColor: "blue",
      borderColor: "yellow",
      data: yValues1
    }]
  },
  options: {
    legend: {display: false},
    scales: {
      yAxes: [{ticks: {min: 0, max:500}}],
    }
  }
});
</script>

           
<?php include('include/newadmin-footer.php'); ?>                