<!-- edit_user.php -->
<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Update Admin Profile</h3>
                  
                        
        <p class="breadcrumb-item"><a href="<?= base_url('admin/dashboard'); ?>" class="btn btn-primary">Back</a></p>
 
                        <h5 class="card-title">Update Admin Profile</h5>
                        
                        
                        <?php if (session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?= session('success') ?>
                            </div>
                        <?php elseif (session()->has('errors')): ?>
                            <div class="alert alert-danger">
                                <?php
                                $errors = session('errors');
                                if (is_array($errors)) {
                                    foreach ($errors as $error) {
                                        echo $error . '<br>';
                                    }
                                } else {
                                    echo $errors;
                                }
                                ?>
                            </div>
                        <?php endif; ?>
                        
                         <form method="POST" action="<?= base_url('admin/update-profile'); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for user data editing -->
                            <input type="hidden"  class="form-control" name="admin_id" value="<?=$user['admin_id'];?>">
                           
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" name="admin_email" value="<?= $user['admin_email']; ?>">
                            </div>
                         <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                     
                     <div class="breadcrumbs-area">
                      <h5 class="card-title">Update Admin Password</h5>
                        
                        <form method="POST" action="<?= base_url('admin/update-profile-password'); ?>">
                            <input type="hidden" class="form-control" name="admin_id" value="<?= $user['admin_id']; ?>">
                           <div class="mb-3">
                                <label for="password" class="form-label">New Password:</label>
                                <input type="password" class="form-control" name="admin_password" required minlength="6">
                            </div>
                        
                            <div class="mb-3">
                                <label for="c_password" class="form-label">Confirm Password:</label>
                                <input type="password" class="form-control" name="c_password" required>
                            </div>
                        
                            <button type="submit" class="btn btn-primary" style="width:12%;">Update Password</button>
                        </form>

                        
<?php include('include/newadmin-footer.php'); ?>

