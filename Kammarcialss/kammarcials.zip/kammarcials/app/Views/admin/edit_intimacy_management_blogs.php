<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Edit Intimacy Management Blogs</h3>
                   
        <p class="breadcrumb-item"><a href="<?= base_url('admin/intimacy_management_blogs'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title">Update Intimacy Management Blogs</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/intimacy_management_blogs/update/' . $sonography_ultrasounds['imb_id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                           <input type="hidden"  class="form-control" name="imb_id" value="<?=$sonography_ultrasounds['imb_id'];?>">
                           
                           
                           
                           <div class="mb3">
                                <label>Intimacy Management Category: <span class="red">*</span></label>
                                <select class="form-control " name="imb_intimacy_management_categories_id" id="">
                                    <?php
                                    $db = \Config\Database::connect();
                                    $builder = $db->table('intimacy_management_categories');
                                    $query = $builder->select('imc_id, imc_name')->get();
                                    $results = $query->getResultArray();
                                    echo '<option value="" disabled>Select forum Description</option>';
                                   
                                        foreach ($results as $user) { ?>
                                            <option value="<?= $user['imc_id']; ?>" <?php if ($user['imc_id'] == $sonography_ultrasounds['imb_intimacy_management_categories_id']) {
                                                echo 'selected';
                                            } ?>>
                                                <?= $user['imc_name']; ?></option>
                                        <?php }
                                     ?>
                                </select>
                            </div>
                            
                    
                           
                            <div class="mb-3">
                                <label for="title" class="form-label">Title:</label>
                                <input type="text" class="form-control" name="imb_title" value="<?= $sonography_ultrasounds['imb_title']; ?>">
                            </div>
                            
                            <!--<div class="mb-3">-->
                            <!--    <label for="title" class="form-label">Description:</label>-->
                            <!--    <input type="text" class="form-control" name="imb_description" value="<?= $sonography_ultrasounds['imb_description']; ?>">-->
                            <!--</div>-->
                            
                            <div class="mb-3">
                           <label for="description" class="form-label">Description:</label>
                           <textarea id="editor" name="imb_description"><?= $sonography_ultrasounds['imb_description']; ?></textarea>
                            <script>
                              CKEDITOR.replace('editor');
                            </script>
                            </div>
                            
                            
                            <div class="mb-3">
                                <label for="existing_image" class="form-label">Existing Image:</label>
                                <?php if (!empty($sonography_ultrasounds['imb_image']) && file_exists(ROOTPATH . 'public/uploads/intimacy_management_blogs/' . $sonography_ultrasounds['imb_image'])): ?>
                                    <img src="<?= base_url('public/uploads/intimacy_management_blogs/' . $sonography_ultrasounds['imb_image']); ?>" alt="Product Image" width="150" height="150">
                                <?php else: ?>
                                    <p>No existing image</p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="product_image" class="form-label">New Image:</label>
                                <input type="file" class="form-control" id="imb_image" name="imb_image" style="height:10%">
                            </div>
                            
                            
                            
                            <button type="submit" class="btn btn-primary" style="width:17%;">Update Intimacy Management Blogs</button>
                        </form>

<?php include('include/newadmin-footer.php'); ?>
