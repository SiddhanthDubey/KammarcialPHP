<?php include('include/newadmin-header.php'); ?>
<?php include('include/newadmin-sidebar.php'); ?>
<style>
    .breadcrumb-item {
    margin-left: auto;
}

.breadcrumb-item a {
    float: right;
}
  #inputField:disabled {
            font-weight: bold;
            /* Add any other styling as needed */
        }
</style>

<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>

<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Admin Employee Leave</h3>
                   
        <p class="breadcrumb-item"><a href="<?= base_url('admin/forum_categories'); ?>" 
        class="btn btn-primary" style="margin-top:-50px;">Back</a></p>
                </div>
                    <?php if (session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?= session('success') ?>
                        </div>
                    <?php elseif (session()->has('errors')): ?>
                        <div class="alert alert-danger">
                            <?php if (is_array(session('errors'))): ?>
                                <ul>
                                    <?php foreach (session('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <?= session('errors') ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
                        <h5 class="card-title"> Employee Leave</h5>
                        
                        <!-- Form for adding a new user -->
                        <form method="POST" action="<?= base_url('admin/forum_categories/update/' . $sonography_ultrasounds['li_id']); ?>" enctype="multipart/form-data">
                            <!-- Add your form fields for new user data -->
                           <input type="hidden"  class="form-control" name="li_id" value="<?=$sonography_ultrasounds['li_id'];?>">
                           
                           
                            
                             <div class="mb-3">
                                <label for="title" class="form-label">Employee Name:</label>
                                <input type="text" disabled class="form-control" name="user_id" value="<?php $uid =  $sonography_ultrasounds['user_id'];
                                 $db = \Config\Database::connect();
                                    $builder = $db->table('users');
                                    $query = $builder->select('id, user_name')->where('id',$uid)->get();
                                    $results = $query->getResultArray();
                                    foreach ($results as $user) {
                                    
                                        echo $user['user_name'];
                                    }
                                ?>">
                            </div>
                            
                           
                            <div class="mb-3">
                                <label for="title" class="form-label">From leave Date:</label>
                                <input type="text" class="form-control" name="leave_from_date" value="<?php
                                $datetimeString = $sonography_ultrasounds['leave_from_date'];
                                $dateTime = new DateTime($datetimeString);
                                
                               echo $dateOnly = $dateTime->format("Y-m-d");

                                 ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="title" class="form-label">To leave Date:</label>
                                <input type="text" class="form-control" name="leave_to_date" value="<?php  
                                
                         
                                $datetimeString1 = $sonography_ultrasounds['leave_to_date'];
                                $dateTime1 = new DateTime($datetimeString1);
                                
                               echo $dateOnly1 = $dateTime1->format("Y-m-d");

                                ?>">
                            </div>
                            
                             <div class="mb-3">
                                <label for="title" class="form-label">Reason:</label>
                                <input type="text" class="form-control" name="reason" value="<?= $sonography_ultrasounds['reason']; ?>">
                            </div>
                            
                            <div class="mb-3">
                                  <label style=" color: #1c4fc3; font-weight: bold;">Administrator Reply <span class="red">*</span></label>
                                    <select class="form-control "  id="selectOption" onchange="showAlert()"  name="status" required >
                                      
                                      <option value = 'Pending' <?php if($sonography_ultrasounds['status'] == 'Pending'){echo "selected";}?>>Pending</option>
                                      <option value = 'Reject' <?php if($sonography_ultrasounds['status'] == 'Reject'){echo "selected";}?>>Reject</option>
                                      <option value = 'Accept' <?php if($sonography_ultrasounds['status'] == 'Accept'){echo "selected";}?>>Accept</option>
                                      
                                    </select>
                                </div>
                            
                             <div class="mb-3">
                                <label for="title" class="form-label" style=" color: #1c4fc3; font-weight: bold;">Admin Reply:</label>
                                <input type="text" id="inputField" required class="form-control" name="admin_reply" value="<?= $sonography_ultrasounds['admin_reply']; ?>">
                            </div>
                            
                            
                            <button type="submit" class="btn btn-primary"  style="width:180px;">Reply</button>
                        </form>

<?php include('include/newadmin-footer.php'); ?>
<script>
    // JavaScript function to show alert on dropdown change
    function showAlert() {
        
          var selectedValue = document.getElementById('selectOption').value;
        var inputField = document.getElementById('inputField');

        // Enable or disable the input field based on the selected value
        inputField.disabled = (selectedValue === 'Accept');
        
       inputField.style.borderColor = (selectedValue === 'Accept') ? 'lightgreen' : 'lightcoral';

    }
</script>
