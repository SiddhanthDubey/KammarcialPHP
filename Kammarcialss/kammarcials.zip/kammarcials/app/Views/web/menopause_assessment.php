<!DOCTYPE html>
<html lang="en">
<head>
  <title>Menopause Assessment</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity = "sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin = "anonymous">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
    body{
      font-family: 'Rubik', sans-serif;
          background: #ddd;
    }
    b, strong {
    font-weight: 500;
    }
    .bg-dark {
    background-color: #115571!important;
    }
    .radiobox{
      position: relative;
     padding-left: 35px;
     margin-bottom: 12px;
     cursor: pointer;
     font-size: 16px;
     -webkit-user-select: none;
     -moz-user-select: none;
     -ms-user-select: none;
    user-select: none;
    }
    /* Hide the browser's default radio button */
.radiobox input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.radiobox:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.radiobox input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.radiobox input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.radiobox .checkmark:after {
  top: 6px;
  left: 6px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
.bsd{
  border-bottom:1px solid #f3eeee;
}
.btn-primary{
  background-color:#115571 !important;
   border-color:#115571 !important;
   font-size:20px !important;
    border-radius:50px;
}
 
  </style>

</head>
<body>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Menopause Assessment
</a>
  
  
</nav>

<div class="container" style="margin-top:50px; margin-bottom:50px">
  <div class="row justify-content-center">
  <div class="col-lg-8">
    <form>
      <div class="card">
        <div class="card-header">
         <h6 class="mb-0">Menopause Assessment</h6>
         </div>
         <div class="card-body">
         <div class="row">
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q1. Does your heart beat quickly or strongly?</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio1" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio1" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio1" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio1" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q1. Are you feeling tense or nervous?</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio2" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio2" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio2" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio2" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q3. Do you have difficulty sleeping?</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio3" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio3" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio3" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio3" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q4. Do  you feel  'excited?' </strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio4" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio4" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio4" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio4" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q5. Do you have attacks of anxiety or panic? </strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio5" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio5" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio5" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio5" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q6. Have you noticed difficulty concentrating?</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio6" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio6" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio6" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio6" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q7. Are you feeling tired and lacking in energy?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio7" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio7" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio7" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio7" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q8. Have you lost interest in most things?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio8" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio8" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio8" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio8" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q9. Are you feeling unhappy or depressed?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio9" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio9" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio9" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio9" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q10. Are you experiencing crying spells?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio10" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio10" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio10" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio10" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q11. Are you more irritable?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio11" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio11" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio11" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio11" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>
           
           

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q12. Have you been feeling dizzy or faint?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio12" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio12" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio12" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio12" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q13. Do you experience pressure or tightness in your head?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio13" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio13" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio13" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio13" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q14. Have you noticed that parts of your body feel numb?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio14" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio14" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio14" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio14" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q15. Have you noticed that you have headaches?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio15" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio15" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio15" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio15" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q16. Do you have muscle aches and joint pains?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio16" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio16" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio16" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio16" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q17. Have you noticed a loss of feeling in your hands or feet?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio17" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio17" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio17" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio17" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q18. Are you experiencing breathing difficulties?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio18" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio18" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio18" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio18" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q19. Do you have hot flushes?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio19" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio19" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio19" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio19" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q20. Do you sweat at night?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio20" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio20" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio20" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio20" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q21. Have you lost interest in sex?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio21" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio21" value="1"> A little <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio21" value="2"> Quite a bit<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio21" value="3"> Extremely  <span class="checkmark"></span></label>
           </div>


           <div class="col-lg-12 form-group bsd">
            <button type="submit" name="submit" class="btn btn-primary w-100">Submit</button>
           </div>

         </div>
        </div>
       </div>
     </form>
  </div>
  </div>
</div>

<!-- <div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div> -->

</body>
</html>
