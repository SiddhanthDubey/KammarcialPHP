<!DOCTYPE html>
<html lang="en">
<head>
  <title>QUIZ PCOS TYPE</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity = "sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin = "anonymous">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
    body{
      font-family: 'Rubik', sans-serif;
          background: #ddd;
    }
    .bg-dark {
    background-color: #115571!important;
    }
    b, strong {
    font-weight: 500;
    }
    .radiobox{
      position: relative;
     padding-left: 35px;
     margin-bottom: 12px;
     cursor: pointer;
     font-size: 16px;
     -webkit-user-select: none;
     -moz-user-select: none;
     -ms-user-select: none;
    user-select: none;
    }
    /* Hide the browser's default radio button */
.radiobox input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.radiobox:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.radiobox input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.radiobox input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.radiobox .checkmark:after {
  top: 6px;
  left: 6px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
.bsd{
  border-bottom:1px solid #f3eeee;
}
.btn-primary{
  background-color:#115571 !important;
   border-color:#115571 !important;
   font-size:20px !important;
    border-radius:50px;
}
 
  </style>

</head>
<body>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">QUIZ PCOS TYPE</a>
  
  
</nav>

<div class="container" style="margin-top:50px; margin-bottom:50px">
  <div class="row justify-content-center">
  <div class="col-lg-8">
    <form>
      <div class="card">
        <div class="card-header">
         <h6 class="mb-0">QUIZ PCOS TYPE</h6>
         </div>
         <div class="card-body">
         <div class="row">
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q1. I have dark spots in my skin folds (acanthosis nigricans)</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio1" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio1" value="0"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q2. I want to eat sweet food during the day</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio2" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio2" value="0"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q3. I often feel tired after eating</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio3" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio3" value="0"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q4.I'm very hungry if I haven't eaten for three hours (or I feel angry, agitated or foggy when I haven't eaten)</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio4" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio4" value="0"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q5. I feel like I always need something sweet after a meal (even if I'm full)</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio5" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio5" value="0"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q6. I crave stimulants like coffee after meals</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio6" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio6" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q7. I easily gain weight in the abdominal area or find it difficult to lose weight in this area</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio7" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio7" value="0"> No  <span class="checkmark"></span></label>
           </div>

            <div class="col-lg-12 form-group bsd">
            <label><strong>Q8. I have a family history of diabetes or pre-diabetes</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio8" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio8" value="0"> No  <span class="checkmark"></span></label>
           </div>

            <div class="col-lg-12 form-group bsd">
            <label><strong>Q9. Waist circumference over 80cm (32 inches)</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio9" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio9" value="0"> No  <span class="checkmark"></span></label>
           </div>

            <div class="col-lg-12 form-group bsd">
            <label><strong>Q10. I have been told I have pre-diabetes, or that I have high fasting insulin or high glucose levels on my blood test result</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio10" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio10" value="0"> No  <span class="checkmark"></span></label>
           </div>

            <div class="col-lg-12 form-group bsd">
            <label><strong>Q11. I have been under a lot of stress for the past five years</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio11" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio11" value="0"> No  <span class="checkmark"></span></label>
           </div>

            <div class="col-lg-12 form-group bsd">
            <label><strong>Q12. I feel that I overreact to situations that stress me out and require me to take a long time to recover.</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio12" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio12" value="0"> No  <span class="checkmark"></span></label>
           </div>

            <div class="col-lg-12 form-group bsd">
            <label><strong>Q13. I experienced chronic stress during early puberty or I was involved in extreme dieting during early puberty</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio13" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio13" value="0"> No  <span class="checkmark"></span></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q14. I have normal testosterone in blood test, but  have PCOS Symptoms
</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio14" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio14" value="0"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q15. I have a high DHEAS reading in a blood test or urine test
</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio15" value="1"> Yes  <span class="checkmark"></span></label>
            <label class="radiobox"><input type="radio" name="radio15" value="0"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q16. I find I have more energy after six in the evening or before bed
</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio16" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio16" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q17. I rely on caffeine or other stimulants for energy.</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio17" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio17" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q18. I still wake up and feel tired even after sleeping for 7 hours.</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio18" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio18" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q19. I do moderate to high intensity exercise (running, HIIT, cross fit, boxing) more than six hours a week.</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio19" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio19" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q20. I will feel a headache when I am stressed or tired</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio20" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio20" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q21. Weight gain is not one of my symptoms.</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio21" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio21" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q22. My symptoms started after I stopped using birth control pills (or Depo shots, implants, or IUDs)</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio22" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio22" value="0"> No<span class="checkmark"></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q23. I have chronic digestive problems such as bloating, IBS, SIBO, constipation, diarrhea, reflux or gas</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio23" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio23" value="0"> No<span class="checkmark"></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q24. I have food allergies or a chronic skin condition such as eczema, rosacea, or hives</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio24" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio24" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q25. I have autoimmune conditions such as Hashimoto's, psoriasis,or celiac disease (or a family history of this condition)</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio25" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio25" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q26. I was diagnosed with endometriosis</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio26" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio26" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q27. My blood test showed low vitamin D levels</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio27" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio27" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q28. My blood tests show elevated markers of inflammation (eg, CRP), thyroid antibodies or gluten antibodies</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio28" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio28" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q29. My blood test showed high iron or ferritin levels</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio29" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio29" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q30. My blood tests show abnormal thyroid hormones or I have been diagnosed with hyper or hypothyroidism</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio30" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio30" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q31. I have unexplained headaches, migraines, or fatigue</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio31" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio31" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q32. I have chronic and painful muscle or joint pain or muscle weakness</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio32" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio32" value="0"> No<span class="checkmark"></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q33. I have mood swings or depression</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio33" value="1"> Yes<span class="checkmark"></label>
            <label class="radiobox"><input type="radio" name="radio33" value="0"> No<span class="checkmark"></label>
           </div>
           <div class="col-lg-12 form-group bsd">
            <button type="submit" name="submit" class="btn btn-primary w-100">Submit</button>
           </div>

         </div>
        </div>
       </div>
     </form>
  </div>
  </div>
</div>

<!-- <div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div> -->

</body>
</html>
