<!DOCTYPE html>
<html lang="en">
<head>
  <title>Male Fertility</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity = "sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin = "anonymous">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
    body{
      font-family: 'Rubik', sans-serif;
          background: #ddd;
    }
    b, strong {
    font-weight: 500;
    }
    .bg-dark {
    background-color: #115571!important;
    }
    .radiobox{
      position: relative;
     padding-left: 35px;
     margin-bottom: 12px;
     cursor: pointer;
     font-size: 16px;
     -webkit-user-select: none;
     -moz-user-select: none;
     -ms-user-select: none;
    user-select: none;
    }
    /* Hide the browser's default radio button */
.radiobox input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.radiobox:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.radiobox input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.radiobox input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.radiobox .checkmark:after {
  top: 6px;
  left: 6px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
.bsd{
  border-bottom:1px solid #f3eeee;
}
.btn-primary{
  background-color:#115571 !important;
   border-color:#115571 !important;
   font-size:20px !important;
   border-radius:50px;
}
 
  </style>

</head>
<body>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Male Fertility
</a>
  
  
</nav>

<div class="container" style="margin-top:50px; margin-bottom:50px">
  <div class="row justify-content-center">
  <div class="col-lg-8">
    <form>
      <div class="card">
        <div class="card-header">
         <h6 class="mb-0">Male Fertility</h6>
         </div>
         <div class="card-body">
         <div class="row">
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q1. Why do you want to check your fertility condition?</strong></label><br>
           
            <label class="mr-5 radiobox"><input type="radio" name="radio1" value="3"> I am a man who is curious about my fertility<span class="checkmark"></span></label><br>
            
            <label class="radiobox"><input type="radio" name="radio1" value="2"> I am a man who is actively trying to get pregnant with my partner<span class="checkmark"></span></label><br>
          
            <label class="radiobox"><input type="radio" name="radio1" value="1"> I am a man with fertility problems<span class="checkmark"></span></label><br>
          
            <label class="radiobox"><input type="radio" name="radio1" value="0"> I want to know about the quality of my partner's sperm  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q2. How old are you?</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio2" value="2"> Below 40
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio2" value="1"> Above 40 <span class="checkmark"></span></label><br>
           
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q3. What is your BMI?</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio3" value="4"> Between 18,5-24
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio3" value="3"> Between 25-29<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio3" value="2"> Between 30-34
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio3" value="1"> More than 35
             <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q4. How many times a week do you eat fast food?</strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio4" value="3"> Never
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio4" value="2"> 1-3 a week<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio4" value="1"> More than 4 times a week<span class="checkmark"></span></label><br>
           
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q5. How many times a week do you eat vegetables? </strong></label><br>
            <label class="mr-5 radiobox"><input type="radio" name="radio5" value="3"> Every day
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio5" value="2"> 1-3 times a week <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio5" value="1"> Never<span class="checkmark"></span></label><br>
            
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q6. How often do you eat sugary snacks or sugary water?</strong></label><br>
           <label class="mr-5 radiobox"><input type="radio" name="radio6" value="3"> Never
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio6" value="2"> 1-3 a week<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio6" value="1"> More than 4 times a week<span class="checkmark"></span></label><br>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q7. Do you take any fertility supplements?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio7" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio7" value="3"> Yes - Fertility supplement<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio7" value="2"> Yes - Supplements are not for fertility<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio7" value="1"> No  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q8. Do you feel stressed and worried?</strong></label><br>
             <label class="mr-5 radiobox"><input type="radio" name="radio8" value="0"> Not at all
            <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio8" value="3"> No <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio8" value="2"> Yes, sometimes<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio8" value="1"> Yes, always  <span class="checkmark"></span></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q9. How many times a week do you exercise?</strong></label><br>
           
            <label class="radiobox"><input type="radio" name="radio9" value="3"> 1-4 times a week<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio9" value="2"> Several times a month<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio9" value="1"> Several times a month  <span class="checkmark"></span></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q10. Are your private parts exposed to heat from cell phones, hot blankets, hot tubs or radiators?</strong></label><br>
             
            <label class="radiobox"><input type="radio" name="radio10" value="3"> No <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio10" value="2"> Yes, sometimes
<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio10" value="1"> Yes, several times a day  <span class="checkmark"></span></label>
           </div>
           
           <div class="col-lg-12 form-group bsd">
            <label><strong>Q11. Do you smoke?</strong></label><br>
             <label class="radiobox"><input type="radio" name="radio11" value="3"> No <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio11" value="2"> Yes, sometimes
<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio11" value="1"> Yes, several times a day  <span class="checkmark"></span></label>
           </div>
           
           

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q12. How much alcohol do you drink a week? One unit is equivalent to 12g of alcohol. Equal to half a cup of beer/wine.</strong></label><br>
             
            <label class="radiobox"><input type="radio" name="radio12" value="3"> Do not take or less than 7 units per week <span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio12" value="2"> In 7-14 units per week<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio12" value="1"> More than 14 units per week  <span class="checkmark"></span></label>
           </div>

           <div class="col-lg-12 form-group bsd">
            <label><strong>Q13. Do you know your sperm quality?</strong></label><br>
            
            <label class="radiobox"><input type="radio" name="radio13" value="2"> Yes, I know my sperm quality<span class="checkmark"></span></label><br>
            <label class="radiobox"><input type="radio" name="radio13" value="1"> Nope  <span class="checkmark"></span></label>
           </div>


           <div class="col-lg-12 form-group bsd">
            <button type="submit" name="submit" class="btn btn-primary w-100">Submit</button>
           </div>

         </div>
        </div>
       </div>
     </form>
  </div>
  </div>
</div>

<!-- <div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div> -->

</body>
</html>
