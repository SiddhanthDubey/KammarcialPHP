<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
</head>
<body>
    

    <form action="index.php" method="post">
                    <input type="submit" value="Save">

        <textarea id="editor" name="editor_content" >
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Get the content from the POST request
                $content = $_POST['editor_content'];

                // Specify the file name where you want to save the content
                $file = 'content.txt';

                // Open the file for writing (you can use 'w' to overwrite or 'a' to append)
                $fileHandle = fopen($file, 'w');

                if ($fileHandle === false) {
                    die('Unable to open the file for writing.');
                }

                // Write the content to the file
                fwrite($fileHandle, $content);

                // Close the file
                fclose($fileHandle);
            }

            // Read and display the content from the file
            $file = 'content.txt';

            if (file_exists($file)) {
                $content = file_get_contents($file);
                echo $content;
            }
            ?>
        </textarea>
    </form>


    <script>
        CKEDITOR.replace('editor', {
            height: 1000, // You can set the height in pixels.
            colorButton_colors: 'CF5D4E,454545,FFF,DDD,CCEAEE,66AB16'

        });
    </script>
</body>
</html>