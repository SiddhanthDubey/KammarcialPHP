<p><strong>Privacy Policy</strong></p>
<p>This Privacy Policy describes how FERTILITYMATE] ("us," "we," or "our") collects, uses, and shares personal information when you use the [Fertility Management App] (the "App").</p>
<h3>1. Information We Collect</h3>
<p>We collect various types of information to provide and improve the App. The types of information we may collect include:</p>
<h4>1.1 Personal Information</h4>
<ul>
<li><strong>Full name</strong></li>
<li><strong>Email address</strong></li>
<li><strong>Phone number</strong></li>
<li><strong>Home address</strong></li>
<li><strong>Date of birth</strong></li>
<li><strong>Gender</strong></li>
</ul>
<h4>1.2 Health Information</h4>
<ul>
<li><strong>Fertility and reproductive health data</strong>: This includes information related to menstrual cycles, ovulation, pregnancy, and any related health data that you choose to provide.</li>
</ul>
<h4>1.3 Financial Information</h4>
<ul>
<li><strong>Credit card details</strong>: We may collect this information when processing payments for premium features or services.</li>
</ul>
<h4>1.4 Usage Data</h4>
<ul>
<li>
<p><strong>Device information</strong>: This includes your device's IP address, operating system, browser type, and version.</p>
</li>
<li>
<p><strong>Log data</strong>: We automatically collect log data, including the pages you visit, your interaction with the App, and the dates and times of your visits.</p>
</li>
</ul>
<h4>1.5 Cookies and Tracking Technologies</h4>
<p>We use cookies and similar tracking technologies to track the activity on our App. These technologies may include:</p>
<ul>
<li><strong>Session cookies</strong>: To operate our service.</li>
<li><strong>Preference cookies</strong>: To remember your preferences and settings.</li>
<li><strong>Security cookies</strong>: For security purposes.</li>
</ul>
<h3>2. How We Use Your Information</h3>
<p>We use your information for the following purposes:</p>
<h4>2.1 Providing and Improving the App</h4>
<ul>
<li>To provide, maintain, and improve the App.</li>
<li>To monitor the usage of the App.</li>
</ul>
<h4>2.2 Personalization</h4>
<ul>
<li>To personalize your experience and deliver content tailored to your preferences.</li>
</ul>
<h4>2.3 Communication</h4>
<ul>
<li>To notify you about changes to the App.</li>
<li>To provide customer support.</li>
</ul>
<h4>2.4 Analytics</h4>
<ul>
<li>To gather valuable information to improve the App and our services.</li>
</ul>
<h4>2.5 Payment Processing</h4>
<ul>
<li>To process payments for premium features and services.</li>
</ul>
<h3>3. How We Share Your Information</h3>
<p>We do not sell or share your personal information with third parties except as described in this Privacy Policy:</p>
<h4>3.1 Service Providers</h4>
<p>We may employ third-party companies and individuals to facilitate our App and provide the App on our behalf.</p>
<h4>3.2 Legal Requirements</h4>
<p>We may disclose your personal information in good faith to comply with a legal obligation, protect and defend our rights or property, act in urgent circumstances to protect the personal safety of users of the App, or protect against legal liability.</p>
<h3>4. Your Rights</h3>
<p>You have the following rights regarding your personal information:</p>
<h4>4.1 Access, Correction, and Deletion</h4>
<p>You may request access to, correction, or deletion of your personal information.</p>
<h4>4.2 Data Portability</h4>
<p>You have the right to request a copy of your data in a commonly used format.</p>
<h4>4.3 Opt-Out</h4>
<p>You can opt out of receiving promotional emails from us.</p>
<h3>5. Data Security</h3>
<p>We take appropriate measures to protect your data:</p>
<ul>
<li>We use encryption to protect data transmitted to and from the App.</li>
<li>We regularly monitor our systems for possible vulnerabilities and attacks.</li>
<li>We limit access to your personal information to employees who need to know this information.</li>
</ul>
<h3>6. Children's Privacy</h3>
<p>Our App does not address anyone under the age of 18. We do not knowingly collect personal information from children under 18. If we discover that a child under 18 has provided us with personal information, we will promptly delete it from our servers.</p>
<h3>7. Changes to This Privacy Policy</h3>
<p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
<h3>8. Contact Us</h3>
<p>If you have any questions about this Privacy Policy, please contact us at or mail.</p>