
</script><button onclick="openNewWindow()">Try it</button>


<script>
function openNewWindow() {
  // Specify the URL, window name, and dimensions
  var url = "https://www.w3schools.com";
  var windowName = "MyWindow";
  var windowFeatures = "width=800,height=600";

  // Open the new browser window
  window.open(url, windowName, windowFeatures);
}
</script>
In this code, you can adjust the width and height values in the windowFeatures string to set the dimensions of the new browser window as per your requirements. When you call the openNewWindow() function, it will open a new browser window with the specified dimensions. However, it's worth noting that modern browsers may still override these settings based on the user's preferences and browser restrictions. Users often have the ability to control whether pop-up windows open in new tabs or new windows.





